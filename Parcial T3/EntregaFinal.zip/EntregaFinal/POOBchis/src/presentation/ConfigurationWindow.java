package presentation;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.*;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import domain.Poobchis;
import domain.PoobchisException;

/**
 * Clase que crea la ventana de configuracion
 * @author Angie Mojica - Daniel Santanilla.
 * @version 0.4
 */
public class ConfigurationWindow {
	
	private CardLayout card;
	private POOBchisGUI gui;
	private Poobchis currentGame;
	private GameWindow GW;
	private JPanel principal;
	private JTextField nombre;
	private JLabel fondoCW, tituloC, tituloJ, jugador, lnombre, lcolor, numero, lsolo, lpareja, lcomodines, lfichas;
	private JButton solo, pareja, iniciar, agregar, aleatorio, personalizar;
	private PaintPicture impresora;
	private Color color;
	private int noJugadores, actual;
	private List<String> jugadoresNombre = new ArrayList<>();
	private List<Color> jugadoresColor = new ArrayList<>();
	private List<String> jugadoresFichas;
	private List<String> jugadoresComodines = new ArrayList<>();
	private List<JButton> coloresLista = new ArrayList<>();
	private List<JCheckBox> comodinesLista = new ArrayList<>();
	private List<JCheckBox> fichasLista = new ArrayList<>();
	private List<JButton> colorPressed = new ArrayList<>();
	private boolean tipoDeDado;
	
	/**
	 * Constructor de la ventana
	 * @param gui Vista de la venta principal.
	 */
	public ConfigurationWindow(POOBchisGUI gui) {
		this.gui = gui;
		this.actual = 1;
		card = gui.getCard();
		principal = gui.getPrincipal();
		impresora = PaintPicture.getPrinter();
		prepareElements();
		prepareWildCardBox();
		preparePiceBox();
		prepareColoredButtons();
		prepareSizes();
		prepareInvisibilitys();
		prapareImages();
		addComponents();
		prepareActions();
	}

	/**
	 * Crea los elementos visuales de la ventana.
	 */
	private void prepareElements() {
		fondoCW = new JLabel();
		tituloC = new JLabel();
		tituloJ = new JLabel();
		lsolo = new JLabel();
		lpareja = new JLabel();
		lcomodines = new JLabel();
		lfichas = new JLabel();
		jugador = new JLabel();
		numero = new JLabel();
		lnombre = new JLabel();
		lcolor = new JLabel();
		nombre = new JTextField();
		solo = new JButton();
		pareja = new JButton();
		aleatorio = new JButton();
		personalizar = new JButton();
		iniciar = new JButton();
		agregar = new JButton();
	}
	
	/**
	 * Crea las opciones de comodines a agregar al juego
	 */
	private void prepareWildCardBox() {
		String[] comodinesNombre = {"Avanzar","Retroceder","Encarcelar","Liberar","Dobles", "Eliminar","Inmortal", "Mutar", "Antibloqueo"};
		String[] tipsComodines = 
			{"Avanza 5 Casillas",
			 "Retrocede 5 Casilla",
			 "La Ficha Entra A La Carcel",
			 "Sale De la Carcel Una Ficha",
			 "Juega Doble Turno",
			 "Elimina La Ficha Mas Avanzada Del Oponente",
			 "La Ficha Se Vuelve Inmortal Durante La Partida",
			 "La Ficha Muta A Una Personalizada",
			 "Deshace El Bloqueo Mas Cercano"};
		for (int i = 0; i < comodinesNombre.length; i++) {
			JCheckBox comodin = new JCheckBox(comodinesNombre[i]);
			comodin.setToolTipText(tipsComodines[i]);
			comodin.setContentAreaFilled(false);
			comodin.setFont(new Font("arial",1,20));
			comodin.setForeground(Color.WHITE);
			comodin.setBounds(790, 300+i*30, 200, 25);
			comodin.setVisible(false);
			fondoCW.add(comodin);
			comodinesLista.add(comodin);
		}
		
	}
	
	/**
	 * Crea las posibles opciones a escoger de los tipos de fichas en el juego.
	 */
	private void preparePiceBox() {
		String[] fichasNombre = {"Cohete","Aspiradora","Saltarina","Ventajosa","Ingeniera"};
		String[] tipsFichas = 
			{"Avanza al seguro mas cercano",
			 "Atrae ficha mas cercana",
			 "Salta los bloqueos",
			 "Avanza 3 casillas cada 2 turnos",
			 "Crea seguros en la casilla que cae"};
		for (int i = 0; i < fichasNombre.length; i++) {
			JCheckBox ficha = new JCheckBox(fichasNombre[i]);
			ficha.setToolTipText(tipsFichas[i]);
			ficha.setContentAreaFilled(false);
			ficha.setFont(new Font("arial",1,20));
			ficha.setForeground(Color.WHITE);
			ficha.setBounds(480, 300+i*30, 200, 25);
			ficha.setVisible(false);
			fondoCW.add(ficha);
			fichasLista.add(ficha);
		}
	}
	
	/**
	 * Preapara los botones para que el jugador seleccione el color.
	 */
	private void prepareColoredButtons() {
		String[] tipsColores = {"Amarillo", "Azul", "Rojo", "Verde"};
		for (int i = 0; i < 4; i++) {
			JButton color = new JButton();
			color.setBounds(160+i*40, 350, 30, 30);
			color.setToolTipText(tipsColores[i]);
			if (i == 0) {
				color.setBackground(Color.YELLOW);
			} else if (i == 1) {
				color.setBackground(Color.BLUE);
			} else if (i == 2) {
				color.setBackground(Color.RED);
			} else if (i == 3) {
				color.setBackground(Color.GREEN);
			}
			color.setVisible(false);
			color.addMouseListener( new MouseAdapter(){
				public void mousePressed(MouseEvent e) {
					actionColor(e);
				} 
			});
			fondoCW.add(color);
			coloresLista.add(color);
		}
	}
	
	/**
	 * Modifica los tamannos de los componentes visuales de la ventana.
	 */
	private void prepareSizes() {
		tituloC.setBounds(200, 0, 667, 200);
		tituloJ.setBounds(250, 0, 491, 179);
		solo.setBounds(320, 380, 130, 130);
		pareja.setBounds(520, 380, 130, 130);
		lsolo.setBounds(320, 300, 152, 79);
		lpareja.setBounds(520, 300, 152, 79);
		lcomodines.setBounds(750, 200, 242, 85);
		lfichas.setBounds(450, 200, 165, 80);
		jugador.setBounds(150, 200, 215, 86);
		numero.setBounds(350, 190, 100, 100);
		lnombre.setBounds(10, 290,  146, 62);
		lcolor.setBounds(10, 340, 121, 59);
		nombre.setBounds(160, 300, 239, 30);
		aleatorio.setBounds(450, 300, 232, 88);
		personalizar.setBounds(450, 360, 317, 94);
		iniciar.setBounds(450, 500, 173, 79);
		agregar.setBounds(150, 500, 207, 82);
		solo.setToolTipText("1 Jugador");
		pareja.setToolTipText("2 Jugadores");
		aleatorio.setToolTipText("Genera Tu Equipo De Fichas Aleatorio");
		personalizar.setToolTipText("Personaliza Tu Equipo De Fichas");
		agregar.setToolTipText("Agregar Jugador");
		nombre.setToolTipText("Ingresa Un Nombre");
	}
	
	/**
	 * Se modifican las caracteristicas de los componentes de la ventana.
	 */
	private void prepareInvisibilitys() {
		solo.setBorder(null);
		pareja.setBorder(null);
		aleatorio.setBorder(null);
		personalizar.setBorder(null);
		agregar.setBorder(null);
		iniciar.setBorder(null);
		solo.setContentAreaFilled(false);
		pareja.setContentAreaFilled(false);
		aleatorio.setContentAreaFilled(false);
		personalizar.setContentAreaFilled(false);
		agregar.setContentAreaFilled(false);
		iniciar.setContentAreaFilled(false);
		lcomodines.setVisible(false);
		lfichas.setVisible(false);
		aleatorio.setVisible(false);
		tituloC.setVisible(false);
		jugador.setVisible(false);
		personalizar.setVisible(false);
		numero.setVisible(false);
		nombre.setVisible(false);
		lnombre.setVisible(false);
		lcolor.setVisible(false);
		agregar.setVisible(false);
		iniciar.setVisible(false);
	}
	
	/**
	 * Agregan imagenes a las componentes de la ventana.
	 */
	private void prapareImages() {
		impresora.pintarImagen(fondoCW, "./img/fondoPrincipal.jpg", 1080, 720);
		impresora.pintarImagen(tituloC, "./img/configuracion.png", 677, 200);
		impresora.pintarImagen(tituloJ, "./img/jugadores.png", 491, 179);
		impresora.pintarImagen(jugador, "./img/jugador.png", 215, 86);
		impresora.pintarImagen(lnombre, "./img/nombre.png", 146, 62);
		impresora.pintarImagen(lcolor, "./img/color.png", 121, 59);
		impresora.pintarImagen(iniciar, "./img/iniciar.png", 173, 79);
		impresora.pintarImagen(agregar, "./img/agregar.png", 207, 82);
		impresora.pintarImagen(numero, "./img/1.png", 80, 80);
		impresora.pintarImagen(solo, "./img/1.png", 130, 130);
		impresora.pintarImagen(pareja, "./img/2.png", 130, 130);
		impresora.pintarImagen(lsolo, "./img/maquina.png", 152, 79);
		impresora.pintarImagen(lpareja, "./img/humanos.png", 152, 79);
		impresora.pintarImagen(lcomodines, "./img/comodines.png", 242, 85);
		impresora.pintarImagen(lfichas, "./img/fichas.png", 165, 80);
		impresora.pintarImagen(aleatorio, "./img/aleatorio.png", 232, 88);
		impresora.pintarImagen(personalizar, "./img/personalizar.png", 317, 94);
	}
	
	/**
	 * Agregar componentes a la etiqueta principal y al panel.
	 */
	private void addComponents() {
		fondoCW.add(tituloC);
		fondoCW.add(tituloJ);
		fondoCW.add(jugador);
		fondoCW.add(lsolo);
		fondoCW.add(lpareja);
		fondoCW.add(lcomodines);
		fondoCW.add(lfichas);
		fondoCW.add(solo);
		fondoCW.add(pareja);
		fondoCW.add(numero);
		fondoCW.add(nombre);
		fondoCW.add(lnombre);
		fondoCW.add(lcolor);
		fondoCW.add(aleatorio);
		fondoCW.add(personalizar);
		fondoCW.add(iniciar);
		fondoCW.add(agregar);
		principal.add(fondoCW, "FondoCW");
	}
	
	/**
	 * Pepara las acciones de cada boton.
	 */
	private void prepareActions() {
		iniciar.addActionListener( new ActionListener(){
			public void actionPerformed( ActionEvent event) {
				actionIniciar();
			} 
		});
		agregar.addActionListener( new ActionListener(){
			public void actionPerformed( ActionEvent event) {
				actionAgregar();
			} 
		});
//		solo.addActionListener( new ActionListener(){
//			public void actionPerformed( ActionEvent event) {
//				noJugadores = 1;
//				actionPrepareBot();
//			} 
//		});
		pareja.addActionListener( new ActionListener(){
			public void actionPerformed( ActionEvent event) {
				noJugadores = 2;
				actionPrepare();
			} 
		});
		aleatorio.addActionListener( new ActionListener(){
			public void actionPerformed( ActionEvent event) {
				actionRandom();
			} 
		});
		personalizar.addActionListener( new ActionListener(){
			public void actionPerformed( ActionEvent event) {
				actionPersonalize();
			} 
		});
	}
	
	/**
	 * Selecciona aleatoriamente los tipos de fichas para la partida.
	 */
	protected void actionRandom() {
		aleatorio.setVisible(false);
		personalizar.setVisible(false);
		int random = (int)(Math.random()*3+1);
		for (int i = 0; i < random; i++) {
			int pos = (int)(Math.random()*fichasLista.size());
			JCheckBox ficha = fichasLista.get(pos);
			ficha.setSelected(true);
		}
		for (JCheckBox ficha : fichasLista) {
			ficha.setVisible(true);
			ficha.setEnabled(false);
		}
	}
	
	/**
	 * Permite personalizar las fichas para la partida.
	 */
	protected void actionPersonalize() {
		aleatorio.setVisible(false);
		personalizar.setVisible(false);
		for (JCheckBox ficha : fichasLista) {
			ficha.setVisible(true);
		}
	}
	
	/**
	 * Prepara la ventana de configuracion.
	 */
	protected void actionPrepare() {
		lsolo.setVisible(false);
		lpareja.setVisible(false);
		tituloJ.setVisible(false);
		tituloC.setVisible(true);
		solo.setVisible(false);
		pareja.setVisible(false);
		jugador.setVisible(true);
		numero.setVisible(true);
		nombre.setVisible(true);
		aleatorio.setVisible(true);
		lnombre.setVisible(true);
		lcolor.setVisible(true);
		lcomodines.setVisible(true);
		lfichas.setVisible(true);
		personalizar.setVisible(true);
		agregar.setVisible(true);
		for (JCheckBox comodin : comodinesLista) {
			comodin.setVisible(true);
		}
		for (JButton color : coloresLista) {
			color.setVisible(true);
		}
	}
	
	/**
	 * Determina la accicion al presionar el boton agregar.
	 * Ente annade un jugador con su respectivo color.
	 */
	protected void actionAgregar() {
		if (this.color == null) {
			JOptionPane.showMessageDialog(null, "Falta Escojer El Color Del Jugador","�Alerta!",1);
		} else if (nombre.getText().equals("")) {
			JOptionPane.showMessageDialog(null, "Falta Nombre Del Jugador","�Alerta!",1);
		} else {
			jugadoresNombre.add(nombre.getText());
			jugadoresColor.add(this.color);
			for (JButton color : coloresLista) {
				if (color.getBackground().equals(this.color)) {
					colorPressed.add(color);
				}
			}
			this.color = null;
			if (this.actual != this.noJugadores) {
				this.actual += 1;  
				nombre.setText("");
				impresora.pintarImagen(numero, "./img/"+this.actual+".png", 80, 80);
			} else {
				agregar.setVisible(false);
				iniciar.setVisible(true);
			}
		}
	}
	
	/**
	 * Inicia la partida con las configuraciones seleccionadas.
	 */
	public void actionIniciar() {
		try {
			int resp = JOptionPane.showConfirmDialog(null, "�Quieres usar dados magicos?\n Estos dados van de 1 a 8", "Tipo de Dado", JOptionPane.YES_NO_OPTION);
			if (resp == JOptionPane.YES_OPTION) {
				tipoDeDado = true;
			}
			escogerFichas();
			escogerComodines();
			currentGame = new Poobchis(jugadoresNombre, jugadoresColor, jugadoresFichas, jugadoresComodines, tipoDeDado);
			GW = new GameWindow(gui, currentGame);
			card.show(principal, "FondoGW");
		} catch (PoobchisException e) {
			JOptionPane.showMessageDialog(null, e.getMessage()+"\nReconsidera tu eleccion.","�Alerta!",2);
		}	
	}

	/**
	 * Se escoge los comodines seleccionados.
	 */
	private void escogerComodines() {
		for (JCheckBox comdin : comodinesLista) {
			if (comdin.isSelected()) {
				jugadoresComodines.add(comdin.getText());
			}
		}
		if (jugadoresComodines.size()==0) {
			for (int i = 0; i < 4; i++) {
				int pos = (int)(Math.random()*comodinesLista.size());
				jugadoresComodines.add(comodinesLista.get(pos).getText());
			}
		}
	}

	/**
	 * Realiza la accion cuando se elije un color
	 * @param e Evento generado por el mouse.
	 */
	public void actionColor(MouseEvent e) {
		JButton pressed = (JButton)e.getSource();
		pressed.setEnabled(false);
		for (JButton color : coloresLista) {
			if (color != pressed) {
				color.setEnabled(true);
				for (JButton used : colorPressed) {
					used.setEnabled(false);
				}	
			}
		}
		if (pressed.getBackground() == Color.YELLOW) {
			this.color = Color.YELLOW;
		} else if (pressed.getBackground() == Color.BLUE) {
			this.color = Color.BLUE;
		} else if (pressed.getBackground() == Color.RED) {
			this.color = Color.RED;
		} else if (pressed.getBackground() == Color.GREEN) {
			this.color = Color.GREEN;
		}
	}
	
	/**
	 * Obtiene el juego creado
	 * @return Juego actual
	 */
	public Poobchis getJuego() {
		return currentGame;
	}
	
	/**
	 * Obtiene la ventana del juego
	 * @return Estado del juego
	 */
	public GameWindow getGameW() {
		return GW;
	}
	
	/**
	 * Se escoje las fichas selecionadas.
	 * @throws PoobchisException EXCEDIDA_PERSONALIZADAS Si se exceden mas de 4 fichas seleccionadas.
	 */
	public void escogerFichas() throws PoobchisException{
		jugadoresFichas = new ArrayList<>();
		for (JCheckBox ficha : fichasLista) {
			if (ficha.isSelected()) {
				jugadoresFichas.add(ficha.getText());
			} 
		}
		if (jugadoresFichas.size() > 4 ) {
			throw new PoobchisException(PoobchisException.EXCEDIDA_PERSONALIZADAS);
		}
		while (jugadoresFichas.size() < 4) {
			jugadoresFichas.add("Ficha");
		}
	}

}
