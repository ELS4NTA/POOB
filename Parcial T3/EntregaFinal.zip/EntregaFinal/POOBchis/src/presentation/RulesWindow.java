package presentation;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Font;

import javax.swing.*;

import domain.Poobchis;

/**
 * Clase que crea la ventana del juego
 * @author Angie Mojica - Daniel Santanilla.
 * @Version 0.3
 */
public class RulesWindow {
	private CardLayout card;
	private POOBchisGUI gui;
	private JPanel principal;
	private JLabel fondoRW, reglas;
	private PaintPicture impresora;
	
	/**
	 * Constructor
	 * @param gui Ventana principal
	 */
	public RulesWindow(POOBchisGUI gui) {
		this.gui = gui;
		card = gui.getCard();
		principal = gui.getPrincipal();
		impresora = PaintPicture.getPrinter();
		prepareElements();
		prepareSizes();
		prapareImages();
		addComponents();
		prepareActions();
	}
	
	/**
	 * Prepara los elementos de la ventana
	 */
	private void prepareElements() {
		fondoRW = new JLabel();
		reglas = new JLabel();
		reglas.setFont(new Font("arial",1,20));
		reglas.setForeground(Color.LIGHT_GRAY);
		fondoRW.setVisible(true);
	}
	
	/**
	 * Modifica los tamannos de las etiquetas
	 */
	private void prepareSizes() {
		fondoRW.setBounds(0, 0, 1080, 720);
		reglas.setBounds(50, 0, 980, 620);
	}
	
	/**
	 * Agrega el texto a la etiqueta
	 */
	private void prapareImages() {
		impresora.pintarImagen(fondoRW, "./img/fondoPrincipal.jpg", 1080, 720);
		reglas.setText
		("<html>GANAR EL JUEGO: Gana el jugador que primero logre llevar sus 4 fichas alrededor del tablero hasta la llegada en forma segura.<p>"
	    +"<p>SALIR DE LA CARCEL: Las pierzas salen de la carcel cuando el jugador tira 5 en un dado.<p>"
		+"<p>CASTIGO 3 PARES: Si el jugador obtiene 3 pares consecutivos la tercera vez pierde el turno y la ultima ficha jugada va a la carcel.<p>"
	    +"<p>BLOQUEOS: Dos fichas del mismo color en una casilla pueden generar un bloqueo, "
	    + "lo que implica que ninguna ficha podra sobrepasar esa casilla a menos que sea la ficha saltarina.<p>"
	    + "<p>SEGUROS: Las casillas grises son espacion seguros y en esa casilla no se puede campturar fichas.<p>"
	    + "<p>PREMIO POR CORONACION: El jugador obtiene +10 movimientos por llevar una ficha a la casilla de coronacion.<p>"
	    + "<p>PREMIO POR CAPTURA: El jugador obtiene +20 movimientos por capturar una ficha de algun contrincante.<html>");
	}
	
	/**
	 * Agrega los componentes a la ventada
	 */
	private void addComponents() {
		fondoRW.add(reglas);
		principal.add(fondoRW, "FondoRW");
	}

	private void prepareActions() {
		// TODO Auto-generated method stub
		
	}
}
