package domain;
import java.io.Serializable;
import java.util.ArrayList;

import domain.fichas.Ficha;
/**
 * Clase que representa la carcel de un tablero de Poobchis.
 * @author Angie Mojica - Daniel Santanilla
 * @version 0.4
 */
public class Carcel implements Serializable{
	
	private ArrayList<Ficha> encarceladas = new ArrayList<Ficha>();
	
	/**
	 * Constructor de la carcel.
	 * @param fichasJugador Lista de fichas del jugador.
	 */
	public Carcel(ArrayList<Ficha> fichasJugador) {
		for (Ficha ficha : fichasJugador)  {
			encarceladas.add(ficha);
		}
		
	}
	/**
	 * Obtiene las fichas que estan en la cacel.
	 * @return Lista de las fichas encarceladas.
	 */
	public ArrayList<Ficha> getEncarceladas() {
		return this.encarceladas;
	}
	
	/**
	 * Annade una ficha a la carcel.
	 * @param nuevaFicha Ficha para agregar a la carcel.
	 */
	public void addFicha(Ficha nuevaFicha) {
		encarceladas.add(nuevaFicha);
	}
	
	/**
	 * Verifica si la ficha esta actualmente en la carcel
	 * @param ficha Ficha por consultar
	 * @return True si la ficha esta en carcel, False si no.
	 */
	public boolean contieneFicha(Ficha ficha) {
		return encarceladas.contains(ficha);
	}
	
	/**
	 * Elimina una ficha de la carcel.
	 * @return Ficha proxima a salir.
	 */
	public Ficha sacarFicha() {
		Ficha ficha = encarceladas.get(0);
		encarceladas.remove(0);
		return ficha;
	}
	
	/**
	 * Quita una ficha especifica de la carcel.
	 * @param ficha Ficha que se quiere eliminar de carcel.
	 */
	public void quitarFicha(Ficha ficha) {
		this.encarceladas.remove(ficha);
	}
	
	/**
	 * Verfica si hay fichas en la carcel.
	 * @return True si la carcel no contiene fichas, de lo contrario false.
	 */
	public boolean estaVacia() {
		return encarceladas.isEmpty();
	}
	
	/**
	 * Obtiene la cantidad de fichas en carcel.
	 * @return Entero con la cantidad de fichas encarceladas.
	 */
	public int getTamanno() {
		return encarceladas.size();
	}
}
