package domain.fichas;

import java.awt.Color;
import java.io.Serializable;

/**
 * Clase que representa a una {@link Ficha} Ventajosa\n
 * Cada dos turnos del jugador la ficha avanzar� a 3 casillas sin necesidad que el 
 * jugador se lo indique o caiga 3 en el valor de los dados.
 * @author Angie Mojica - Daniel Santanilla.
 * @Version 0.4
 */
public class Ventajosa extends Ficha implements Serializable{
	
	/**
	 * Constructor de la ficha
	 * @param color Color de la ficha.
	 */
	public Ventajosa(Color color) {
		super(color);
	}
	
	/**
	 * Ver tambien {@inheritDoc}
	 */
	@Override
	public String getTipo() {
		return "Ventajosa";
	}
	
}
