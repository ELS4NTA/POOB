package domain.fichas;
import java.awt.Color;
import java.io.Serializable;

import domain.PoobchisException;
import domain.Tablero;
/**
 * Clase que representa a una {@link Ficha} Cohete\n
 * Esta ficha salta al seguro m�s cercano sin necesidad que el valor de los dados sea
 * v�lido, �nicamente puede ser usado este poder 2 veces durante la partida.
 * @author Angie Mojica - Daniel Santanilla
 * @Version 0.4
 */
public class Cohete extends Ficha implements Serializable{
	
	/**
	 * Crea una ficha Cohete
	 * @param color Color de la ficha
	 */
	public Cohete(Color color) {
		super(color);
	}
	
	/**
	 * Ver tambien {@inheritDoc}
	 */
	@Override
	public void setNumPoder() {
		poderUsado = 2;
	}
	
	/**
	 * Ver tambien {@inheritDoc}
	 */
	@Override
	public void poderUsado(Tablero tablero) {
		int distanciaSeguroCercano = tablero.getSeguroCercano(this);
		if (sePuedeMover(this, distanciaSeguroCercano, tablero)) {
			try {
				mover(tablero.getJugador(getColor()), this, distanciaSeguroCercano, tablero);
			} catch (PoobchisException e) {
				e.printStackTrace();
			}
		}
		poderUsado -= 1;
	}
	
	/**
	 * Ver tambien {@inheritDoc}
	 */
	@Override
	public String getTipo() {
		return "Cohete";
	}
	

}
