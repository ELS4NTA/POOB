package domain.comodines;

import java.io.Serializable;

import domain.Poobchis;
import domain.PoobchisException;
import domain.fichas.Ficha;

/**
 * Clase que representa un comodin\n
 * Los comodines son ventajas o desventajas que puede adquirir el jugador durante la partida, 
 * al caer en una casilla con comodin el jugador recibe un comodin aleatorio.
 * @author Angie Mojica - Daniel Santanilla
 * @version 0.4
 */
public abstract class Comodin  implements Serializable{
	
	/**
	 * Constructor de un comodin
	 */
	public Comodin() {}
	
	/**
	 * Accion especial del comodin sobre una ficha.
	 * @param currentGame Juego en curso.
	 * @param ficha Ficha que obtiene el comdin.
	 * @throws PoobchisException Si ocurre algun error de movimiento
	 */
	public abstract void especial(Poobchis currentGame, Ficha ficha) throws PoobchisException;
}
