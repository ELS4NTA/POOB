package domain.comodines;

import java.io.Serializable;

import javax.swing.JOptionPane;

import domain.Poobchis;
import domain.PoobchisException;
import domain.fichas.Ficha;

/**
 * Clase que represneta un {@link Comodin} Avanzar
 * @author Angie Mojica - Daniel Santanilla
 * @version 0.4
 */
public class Avanzar extends Comodin implements Serializable{
	
	/**
	 * La ficha que obtenga este comodin avanza 5 casillas automaticamente.
	 * Ver tambien {@inheritDoc}
	 */
	@Override
	public void especial(Poobchis currentGame, Ficha ficha) throws PoobchisException {
		JOptionPane.showMessageDialog(null, "Avanza 5 casillas.","Buena Suerte",1);
		currentGame.jugar(ficha, 5);
		
	}

}
