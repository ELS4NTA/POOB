package domain.comodines;

import java.io.Serializable;

import javax.swing.JOptionPane;

import domain.Casilla;
import domain.Jugador;
import domain.Poobchis;
import domain.fichas.Ficha;

/**
 * Clase que representa un {@link Comodin} Encarcelar
 * @author Angie Mojica - Daniel Santanilla
 * @version 0.4
 */
public class Encarcelar extends Comodin implements Serializable{
	
	/**
	 * La ficha que obtenga este comodin se ira directamente a la carcel.
	 * Ver tambien {@inheritDoc}
	 */
	@Override
	public void especial(Poobchis currentGame, Ficha ficha) {
		JOptionPane.showMessageDialog(null, "Se te encarcelo la ficha.","Mala Suerte",1);
		int pos = ficha.getPosicion();
		Casilla casilla = currentGame.getTableroJuego().getCasilla(pos);
		casilla.quitarFicha(ficha);
		ficha.setPosicion(0);
		Jugador jugador = currentGame.getJugadorEnTurno();
		jugador.getNido().addFicha(ficha);
		
	}

}
