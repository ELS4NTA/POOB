package domain.comodines;

import java.io.Serializable;

import javax.swing.JOptionPane;

import domain.Poobchis;
import domain.PoobchisException;
import domain.fichas.Ficha;

/**
 * Clase que represnetna un {@link Comodin} Retroceder
 * @author Angie Mojica - Daniel Santanilla
 * @version 0.4
 */
public class Retroceder extends Comodin implements Serializable{
	
	/**
	 * La ficha que obtenga este comodin retrocede 5 casillas autom�ticamente.
	 * Ver tambien {@inheritDoc}
	 */
	@Override
	public void especial(Poobchis currentGame, Ficha ficha) throws PoobchisException {
		JOptionPane.showMessageDialog(null, "Retrocedes 5 casillas.","Mala Suerte",1);
		//currentGame.jugar(ficha, -5); no sirve dado que el mover que usa la ficha no es valido para reversa
		
		
	}

}
