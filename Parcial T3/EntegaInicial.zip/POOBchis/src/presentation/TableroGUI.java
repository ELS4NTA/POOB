package presentation;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.swing.*;

import org.hamcrest.core.IsInstanceOf;

import domain.Carcel;
import domain.Casilla;
import domain.Dado;
import domain.Jugador;
import domain.Poobchis;
import domain.PoobchisException;
import domain.Tablero;
import domain.fichas.Aspiradora;
import domain.fichas.Cohete;
import domain.fichas.Ficha;
import domain.fichas.Ingeniera;
import domain.fichas.Ventajosa;

/**
 * Clase que crea la interfaz del tablero
 * @author Angie Mojica - Daniel Santanilla.
 * @version 0.3
 */
public class TableroGUI extends JPanel {
	private PaintPicture impresora; 
	private ArrayList<JPanel> tableroCasillas = new ArrayList<JPanel>();
	private static ArrayList<JButton> fichas = new ArrayList<JButton>();
	private HashMap<Color, String> colorMap = new HashMap<Color, String>();
	private final int distancex = 73;
	private final int distancey = 27;
	private Poobchis currentGame;
	private JPanel panel0, panel1, panel2, panel3, panel5, panel6, panel7, panel8;
	private GameWindow instanceGameGui;
	private TriangleTablero panel4;
	
	/**
	 * Constructor del tablero visual
	 * @param juego Estado del juego actual
	 * @param gameGUI Ventana del juego
	 */
	public TableroGUI(Poobchis juego, GameWindow gameGUI) {
		instanceGameGui = gameGUI;
	    colorMap.put(Color.BLUE, "azul");
	    colorMap.put(Color.RED, "rojo");
	    colorMap.put(Color.YELLOW, "amarillo");
	    colorMap.put(Color.GREEN, "verde");
		impresora = PaintPicture.getPrinter();
		currentGame = juego;
		iniciarComponentes();
		pintarComponentes();
		iniciarTablero();
	}
	
	/**
	 * Creacion de los paneles que representan las casillas del tablero
	 */
	private void iniciarComponentes() {
		setBounds(0, 0, 660, 660);
		setLayout(new GridLayout(3, 3, 0, 0));
		panel0 = new JPanel();
		panel1 = new JPanel();
		panel2 = new JPanel();
		panel3 = new JPanel();
		panel5 = new JPanel();
		panel6 = new JPanel();
		panel7 = new JPanel();
		panel8 = new JPanel();
		panel1.setLayout(null);
		panel3.setLayout(null);
		panel5.setLayout(null);
		panel7.setLayout(null);
		panel0.setBorder(BorderFactory.createEtchedBorder());
		panel1.setBorder(BorderFactory.createEtchedBorder());
		panel2.setBorder(BorderFactory.createEtchedBorder());
		panel3.setBorder(BorderFactory.createEtchedBorder());
		panel5.setBorder(BorderFactory.createEtchedBorder());
		panel6.setBorder(BorderFactory.createEtchedBorder());
		panel7.setBorder(BorderFactory.createEtchedBorder());
		panel8.setBorder(BorderFactory.createEtchedBorder());
		panel0.setLayout(new GridLayout(2,2,1,1));
		panel2.setLayout(new GridLayout(2,2,1,1));
		panel6.setLayout(new GridLayout(2,2,1,1));
		panel8.setLayout(new GridLayout(2,2,1,1));
		panel0.setBackground(Color.RED);
		panel2.setBackground(Color.BLUE);
		panel6.setBackground(Color.GREEN);
		panel8.setBackground(Color.YELLOW);
		panel4 = new TriangleTablero();
		add(panel0);
		add(panel1);
		add(panel2);
		add(panel3);
		add(panel4);
		add(panel5);
		add(panel6);
		add(panel7);
		add(panel8);
		JPanel casilla0 = new JPanel();
		tableroCasillas.add(casilla0);
		
		//Casillas 1-8
		int cont = 192;
		for (int i=1; i<9; i++) {
			JPanel casilla = new JPanel();
			casilla.setBounds(146, cont, distancex, distancey);
			casilla.setLayout(new GridLayout(1,3,4,4));
			panel7.add(casilla);
			tableroCasillas.add(casilla);
			cont -= distancey;
		}
	
		//Casillas 9-16
		int cont2 = 2;
		for (int i=1; i<9; i++) {
			JPanel casilla = new JPanel();
			casilla.setBounds(cont2, 148, distancey, distancex);
			casilla.setLayout(new GridLayout(3,1,4,4));
			panel5.add(casilla);
			tableroCasillas.add(casilla);
			cont2 += distancey;
		}

		//Casilla 17; 18-25
		JPanel casilla17 = new JPanel();
		casilla17.setBounds(191, 75, distancey, distancex);
		casilla17.setLayout(new GridLayout(3,1,4,4));
		panel5.add(casilla17);
		tableroCasillas.add(casilla17); 
		int cont3 = 191;
		for (int i=1; i<9; i++) {
			JPanel casilla = new JPanel();
			casilla.setBounds(cont3, 2, distancey, distancex);
			casilla.setLayout(new GridLayout(3,1,4,4));
			panel5.add(casilla);
			tableroCasillas.add(casilla);
			cont3 -= distancey;
		}
		
		//Casillas 26-33
		int cont4 = 193;
		for (int i=1; i<9; i++) {
			JPanel casilla = new JPanel();
			casilla.setBounds(146, cont4, distancex, distancey);
			casilla.setLayout(new GridLayout(1,3,4,4));
			panel1.add(casilla);
			tableroCasillas.add(casilla);
			cont4 -= distancey;
		}

		//Casillas 34; 35-42
		JPanel casilla34 = new JPanel();
		casilla34.setBounds(73, 4,  distancex, distancey);
		casilla34.setLayout(new GridLayout(1,3,4,4));
		panel1.add(casilla34);
		tableroCasillas.add(casilla34); 
		int cont5 = 4;
		for (int i=1; i<9; i++) {
			JPanel casilla = new JPanel();
			casilla.setBounds(1, cont5, distancex, distancey);
			casilla.setLayout(new GridLayout(1,3,4,4));
			panel1.add(casilla);
			tableroCasillas.add(casilla);
			cont5 += distancey;
		}
		
		//Casillas 43-50
		int cont6 = 192;
		for (int i=1; i<9; i++) {
			JPanel casilla = new JPanel();
			casilla.setBounds(cont6, 2, distancey, distancex);
			casilla.setLayout(new GridLayout(3,1,4,4));
			panel3.add(casilla);
			tableroCasillas.add(casilla);
			cont6 -= distancey;
		}

		//Casillas 51; 52-59
		JPanel casilla51 = new JPanel();
		casilla51.setBounds(2, 75, distancey, distancex);
		casilla51.setLayout(new GridLayout(3,1,4,4));
		panel3.add(casilla51);
		tableroCasillas.add(casilla51);
		
		int cont7 = 3;
		for (int i=1; i<9; i++) {
			JPanel casilla = new JPanel();
			casilla.setBounds(cont7, 148, distancey, distancex);
			casilla.setLayout(new GridLayout(3,1,4,4));
			panel3.add(casilla);
			tableroCasillas.add(casilla);
			cont7 += distancey;
		}
		
		//Casillas 60-67
		int cont8 = 3;
		for (int i=1; i<9; i++) {
			JPanel casilla = new JPanel();
			casilla.setBounds(1, cont8, distancex, distancey);
			casilla.setLayout(new GridLayout(1,3,4,4));
			panel7.add(casilla);
			tableroCasillas.add(casilla);
			cont8 += distancey;
		}

		//Casilla 68
		JPanel casilla68 = new JPanel();
		casilla68.setBounds(73, 192, distancex, distancey);
		casilla68.setLayout(new GridLayout(1,3,4,4));
		panel7.add(casilla68);
		tableroCasillas.add(casilla68);
		
		//Casillas CasaAzul
		int cont9 = 163;
		for (int i=1; i<8; i++) {
			JPanel casilla = new JPanel();
			casilla.setBounds(cont9, 75, distancey, distancex);
			casilla.setLayout(new GridLayout(2,1,4,4));
			panel5.add(casilla);
			tableroCasillas.add(casilla);
			cont9 -= distancey;
		}

		JPanel casilla76 = new JPanel();
		tableroCasillas.add(casilla76); //No tiene nada
		
		//Casillas CasaRoja
		int cont10 = 31;
		for (int i=1; i<8; i++) {
			JPanel casilla = new JPanel();
			casilla.setBounds(73, cont10, distancex, distancey);
			casilla.setLayout(new GridLayout(1,2,6,6));
			panel1.add(casilla);
			tableroCasillas.add(casilla);
			cont10 += distancey;
		}
		JPanel casilla84 = new JPanel();
		tableroCasillas.add(casilla84); //No tiene nada
		
		//Casillas casaVerde
		int cont11 = 30;
		for (int i=1; i<8; i++) {
			JPanel casilla = new JPanel();
			casilla.setBounds(cont11, 75, distancey, distancex);
			casilla.setLayout(new GridLayout(2,1,6,6));
			panel3.add(casilla);
			tableroCasillas.add(casilla);
			cont11 += distancey;
		}
		JPanel casilla92 = new JPanel();
		tableroCasillas.add(casilla92); //No tiene nada
		
		//Casillas casaAmarilla
		int cont12 = 165;
		for (int i=1; i<8; i++) {
			JPanel casilla = new JPanel();
			casilla.setBounds(73, cont12, distancex, distancey);
			casilla.setLayout(new GridLayout(1,2,6,6));
			panel7.add(casilla);
			tableroCasillas.add(casilla);
			cont12 -= distancey;
		}
		JPanel casilla100 = new JPanel();
		tableroCasillas.add(casilla100); //No tiene nada
	} 
	
	/**
	 * Pinta las casillas especiales del tablero
	 */
	public void pintarComponentes() {
		tableroCasillas.get(60).setBackground(Color.MAGENTA);
		tableroCasillas.get(9).setBackground(Color.MAGENTA);
		tableroCasillas.get(26).setBackground(Color.MAGENTA);
		tableroCasillas.get(43).setBackground(Color.MAGENTA);
		tableroCasillas.get(12).setBackground(Color.LIGHT_GRAY);
		tableroCasillas.get(17).setBackground(Color.LIGHT_GRAY);
		tableroCasillas.get(29).setBackground(Color.LIGHT_GRAY);
		tableroCasillas.get(34).setBackground(Color.LIGHT_GRAY);
		tableroCasillas.get(46).setBackground(Color.LIGHT_GRAY);
		tableroCasillas.get(51).setBackground(Color.LIGHT_GRAY);
		tableroCasillas.get(63).setBackground(Color.LIGHT_GRAY);
		tableroCasillas.get(68).setBackground(Color.LIGHT_GRAY);
		tableroCasillas.get(5).setBackground(Color.YELLOW);
		tableroCasillas.get(22).setBackground(Color.BLUE);
		tableroCasillas.get(39).setBackground(Color.RED);
		tableroCasillas.get(56).setBackground(Color.GREEN);
		
		for(int i=1; i<tableroCasillas.size();i++) {
			tableroCasillas.get(i).setBorder(BorderFactory.createEtchedBorder());
			if(i>=1 && i<69) {
				String number = String.valueOf(i);
				JLabel etiqueta = new JLabel(number);
				etiqueta.setBounds(0,0, 15, 15);
				etiqueta.setFont(new Font("Bahnschrift SemiBold", Font.BOLD,10)); //Tipo letra
				tableroCasillas.get(i).add(etiqueta);
			}
			if(i>=69 && i<=76) {
				tableroCasillas.get(i).setBackground(Color.BLUE);
			}else if(i>=77 && i<= 84) {
				tableroCasillas.get(i).setBackground(Color.RED);
			}else if(i>=85 && i<= 92) {
				tableroCasillas.get(i).setBackground(Color.GREEN);
			}else if(i>=93 && i<= 100) {
				tableroCasillas.get(i).setBackground(Color.YELLOW);
			}
		}
	}
	
	/**
	 * Crea el tablero con las fichas
	 */
	public void iniciarTablero() {
		Tablero tableroJuego = currentGame.getTableroJuego();
		ArrayList<Jugador> jugadores = tableroJuego.getJugadores();
		for (Jugador jugador : jugadores) {
			Carcel carcel = jugador.getNido();
			Color color = jugador.getColor();
			for (Ficha ficha : carcel.getEncarceladas()) {
				JButton btnFicha = new JButton();
				btnFicha.setContentAreaFilled(false);
				btnFicha.setBorder(null);
				btnFicha.addActionListener(e -> actionChoose(ficha));
				impresora.pintarImagen(btnFicha, "./img/"+colorMap.get(color)+"/"+ficha.getTipo()+".png", 20, 20);
				if (color.equals(Color.BLUE)) {
					panel2.add(btnFicha);
				} else if (color.equals(Color.RED)) {
					panel0.add(btnFicha);
				} else if (color.equals(Color.YELLOW)) {
					panel8.add(btnFicha);
				} else if (color.equals(Color.GREEN)) {
					panel6.add(btnFicha);
				}
				fichas.add(btnFicha);
			}
		}
	}
	
	/**
	 * Determina el comportamiento de la ficha seleccionada
	 * @param ficha Ficha seleccionada
	 */
	public void actionChoose(Ficha ficha) {
		int valorAMover = 0;
		Ficha fichaAtraida = null;
		int valordados = instanceGameGui.movimientosRestantes();
		Dado dado = instanceGameGui.getDadoEscogido();
		if (ficha instanceof Aspiradora) {
			if (ficha.getPosicion() != 0 && ficha.getPoderUsado() > 0) {
				int resp = JOptionPane.showConfirmDialog(this, 
						"�Desea traer la ficha mas cercana a esta posicion?", 
						"Poder de la ficha", 
				        JOptionPane.YES_NO_OPTION);
				if (resp == JOptionPane.YES_OPTION) {
					ficha.poderUsado();
					fichaAtraida = currentGame.getTableroJuego().getFichaAtraida(ficha);
					if (fichaAtraida != null) {
						valorAMover = currentGame.getTableroJuego().valorAMoverFichaAtraida(fichaAtraida, ficha);
					}
				}
			}
		} else if (ficha instanceof Cohete) {
			if (ficha.getPosicion() != 0 && ficha.getPoderUsado() > 0) {
				int resp = JOptionPane.showConfirmDialog(null, 
						"�Desea ir al seguro mas cercano?", 
						"Poder de la ficha", 
				        JOptionPane.YES_NO_OPTION);
				if (resp == JOptionPane.YES_OPTION) {
					ficha.poderUsado();
					valorAMover = currentGame.getTableroJuego().getSeguroCercano(ficha);
				}
			}
		} 
		if (currentGame.getJugadorEnTurno().getTurnosJugdados() % 2 == 0) {
			for (Ficha fichaJugador : currentGame.getJugadorEnTurno().getFichas()) {
				if (fichaJugador instanceof Ventajosa) {
					instanceGameGui.jugar(fichaJugador, 3, dado);
				}
				
			}
		}
		if (valordados == 0) {
			JOptionPane.showMessageDialog(null, "Debes Escojer Un Dado","�Alerta!",1);
		} else {
			if (valorAMover > 0) {
				if (ficha instanceof Cohete) {
					instanceGameGui.jugar(ficha, valorAMover, dado);	
				} else if (ficha instanceof Aspiradora) {
					instanceGameGui.jugar(fichaAtraida, valorAMover, dado);
				}
				
			} else {
				instanceGameGui.jugar(ficha, valordados, dado);
			}
			instanceGameGui.refreshStats();
			refresh();
		}
	}
	
	/**
	 * Actualiza visualmente el estado el juego
	 */
	public void refresh() {
		Tablero tableroJuego = currentGame.getTableroJuego();
		Casilla[] casillas = tableroJuego.getRegilla();
		ArrayList<Ficha> fichasDeJuego = tableroJuego.getFichas();
		ArrayList<Ficha> fichas = tableroJuego.getFichas();
		for (int i= 0; i < fichas.size(); i++) {
			int posFichaDom = fichas.get(i).getPosicion();
			JButton fichaVista = this.fichas.get(i);
			if (posFichaDom == 0) {
				Color colorFicha = fichas.get(i).getColor();
				if (colorFicha.equals(Color.BLUE)) {
					panel2.add(fichaVista);
				} else if (colorFicha.equals(Color.RED)) {
					panel0.add(fichaVista);
				} else if (colorFicha.equals(Color.YELLOW)) {
					panel8.add(fichaVista);
				} else if (colorFicha.equals(Color.GREEN)) {
					panel6.add(fichaVista);
				}
 			} else if (posFichaDom == 76 || posFichaDom == 84 || posFichaDom == 92 || posFichaDom == 100) {
 				panel4.add(fichaVista);
		    }else {
		    	if (fichas.get(i) instanceof Ingeniera && casillas[posFichaDom].getTipo().equals("Seguro")) {
					tableroCasillas.get(posFichaDom).setBackground(Color.LIGHT_GRAY);
				}
				tableroCasillas.get(posFichaDom).add(fichaVista);	
			}
		}
		repaint();
	}
	
	/**
	 * Pinta a cada casilla su numero 
	 */
	public void etiquetas() {
		for(int i=1; i<tableroCasillas.size();i++) {
			tableroCasillas.get(i).setBorder(BorderFactory.createEtchedBorder());
			if(i>=1 && i<69) {
				String number = String.valueOf(i);
				JLabel etiqueta = new JLabel(number);
				etiqueta.setBounds(0,0, 15, 15);
				etiqueta.setFont(new Font("Bahnschrift SemiBold", Font.BOLD,10)); //Tipo letra
				tableroCasillas.get(i).add(etiqueta);
			}
		}
	}
	
	/**
	 * Actualiza el juego
	 * @param juego Un juego de poobchis.
	 */
	public void actualizarJuego(Poobchis juego) {
		this.currentGame = juego;
		panel0.removeAll();
		panel2.removeAll();
		panel6.removeAll();
		panel8.removeAll();
		for (JPanel casilla : tableroCasillas) {
			casilla.removeAll();
		}
		etiquetas();
		fichas = new ArrayList<JButton>();
		for (Ficha ficha : juego.getTableroJuego().getFichas()) {
			Color color = ficha.getColor();
			JButton btnFicha = new JButton();
			btnFicha.setContentAreaFilled(false);
			btnFicha.setBorder(null);
			btnFicha.addActionListener(e -> actionChoose(ficha));
			impresora.pintarImagen(btnFicha, "./img/"+colorMap.get(color)+"/"+ficha.getTipo()+".png", 20, 20);
			if (color.equals(Color.BLUE)) {
				panel2.add(btnFicha);
			} else if (color.equals(Color.RED)) {
				panel0.add(btnFicha);
			} else if (color.equals(Color.YELLOW)) {
				panel8.add(btnFicha);
			} else if (color.equals(Color.GREEN)) {
				panel6.add(btnFicha);
			}
			fichas.add(btnFicha);
		}
	}
	
	public static ArrayList<JButton> getBotonesFichas() {
		return fichas;
	}
	
	/**
	 * Clase que pinta el panel central.
	 */
	public class TriangleTablero extends JPanel {
		
		private PaintPicture impresora; 
		
		public TriangleTablero() {
			impresora = PaintPicture.getPrinter();
			JLabel corona = new JLabel();
			setLayout(null);
			corona.setBounds(80,80,60,60);
			impresora.pintarImagen(corona, "./img/corona.png", 60, 60);
			add(corona);
		}
		@Override
		public void paintComponent(Graphics g) {
			super.paintComponent(g);
			int[] xpositions = {0,110,220};
			int[] ypositions = {0,110,0};
			g.setColor(Color.RED);
			g.fillPolygon(xpositions, ypositions, 3);
			
			int[] xpositions2 = {220,110,220};
			int[] ypositions2 = {0,110,220};
			g.setColor(Color.BLUE);
			g.fillPolygon(xpositions2, ypositions2, 3);
			
			int[] xpositions3 = {0,110,220};
			int[] ypositions3 = {220,110,220};
			g.setColor(Color.YELLOW);
			g.fillPolygon(xpositions3, ypositions3, 3);
			
			int[] xpositions4 = {0,110,0};
			int[] ypositions4 = {0,110,220};
			g.setColor(Color.GREEN);
			g.fillPolygon(xpositions4, ypositions4, 3);

		}
	}
}
	