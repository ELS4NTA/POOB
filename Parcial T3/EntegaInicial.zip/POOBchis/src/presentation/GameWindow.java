package presentation;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import domain.Dado;
import domain.Jugador;
import domain.Poobchis;
import domain.PoobchisException;
import domain.fichas.Ficha;

/**
 * Clase que crea la ventana del juego
 * @author Angie Mojica - Daniel Santanilla.
 * @version 0.4
 */
public class GameWindow {
	private TableroGUI tablero;
	private CardLayout card;
	private POOBchisGUI gui;
	private Poobchis currentGame;
	private JPanel principal;
	private JLabel fondoGW, jugadorEnTruno, lblnombre,lblcolor, lblcoronadas,
	lblcarcel, visual, coronadas, enCarcel, nombre;
	private JButton lanzar, color;
	private PaintPicture impresora;
	private int movimientosRestantes;
	private Dado dadoEscogido;
	private ArrayList<JButton> dadosBoton;
	private boolean seLanza;
	
	/**
	 * Constructor de la ventana de juego
	 * @param gui Ventana principal
	 * @param game Juego a mostrar
	 */
	public GameWindow(POOBchisGUI gui, Poobchis game) {
		dadosBoton = new ArrayList<JButton>();
		this.gui = gui;
		seLanza = false;
		currentGame = game;
		card = gui.getCard();
		principal = gui.getPrincipal();
		impresora = PaintPicture.getPrinter();
		prepareElements();
		prepareSizes();
		prapareImages();
		addComponents();
		prepareActions();
	}

	/**
	 * Prepara los componentes a mostrar en la ventana
	 */
	public void prepareElements() {
		Jugador jugador = currentGame.getJugadorEnTurno();
		String nombreJ = jugador.getNombre();
		Color colorJ = jugador.getColor();
		String coronadasJ = jugador.getFichasCoronadas()+"";
		String enCarcelJ = jugador.getNido().getTamanno()+"";
		tablero = new TableroGUI(currentGame, this);
		fondoGW = new JLabel();
		fondoGW.setVisible(true);
		lanzar = new JButton();
		jugadorEnTruno = new JLabel();
		lblnombre = new JLabel();
		lblcolor = new JLabel();
		lblcoronadas = new JLabel();
		lblcarcel = new JLabel();
		visual = new JLabel();
		nombre = new JLabel(nombreJ);
		color = new JButton();
		color.setBackground(colorJ);
		coronadas = new JLabel(coronadasJ);
		enCarcel = new JLabel(enCarcelJ);
		prepareDices();
	}
	
	/**
	 * Prepara los dados que se usaran para jugar
	 */
	public void prepareDices() {
		for (int i = 0; i < 2; i++) {
			int id = i;
			JButton dado = new JButton();
			dado.setBounds(730+140*i, 500, 112, 112);
			impresora.pintarImagen(dado, "./img/dado/blanco.png", 105, 105);
			dado.addActionListener(e -> actionPlay(id));
			fondoGW.add(dado);
			dadosBoton.add(dado);
		}
	}
	
	/**
	 * Modifica los tamannos de cada componente
	 */
	public void prepareSizes() {
		fondoGW.setBounds(0, 0, 1080, 720);
		lanzar.setBounds(770, 400, 187, 82);
		lanzar.setContentAreaFilled(false);
		lanzar.setBorder(null);
		visual.setBounds(0, 0, 660, 660);
		jugadorEnTruno.setBounds(760, 0, 251, 151);
		lblnombre.setBounds(690, 150, 146, 62);
		lblcolor.setBounds(690, 200, 121, 59);
		lblcoronadas.setBounds(690, 250, 196, 66);
		lblcarcel.setBounds(690, 300, 144, 67);
		nombre.setBounds(830, 165, 130, 30);
		color.setBounds(810, 210, 30, 30);
		coronadas.setBounds(880, 265, 130, 30);
		enCarcel.setBounds(830, 320, 130, 30);
		nombre.setFont(new Font("arial",1,20));
		coronadas.setFont(new Font("arial",1,20));
		enCarcel.setFont(new Font("arial",1,20));
		coronadas.setForeground(Color.WHITE);
		enCarcel.setForeground(Color.WHITE);
		nombre.setForeground(Color.WHITE);
		color.setEnabled(false);
	}

	/**
	 * Prepara las imagenes para los componentes de la ventana
	 */
	public void prapareImages() {
		impresora.pintarImagen(fondoGW, "./img/fondoPrincipal.jpg", 1080, 720);
		impresora.pintarImagen(lanzar, "./img/lanzar.png", 187, 82);
		impresora.pintarImagen(jugadorEnTruno, "./img/enturno.png", 251, 151);
		impresora.pintarImagen(lblnombre, "./img/nombre.png", 146, 62);
		impresora.pintarImagen(lblcolor, "./img/color.png", 121, 59);
		impresora.pintarImagen(lblcoronadas, "./img/coronadas.png", 196, 66);
		impresora.pintarImagen(lblcarcel, "./img/carcel.png", 144, 67);
	}

	/**
	 * Agrega cada componente a la etiqueta principal 
	 */
	public void addComponents() {
		fondoGW.add(tablero);
		fondoGW.add(lanzar);
		fondoGW.add(jugadorEnTruno);
		fondoGW.add(lblnombre);
		fondoGW.add(lblcolor);
		fondoGW.add(lblcoronadas);
		fondoGW.add(lblcarcel);
		fondoGW.add(nombre);
		fondoGW.add(color);
		fondoGW.add(coronadas);
		fondoGW.add(enCarcel);
		fondoGW.add(tablero);
		principal.add(fondoGW, "FondoGW");
	}
	
	/**
	 * Obtiene los movimientos restantes
	 * @return Dado seleccionado en el juego.
	 */
	public Integer movimientosRestantes() {
		return movimientosRestantes;
	}
	
	/**
	 * Se otbtiene el dado ecogido por el boton presiondo.
	 * @return Dado escogido.
	 */
	public Dado getDadoEscogido() {
		return dadoEscogido;
	}
	
	/**
	 * Prepara las acciones de cada boton.
	 */
	public void prepareActions() {
		lanzar.addActionListener( new ActionListener(){
			public void actionPerformed( ActionEvent event) {
				actionDiceThrow();
				} 
		});
	}
	
	/**
	 * Asigna los movimientos restantes.
	 * @param valor Entero con valor de un dado
	 */
	public void actionPlay(int id) {
		ArrayList<Dado> dados = currentGame.getTableroJuego().getDados();
		Dado dado = dados.get(id);
		if (!dado.seHaJugado()) {
			movimientosRestantes = dados.get(id).getValor();
			dadoEscogido = dados.get(id);
		} else {
			JOptionPane.showMessageDialog(null, "Ya seleccionaste este dado.","�Cuidado!",2);
		}
	}
	
	/**
	 * Determina la accion de lanzar los dados
	 */
	public void actionDiceThrow() {
		if (!seLanza) {
			seLanza = true;
			currentGame.lanzarDados();
			ArrayList<Dado> dados = currentGame.getTableroJuego().getDados();
			for (int i = 0; i < 2; i++) {
				JButton dado = dadosBoton.get(i);
				Dado dadoJuego = dados.get(i);
				movimientosRestantes += dadoJuego.getValor();
				dado.setBackground(currentGame.getJugadorEnTurno().getColor());
				impresora.pintarImagen(dado, "./img/dado/dado"+dadoJuego.getValor()+".png", 105, 105);
			}
			if (!currentGame.sePuedenJugarLosDados()) {
				if (!currentGame.getTableroJuego().esPar()) {
					currentGame.cambiarTurno();
					seLanza = false;
				} else {
					seLanza = false;
				}
				refreshStats();
			}
			currentGame.getTableroJuego().reiniciaDados();
		}
	}
	
	/**
	 * Realiza el la accion de jugar.
	 * @param ficha Ficha a mover.
	 * @param valor Valor de casillas a mover.
	 */
	public void jugar(Ficha ficha, int valor, Dado dado) {
		if (!currentGame.aunExisteJugadas()) {
			currentGame.cambiarTurno();
			seLanza = false;
		} else {
			if (currentGame.castigoTriplePar(currentGame.getJugadorEnTurno(), ficha)) {
				JOptionPane.showMessageDialog(null, "Obtienes un castigo por obtener un triple par.","Mala Suerte",1);
				currentGame.getJugadorEnTurno().setCantPares(0);
				currentGame.cambiarTurno();
				seLanza = false;
			} else if (currentGame.esPosibleJugar(valor)) {
				try {
					movimientosRestantes = currentGame.jugar(ficha, valor);
					dado.setSeHaJugado(true);
					if (currentGame.ganador()) {
						JOptionPane.showMessageDialog(null, "El ganador es: "+currentGame.getJugadorEnTurno().getNombre(),"Felicidades",1);
						card.show(principal, "FondoPW");
					} else if (movimientosRestantes == 20) {
						JOptionPane.showMessageDialog(null, "Has obtenido un premio por capturar una ficha, escoge tu ficha a mover.","Felicidades",1);
					} else if (movimientosRestantes == 10 ) {
						JOptionPane.showMessageDialog(null, "Has obtenido un premio por coronar una ficha, escoge tu ficha a mover.","Felicidades",1);
					}
				} catch (PoobchisException pe) {
					if (pe.getMessage() == PoobchisException.NO_ES_TU_FICHA) {
						JOptionPane.showMessageDialog(null,  pe.getMessage(),"�Alerta!",2);
					} else if (pe.getMessage() == PoobchisException.NO_SE_PUEDE_MOVER) {
						JOptionPane.showMessageDialog(null, pe.getMessage(),"�Alerta!",2);
					} else if (pe.getMessage() == PoobchisException.FICHA_EN_CARCEL) {
						JOptionPane.showMessageDialog(null, pe.getMessage(),"�Alerta!",2);
					}
				}
				if (movimientosRestantes == 0 && !currentGame.getTableroJuego().esPar()) {
					currentGame.getJugadorEnTurno().setCantPares(0);
					currentGame.cambiarTurno();
					seLanza = false;
				} else if (currentGame.getTableroJuego().esPar()) {
					currentGame.getJugadorEnTurno().aumentaCantPares();
					seLanza = false;
				}
			}
			refreshStats();
			tablero.refresh();
		}
	}
	

	/**
	 * Actualiza la informacion de cada jugador.
	 */
	public void refreshStats() {
		Jugador jugador = currentGame.getJugadorEnTurno();
		String nombreJ = jugador.getNombre();
		Color colorJ = jugador.getColor();
		String coronadasJ = jugador.getFichasCoronadas()+"";
		String enCarcelJ = jugador.getNido().getTamanno()+"";
		nombre.setText(nombreJ);
		color.setBackground(colorJ);
		coronadas.setText(coronadasJ);
		enCarcel.setText(enCarcelJ);
	}
	
	/**
	 * Detiene el hilo con los segundos indicados
	 * @param seconds Entero con la cantidad de segundos a deter el hilo.
	 */
	private void sleep(int seconds) {
		int miliseconds = seconds*1000;
		try {
			Thread.sleep(miliseconds);
		} catch (InterruptedException e) {
			System.out.println("No se pudo detener la ejecucion del hilo");
			e.printStackTrace();
		}
	}
	
	/**
	 * Obtiene el tablero visual.
	 * @return Interfaz del tablero. 
	 */
	public TableroGUI getTablero() {
		return tablero;
	}
	
	/**
	 * Actualiza el juego.
	 * @param juego Nuevo juego.
	 */
	public void actualizarJuego(Poobchis juego) {
		this.currentGame = juego;
	}
	
	/**
	 * Actualiza el tablero.
	 * @param tablero Nuevo tablero visual.
	 */
	public void actualizarTablero(TableroGUI tablero) {
		this.tablero = tablero;
	}
}
