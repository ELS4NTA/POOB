package domain;
import java.awt.Color;
import java.io.Serializable;
import java.util.*;

import domain.fichas.Ficha;
/**
 * Clase que representa a un Jugador
 * @author Angie Mojica - Daniel Santanilla
 * @version 0.4
 */
public class Jugador implements Serializable {
	
	private int identificador;
	private boolean esHumano;
	private boolean enTurno;
	private Color color;
	private String nombre;
	private int fichasCoronadas;
	private ArrayList<Ficha> fichas = new ArrayList<Ficha>();
	private Carcel nido;
	private int cantPares;
	private int[] valorEnDados;
	private int numTurnos;
	
	/**
	 * Constructor del jugador
	 * @param nombre Nombre del jugador
	 * @param color Color del equipo del jugador
	 * @param equipo Lista de tipos de fichas para el juego
	 * @param humano True si es jugador, false si es maquina
	 * @param identi Numero que identifica el jugador.
	 * @param turno Indica si el jugador esta actualmente en turno.
	 */
	public Jugador(String nombre, Color color, List<String> equipo,boolean humano, int identi, boolean turno) {
		this.numTurnos = 0;
		this.esHumano = humano;
		this.enTurno = turno;
		this.identificador = identi;
		this.color = color;
		this.fichasCoronadas = 0;
		this.nombre = nombre;
		for (int i = 0; i < equipo.size(); i++) {
			try {
				fichas.add((Ficha) Class.forName("domain.fichas."+equipo.get(i)).getDeclaredConstructor(Color.class).newInstance(color));
			} catch (Exception e) {
				System.out.println("No se pudo crear una ficha");
				e.printStackTrace();
			}
		}
		this.nido = new Carcel(fichas);
		
	}
	
	/**
	 * Verifica si el jugador es humano o no.
	 * @return True si el jugador es humano, 
	 * de lo contrario False es decir es maquina.
	 */
	public boolean esHumano() {
		return this.esHumano;
	}
	
	/**
	 * Annade una ficha coronada al contador de fichas coronadas.
	 */
	public void fichaCoronada() {
		this.fichasCoronadas = this.fichasCoronadas + 1;
	}
	
	/**
	 * Obtiene la cantidad de fichas coronadas por el jugador
	 * @return Entero con la cantidad de fichas coronadas
	 */
	public int  getFichasCoronadas() {
		return this.fichasCoronadas;
	}
	
	/**
	 * Verifica si un jugador esta en turno.
	 * @return True si esta en turno, de lo contrario False.
	 */
	public boolean estaEnTurno() {
		return this.enTurno;
	}
	
	/**
	 * Actualiza el turno del jugador.
	 * @param turno Nuevo estado del turno.
	 */
	public void setTurno(boolean turno) {
		this.enTurno = turno;
	}
	
	/**
	 * Obtiene el identificador del jugador
	 * @return Entero que indica el numero de jugador en el tablero.
	 */
	public int getIdentificador() {
		return this.identificador;
	}
	
	/**
	 * Obtiene el nombre del jugador
	 * @return Cadena con el nombre del jugador
	 */
	public String getNombre() {
		return this.nombre;
	}
	
	/**
	 * Obtiene el color del jugador.
	 * @return Color que identifica al jugador.
	 */
	public Color getColor() {
		return this.color;
	}
	
	/**
	 * Obtiene la carcel del jugador.
	 * @return Carcel del jugador.
	 */
	public Carcel getNido() {
		return this.nido;
	}
	
	/**
	 * Obtiene las fichas del jugador.
	 * @return Lista de las fichas del jugador.
	 */
	public ArrayList<Ficha> getFichas() {
		return this.fichas;
	}
	
	/**
	 * Actualiza la cantidad de pares del jugado.r
	 * @param nuevaCantPar Nuevo valor de cantidad de pares
	 */
	public void setCantPares(int nuevaCantPar) {
		cantPares = nuevaCantPar;
	}
	
	/**
	 * Aumenta la canidad de pares del jugador en el contador de pares.
	 * */
	public void aumentaCantPares() {
		cantPares += 1;
	}
	
	/**
	 * Obtiene la cantidad de pares que lleva el jugador
	 * @return Cantidad de pares que lleva el jugador.
	 */
	public int getCantPares() {
		return cantPares;
	}
	
	/**
	 * Obtiene el numero de turnos jugados por el jugador.
	 * @return Entero con la cantidad de turnos jugados. 
	 */
	public int getTurnosJugdados() {
		return numTurnos;
	}
	
	/**
	 * Aumenta la cantidad de turnos jugador por el jugador.
	 */
	public void aumentaTurno() {
		this.numTurnos += 1;
	}
	
}
