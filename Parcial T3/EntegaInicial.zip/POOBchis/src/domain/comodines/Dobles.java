package domain.comodines;

import java.io.Serializable;

import domain.Poobchis;
import domain.fichas.Ficha;

/**
 * Clase que representa un {@link Comodin} Dobles 
 * @author Angie Mojica - Daniel Santanilla
 * @version 0.4
 */
public class Dobles extends Comodin implements Serializable{
	
	/**
	 * El jugador duenno de la ficha a la que le sale este comodin, 
	 * tendra un turno adicional, es decir, podra jugar de nuevo los dados.
	 * Ver tammbien {@inheritDoc}
	 */
	@Override
	public void especial(Poobchis currentGame, Ficha ficha) {
		// TODO Auto-generated method stuba
		
	}

}
