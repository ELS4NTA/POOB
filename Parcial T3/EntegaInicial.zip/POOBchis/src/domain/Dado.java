package domain;

import java.io.Serializable;

/**
 * Clase que representa un dado en el tablero.
 * @author Angie Mojica - Daniel Santanilla
 * @version 0.4
 */
public class Dado implements Serializable{
	
	private int valor;
	private boolean seHaJugado;
	
	/**
	 * Constructor de la clase dado.
	 */
	public Dado () {}
	
	/**
	 * Se el dado y se obtiene un valor al azar.
	 */
	public void lanzar() {
		int valorDado = (int)(Math.random()*6+1);
		setValor(valorDado);
	}
	
	/**
	 * Obtiene el valor actual del dado.
	 * @return Entero con el valor del dado.
	 */
	public int getValor() {
		return valor;
	}

	/**
	 * Se asigna un valor al dado.
	 * @param valor Entero con el nuevo valor de dado.
	 */
	public void setValor(int valor) {
		this.valor = valor;
	}

	/**
	 * Indica si se ha jugado el dado.
	 */
	public boolean seHaJugado() {
		return seHaJugado;
	}
	
	/**
	 * Se asigna el valor indicar si el dado se ha jugado.
	 * @param seHaJugado True si el dado ya se uso, de lo contrario False.
	 */
	public void setSeHaJugado(boolean seHaJugado) {
		this.seHaJugado = seHaJugado;
	}
	
}
