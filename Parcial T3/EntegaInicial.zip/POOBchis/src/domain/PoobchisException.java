package domain;

import java.io.Serializable;

/**
 * Excepciones presentadas en el juego.
 * @author Angie Mojica - Daniel Santanilla.
 * @version 0.4
 */
public class PoobchisException  extends Exception implements Serializable{
	
	public static final String NO_ES_TU_FICHA = "No es tu ficha, selecciona la correcta."; 
	public static final String NO_SE_PUEDE_MOVER = "No se puede mover, selecciona una ficha correcta.";
	public static final String FICHA_EN_CARCEL = "Ficha en la carcel, selecciona una correcta.";
	public static final String ARCHIVO_NO_ENCONTRADO = "Archivo no encontrado.";
	public static final String EXCEDIDA_PERSONALIZADAS = "Se ha excedido la cantidad de fichas perzonalizadas.";
	
	public PoobchisException(String message) {
		super(message);
	}
	
}
