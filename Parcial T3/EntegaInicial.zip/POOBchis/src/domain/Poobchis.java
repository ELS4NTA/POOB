
package domain;
import java.awt.Color;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.*;

import domain.fichas.Ficha;

/**
 * Clase que representa el juego Poobchis
 * @author Angie Mojica - Daniel Santanilla
 * @version 0.4
 */
public class Poobchis implements Serializable {
	
	private Tablero tablero;
	private Jugador enTurno;
	private ArrayList<Jugador> jugadores = new ArrayList<Jugador>();
	private Poobchis juego;
	
	/**
	 * Constructor del juego
	 * @param nombres Lista de los nombres de los jugadores.
	 * @param colores Lista de los colores que identifca a cada jugador.
	 * @param fichas Lista de fichas del jugador.
	 * @param comodines Lista de comodines que se usaran en el tablero.
	 */
	public Poobchis(List<String> nombres, List<Color> colores, List<String> fichas, List<String> comodines) {
		for (int i = 0; i < nombres.size(); i++) {
			if (i==0) {
				jugadores.add(new Jugador(nombres.get(i),colores.get(i),fichas,true,i,true));
				enTurno = jugadores.get(i);
				if (nombres.size()==1) {
					jugadores.add(new Jugador("Maquina",colores.get(i),fichas,false,i,false));
				}
			} else {
				jugadores.add(new Jugador(nombres.get(i),colores.get(i),fichas,true,i,false));
			}
		}
		tablero = new Tablero(jugadores, comodines);
	}
	
	/**
	 * Hace que un jugador lance los dados.
	 * @param jugador Jugador que hara la accion.
	 * @return Array con los valores de los dados.
	 */
	public void lanzarDados() {
		tablero.lanzarDados();
	}

	/**
	 * Realiza el movimiento de la ficha segun el valor del dado.
	 * @param ficha Ficha que se quiere mover.
	 * @param valorDado Cantidad de casillas a mover la ficha.
	 * @return Movimientos restantes que tiene el jugador, ya sea por matar o coronar ficha.
	 * @throws PoobchisException NO_ES_TU_FICHA Cuando el jugador selecciona una ficha incorrecta.
	 * @throws PoobchisException FICHA_EN_CARCEL Cuando la ficha selecciona no ha salido de la carcel.
	 */
	public int jugar(Ficha ficha,int valorDado) throws PoobchisException {
		Jugador jugador = getJugadorEnTurno();
		ArrayList<Ficha> fichas = jugador.getFichas();
		ArrayList<Ficha> enCarcel = jugador.getNido().getEncarceladas();
		if (!fichas.contains(ficha)) {
			throw new PoobchisException(PoobchisException.NO_ES_TU_FICHA);
		}
		if (valorDado == 5) {
			if (!jugador.getNido().estaVacia()) {
				if (enCarcel.contains(ficha)) {
					return sacarFicha(jugador, ficha);
				} else {
					if (sacarFicha(jugador,enCarcel.get(0)) == 5) {
						Casilla ultima = ficha.mover(jugador, ficha, valorDado, tablero);
						if (tablero.comer(ultima, jugador)) {
							return movimientosExtra(true, false);
						}
					}
				}	
			} else {
				Casilla ultima = ficha.mover(jugador, ficha, valorDado, tablero);
				if (tablero.comer(ultima, jugador)) {
					return movimientosExtra(true, false);
				}
				if (ultima.equals(tablero.getCasilla(ficha.getLlegada()))) {
					jugador.fichaCoronada();
					ultima.quitarFicha(ficha);
					return movimientosExtra(false, true);
				}
			}
		} else {
			if(enCarcel.contains(ficha)) {
				throw new PoobchisException(PoobchisException.FICHA_EN_CARCEL);
			}
			Casilla ultima = ficha.mover(jugador, ficha, valorDado, tablero);
			if (ultima.getTipo().equals("Comodin")) {
				if (ultima.getComodin() != null) {
					ultima.getComodin().especial(this, ficha);
				}
			}
			if (tablero.comer(ultima, jugador)) {
				return movimientosExtra(true, false);
			}
			if (ultima.equals(tablero.getCasilla(ficha.getLlegada()))) {
				jugador.fichaCoronada();
				ultima.quitarFicha(ficha);
				return movimientosExtra(false, true);
			}
		}
		return 0;
	}
	
	/** 
	 * Verifica si un jugador merece el castigo de obtener triple par
	 * @param jugador Jugador que se quiere verificar
	 * @param ficha Ficha ultima movida, a la que se le aplica el castigo
	 * @return True si tiene el castigo, de lo contrario False.
	 */
	public boolean castigoTriplePar(Jugador jugador, Ficha ficha) {
		if (jugador.getCantPares() == 3) {
			int posCasilla = ficha.getPosicion();
			Casilla casilla = tablero.getCasilla(posCasilla);
			casilla.quitarFicha(ficha);
			ficha.setPosicion(0);
			jugador.getNido().addFicha(ficha);
			jugador.setCantPares(0);
			return true;
		}
		return false;
	}
	
	/**
	 * Saca una ficha de la carcel.
	 * @param jugador Jugador que puede sacar ficha de la carcel.
	 * @param ficha Ficha a sacar de la carcel.
	 * @return Entero con los movimientos restantes luego de sacar o no la ficha.
	 */
	public int sacarFicha(Jugador jugador, Ficha ficha) {
		Casilla salida = tablero.casillaSalida(jugador);
		Jugador oponente = tablero.jugadorOpuesto(salida, jugador);
		Ficha sacada = ficha;
		int cantFichas = salida.contarMisFichas(jugador);
		if (salida.catidadFichas() <= 1) {
			jugador.getNido().quitarFicha(ficha);
			sacada.setPosicion(salida.getPosicion());
			salida.addFicha(sacada);
		} else if (salida.catidadFichas() == 2) {
			if (cantFichas == 2) {
				return movimientosExtra(false,false);
			} else {
				Ficha aMatar = salida.obtenerFicha(oponente);
				aMatar.setPosicion(0);
				salida.quitarFicha(aMatar);
				oponente.getNido().addFicha(aMatar);
				jugador.getNido().sacarFicha();
				sacada.setPosicion(salida.getPosicion());
				salida.addFicha(sacada);
				return movimientosExtra(true,false);
			}
		}
		return 0;
	}
	
	/**
	 * Asigna los movimientos restantes de un jugador luego de mover
	 * @param seCome Indica si se comio una ficha.
	 * @param seCorona Indica si se corona una ficha
	 * @return Entero con los movimientos ganados por matar, coronar o restantes
	 */
	public int movimientosExtra(boolean seCome, boolean seCorona){
		if (seCome) {
			return 20;
		} else if (seCorona) {
			return 10;
		} else {
			return 5;
		}
	}
	
	/**
	 * Cambia el turno del jugador y le asigna un turno al siguiente.
	 */
	public void cambiarTurno() {
		if (tablero.numeroDadosJugados() == 2) {
			enTurno.aumentaTurno();
			enTurno.setTurno(false);
			if (enTurno.equals(jugadores.get(jugadores.size()-1))) {
				enTurno = jugadores.get(0);
			} else {
				enTurno = jugadores.get(jugadores.indexOf(enTurno)+1);
			}
			enTurno.setTurno(true);
			tablero.reiniciaDados();
		}
	}
	
	/**
	 * Obtiene el jugador en turno.
	 * @return Jugador en turno.
	 */
	public Jugador getJugadorEnTurno() {
		for (Jugador jugador : jugadores) {
			if (jugador.estaEnTurno()) {
				enTurno = jugador;
			}
		}
		return enTurno;
	}
	
	/**
	 * Verifica si existe almenos una ficha que se pueda mover con el valor del dado obtenido
	 * @param jugador Jugador que desea jugar.
	 * @param valorDado Movimientos a relizar.
	 * @return True si existe alguna ficha a mover, false de lo contrario.
	 */
	public boolean algunaSeMueve(Jugador jugador, int valorDado) {
		ArrayList<Ficha> fichas = jugador.getFichas();
		for (Ficha ficha : fichas) {
			if (!jugador.getNido().getEncarceladas().contains(ficha)) {
				if (ficha.sePuedeMover(ficha, valorDado, tablero)) {
					return true;
				} 
			} else {
				if (valorDado == 5) {
					if (ficha.puedeSalir(ficha, jugador, tablero)) {
						return true;
					}
				}
			}
		}
		return false;	
	}
	
	/**
	 * Verifica si ya existe un ganador de partida.
	 * @return True si ya hay ganador, false sino.
	 */
	public boolean ganador() {
		if (getJugadorEnTurno().getFichasCoronadas() == 4) {
			return true;
		}
		return false;
	}
	
	/**
	 * Obtiene el tablero.
	 * @return tablero de juego.
	 */
	public Tablero getTableroJuego() {
		return this.tablero;
	}
	
	/**
	 * Guarda el estado del juego
	 * @param archivo Archivo donde se guardara
	 * @throws PoobchisException ARCHIVO_NO_ENCONTRADO En caso de que no se encuentre el archivo en la raiz.
	 */
    public void guarde(File archivo) throws PoobchisException {
    	try {
    		ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(archivo));
    		out.writeObject(this);
    		out.close();
		} catch (Exception e) {
			System.out.println("No se pudo guardar el archivo");
            e.printStackTrace();
		}
    }
    
    /**
     * Abre el archivo donde esta el estado del juego
     * @param archivo Archivo para leer.
     * @return Juego guardado
     * @throws PoobchisException ARCHIVO_NO_ENCONTRADO En caso de que no se encuentre el archivo en la raiz.
     */
    public static Poobchis abra(File archivo) throws PoobchisException {
    	Poobchis juego = null;
    	try {
            if(!archivo.exists()){
            	throw new PoobchisException(PoobchisException.ARCHIVO_NO_ENCONTRADO);
            }
    		ObjectInputStream in = new ObjectInputStream(new FileInputStream(archivo));
    		juego = (Poobchis) in.readObject();
    		in.close();
		} catch (Exception e) {
			throw new PoobchisException(PoobchisException.ARCHIVO_NO_ENCONTRADO);
		}
    	return juego;
    }
	
    /**
	 * Determina si es posible jugar, si alguna ficha se mueve.
	 * @param valor Valor a mover
	 * @return True si alguna ficha se mueve, false de lo contrario.
	 */
	public boolean esPosibleJugar(int valor) {
		if (algunaSeMueve(getJugadorEnTurno(), valor)) {
			return true;
		}
		return false;
	}
	
	public boolean sePuedenJugarLosDados() {
		ArrayList<Dado> dados = tablero.getDados();
		int cont = 0;
		for (Dado dado : dados) {
			if (!esPosibleJugar(dado.getValor())) {
				cont += 1;
				dado.setSeHaJugado(true);
			}
		}
		if (cont == 2) {
			return false;
		}
		return true;
	}
	
	public boolean aunExisteJugadas() {
		for (Dado dado : tablero.getDados()) {
			if (tablero.numeroDadosJugados() == 1) {
				if (!esPosibleJugar(dado.getValor())) {
					dado.setSeHaJugado(true);
					return false;
				}
 			}
		}
		return true;
	}
}
