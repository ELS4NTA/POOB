package domain.fichas;

import java.awt.Color;
import java.io.Serializable;

import domain.Casilla;
import domain.Tablero;

/**
 * Clase que representa a una {@link Ficha} Saltarina\n
 * Esta ficha puede saltar los bloqueos que est�n en el camino, es decir, 
 * avanzara lacantidad en los dados sin importar los bloqueos formados
 * @author Angie Mojica - Daniel Santanilla.
 * @Version 0.4
 */
public class Saltarina extends Ficha implements Serializable{
	
	/**
	 * Constructor de la ficha
	 * @param color Color de la ficha.
	 */
	public Saltarina(Color color) {
		super(color);
	}
	
	/**
	 * Verifica si una ficha se puede mover el valor de casillas indicado por el dado,
	 * este movimiento se salta bloqueos debido a su poder de ficha.
	 * Ver tambien {@inheritDoc}
	 */
	@Override
	public boolean sePuedeMover(Ficha ficha, int valorAMover, Tablero tablero) {
		Casilla actual = tablero.getCasilla(ficha.getPosicion());
		int llegada = ficha.getLlegada();
		while (valorAMover > 0) {
			if (actual.getPosicion() != llegada) {
				Casilla siguiente = tablero.siguienteCasilla(actual, ficha.getColor());
				actual = siguiente;
			} else {
				return false;
			}
			valorAMover -= 1;
		}
		if (actual.catidadFichas() == 2) {
			return false;
		}
		return true;
	}
	
	/**
	 * Ver tambien {@inheritDoc}
	 */
	@Override
	public String getTipo() {
		return "Saltarina";
	}
}
