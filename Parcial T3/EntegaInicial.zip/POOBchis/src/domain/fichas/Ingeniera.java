package domain.fichas;
import java.awt.Color;
import java.io.Serializable;

import domain.Casilla;
import domain.Jugador;
import domain.PoobchisException;
import domain.Tablero;

/**
 * Clase que representa a una {@link Ficha} Ingeniera\n
 * Su poder es convertir la casilla donde cae en casilla segura, 
 * dicha casilla ser� segura paratodas las dem�s fichas.
 * @author Angie Mojica - Daniel Santanilla
 * @Version 0.4
 */
public class Ingeniera extends Ficha implements Serializable{
	
	/**
	 * Crea una ficha Ingeniera
	 * @param color Color de la ficha
	 */
	public Ingeniera(Color color) {
		super(color);
	}
	
	/**
	 * Mueve la ficha en el tablero el valor indicado y actualiza el tipo de casilla,
	 * dado que esta tiene la regla de que construye seguros en cada movimiento,
	 * Ver tambien {@inheritDoc}
	 */
	@Override
	public Casilla mover(Jugador jugador, Ficha ficha, int valorAMover, Tablero tablero) throws PoobchisException {
		Casilla ultima = super.mover(jugador, ficha, valorAMover, tablero);
		ultima.setTipo("Seguro");
		return ultima;
	}
	
	/**
	 * Ver tambien {@inheritDoc}
	 */
	@Override
	public String getTipo() {
		return "Ingeniera";
	}
}
