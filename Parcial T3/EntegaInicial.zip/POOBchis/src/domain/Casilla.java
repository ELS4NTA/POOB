package domain;
import java.awt.Color;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

import domain.comodines.Comodin;
import domain.fichas.Ficha;

/**
 * Clase que representa una casilla en el tablero de Poobchis
 * @author Angie Mojica - Daniel Santanilla
 * @version 0.4
 */
public class Casilla implements Serializable{
	
	private String tipo;
	private ArrayList<Ficha> fichas = new ArrayList<Ficha>();
	private final int posicion; 
	private Comodin comodin;
	
	/**
	 * Constructor de la casilla
	 * @param tipo Tipo de casilla entre ellos estan ("Comodin", "Segura", "Salida")
	 * @param posicion Posicion para mantener una ubicacion de la casilla en el tablero.
	 */
	public Casilla(String tipo, int posicion) {
		this.tipo = tipo;
		this.posicion = posicion;
	}
	
	/**
	 * Obtiene el tipo de la casilla.
	 * @return Cadena con el tipo de casilla. 
	 */
	public String getTipo() {
		return this.tipo;
	}
	
	/**
	 * Actuliza el tipo de la casilla.
	 * @param nuevoTipo Nuevo tipo de casilla
	 */
	public void setTipo(String nuevoTipo) {
		this.tipo = nuevoTipo;
	}
	
	/**
	 * Verifica si una casilla esta en estado bloqueado (dos fichas en casilla).
	 * @return True si esta bloqueada la casilla, false si no.
	 */
	public boolean estaBloqueada() {
		return (fichas.size() == 2 ? true : false);
	}
	
	/**
	 * Obtiene las fichas de una casilla.
	 * @return Lista de fichas en casilla.
	 */
	public ArrayList<Ficha> getFichas() {
		return this.fichas;
	}
	
	/**
	 * Agrega una ficha a la casilla.
	 * @param ficha Ficha que se agrega a la casilla.
	 */
	public void addFicha(Ficha ficha) {
		this.fichas.add(ficha);
	}
	
	/**
	 * Elimina una ficha de la casilla.
	 * @return Ficha eliminada de la casilla
	 */
	public Ficha quitarFicha() {
		return this.fichas.remove(0);
	}
	
	/**
	 * Quita una ficha especifica de la casilla.
	 * @param ficha Ficha que se quiere eliminar de casilla.
	 */
	public void quitarFicha(Ficha ficha) {
		this.fichas.remove(ficha);
	}
	
	/**
	 * Obtiene la cantidad de fichas que hay en una casilla.
	 * @return Entero con la cantidad de fichas en casilla.
	 */
	public int catidadFichas() {
		return fichas.size();
	}
	
	/**
	 * Calcula la cantidad de fichas que tiene un jugador en una casilla.
	 * @param jugador Jugador duenno de las fichas a consultar.
	 * @return Entero con la cantidad de fichas en la casilla correspondientes al jugador.
	 */
	public int contarMisFichas(Jugador jugador) {
		Color color = jugador.getColor();
		int cantidadFichas = 0;
		for (int i = 0; i < fichas.size(); i++) {
			if (fichas.get(i).getColor().equals(color)) {
				cantidadFichas += 1;
			}
		}
		return cantidadFichas;
	}
	
	/**
	 * Obtiene de una casilla la ficha del Jugador consultado.
	 * @param jugador Jugador que quiere su ficha de la casilla.
	 * @return Ficha que esta en la casilla y corresponde al jugador.
	 */
	public Ficha obtenerFicha(Jugador jugador) {
		Color color = jugador.getColor();
		Ficha obtenida = null;
		for (int i = 0; i < fichas.size(); i++) {
			if (fichas.get(i).getColor().equals(color)) {
				obtenida = fichas.get(i);
			}
		}
		return obtenida;
		
	}
	
	/**
	 * Obtiene la posicion de la casilla en el tablero.
	 * @return Entero que identifica la posicion de la casilla. 
	 */
	public int getPosicion() {
		return this.posicion;
	}
	
	/**
	 * Asigna un {@link Comodin} escogido aleatoriamente de una lista de comodines.
	 * @param listaComodines Lista que contiene los comodines.
	 */
	public void setComodin(List<String> listaComodines) {
		int random = (int)(Math.random()*listaComodines.size());
		Comodin nuevoComodin = null;
		try {
			if (listaComodines.size() > 0) {
				nuevoComodin = (Comodin) Class.forName("domain.comodines."+listaComodines.get(random)).getDeclaredConstructor().newInstance();	
			}
		} catch (InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException
				| NoSuchMethodException | SecurityException | ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		this.comodin = nuevoComodin;
		
	}
	
	/**
	 * Obtiene el comodin de la casilla.
	 * @return Comodin contenido en la casilla.
	 */
	public Comodin getComodin() {
		return this.comodin;
	}
}



















