package domain;
import java.util.ArrayList;

public class CompoundActivity extends Activity{
    private ArrayList<Activity> activities;
    
    public CompoundActivity(String code, String name){
        super(code,name);
        activities= new ArrayList<Activity>();
    }
    
    public void addActivity(Activity a){
        activities.add(a);
    }
    
    @Override
    public int credits() throws ActivityException{
        int totalCredits = 0;
        if (activities.size() == 0) throw new ActivityException(ActivityException.EMPTY_COMPOUND);
        
        
        for (Activity a : activities) {
             totalCredits += a.credits();
        }
        return totalCredits;
    }
    
    @Override
    public int definedCredits() {
        int totalCredits = 0;
        for (Activity a : activities) {
             totalCredits += a.definedCredits();
        }
        return totalCredits;
    }
    
    @Override
    public int credit(String name) throws ActivityException{
        int numCredits = 0;
        int contador = 0;
        if (activities.size() == 0) throw new ActivityException(ActivityException.EMPTY_COMPOUND);
        for (Activity a: activities) {
            String nameActivity = a.getName();
            if (nameActivity.equals(name)) {
                contador += 1;
                numCredits = a.credits();
            }
        }
        if (contador == 0) throw new ActivityException(ActivityException.ACTIVITY_WITHOUT_DESCRIPTION);
        if (contador > 1) throw new ActivityException(ActivityException.EXISTING_ACTIVITY);
        return numCredits;
    }
}
