package domain;

public class SimpleActivity extends Activity{
    private Integer credits;
    private String learningResults;
    
    public SimpleActivity(String code, String name,Integer credits){
        super(code,name);
        this.credits=credits;
    }
    
    public SimpleActivity(String code, String name, String learningResults, Integer credits){
        super(code,name);
        this.learningResults=learningResults;
        this.credits=credits;
        
    }
    
    @Override
    public String results(){
        return learningResults;
    }
    
    @Override
    public int credits() throws ActivityException{
        if (this.credits == null) throw new ActivityException(ActivityException.SIMPLE_WITHOUT_CREDITS);
        return this.credits;
    }

    @Override
    public int definedCredits() {
        return ( (this.credits != null) ? this.credits : 0);
    }
    
    @Override
    public int credit(String name) {
        return this.credits;
    }
}
