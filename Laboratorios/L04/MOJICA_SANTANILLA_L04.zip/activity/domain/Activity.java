package domain;

public abstract class Activity{
    private String code;
    private String name;
    
    public Activity(String code, String name){
        this.code=code;
        this.name=name;
    }
    
    public String getCode(){
        return code;
    }
    
    public String getName(){
        return name;
    }
    
    public String results(){
        return "";
    }
    
    /** Obtiene los creditos de la actividad
     * @return Entero con el numero de creditos de la actividad sea compuesta o simple
     */
    public abstract int credits() throws ActivityException;
    
    /**Calculate the number of credits conscodeering the well-defined activities
     * @return Entero con la cantidad de los creditos de las actividades bien definidas
     * */
    public abstract int definedCredits();
    

    public abstract int credit(String name) throws ActivityException;

    
}
