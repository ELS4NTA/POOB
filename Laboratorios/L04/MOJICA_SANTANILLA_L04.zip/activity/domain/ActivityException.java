package domain;


/**
 * Write a description of class ActivityException here.
 *
 * @author Angie Mojica - Daniel Santanilla
 * @version 25-03-22
 */
public class ActivityException extends Exception {
    public static final String EMPTY_COMPOUND = "Actividad Compuesta Vacia";
    public static final String SIMPLE_WITHOUT_CREDITS = "Actividad Simple Sin Creditos";
    public static final String ACTIVITY_WITHOUT_DESCRIPTION = "No Existe Una Actividad Con Esa Descripcion";
    public static final String EXISTING_ACTIVITY = "Existen Dos Actividades Con La Misma Descripcion";

    /**
     * Constructor for objects of class ActivityException
     */
    public ActivityException(String message)  {
        super(message);
    }
    
}
