package test;

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import domain.ActivityException;
import domain.CompoundActivity;
import domain.SimpleActivity;


public class ActivityTest{
   
    private CompoundActivity plan;
    

    @Before
    public void setUp(){
        plan=new CompoundActivity("PIS", "Plan Ingenieria de Sistemas");
        CompoundActivity is= new CompoundActivity("AIS","Ingenieria de Software");
        CompoundActivity isb=new CompoundActivity("SAISB","Ingenieria de Software Basico");
        isb.addActivity(new SimpleActivity("MBDA","Modelos y Bases de Datos",4));
        isb.addActivity(new SimpleActivity("POOB","Programacion Orientada a Objetos",4));
        CompoundActivity isi=new CompoundActivity("SAISI","Ingenieria de Software Intermedio");
        isi.addActivity(new SimpleActivity("CVDS","Ciclos de Vida de Desarrollo del Software",4));
        isi.addActivity(new SimpleActivity("ARSW","Arquitecturas de Software",4));
        isi.addActivity(new SimpleActivity("IETI","Innovacion y Emprendimiento con TIC",4));
        SimpleActivity isf=new SimpleActivity("TDI","Trabajo Dirigido",3);
        plan.addActivity(isb);
        plan.addActivity(isi);
        plan.addActivity(isf);
    }

    @After
    public void tearDown(){
    }
    
    @Test
    public void shouldCalculateTheCreditsOfAWellDefinedActivity(){
        try {
            assertEquals(23,plan.credits());
        } catch (ActivityException e){
            fail("Exception : "+e.getMessage());
        }    
    }    
       
    
    @Test
    public void shouldNotCalculateTheCreditsWhenACompoundActivityIsNotWellDefined(){
        plan.addActivity(new CompoundActivity("AET","Electivas tecnicas"));
        try { 
           assertEquals(23,plan.credits());
           fail("Threw an exception");
        } catch (ActivityException e) {
            assertEquals(ActivityException.EMPTY_COMPOUND,e.getMessage());
        }    
    }    
    
    
    @Test
    public void shouldNotCalculateTheCreditsWhenASimpleActivityIsNotWellDefined(){
        plan.addActivity(new SimpleActivity("PEM","Practica Empresarial",null));
        try { 
           assertEquals(23,plan.credits());
           fail("Threw an exception");
        } catch (ActivityException e) {
            assertEquals(ActivityException.SIMPLE_WITHOUT_CREDITS,e.getMessage());
        }    
    }     
    
    
    @Test
    public void shouldCalculateTheCreditsWhenACompoundActivityIsWellDefined(){
        plan.addActivity(new CompoundActivity("AET","Electivas tecnicas"));
        assertEquals(23,plan.definedCredits());   
    }
    
    @Test
    public void deberiaNoObtenerLosCreditosDeUnaActividadSinDescripcion(){
        try {
            assertEquals(5,plan.credit("Introduccion a Ingenieria de Sistemas"));
            fail("Threw an exception");
        } catch (ActivityException e) {
            assertEquals(ActivityException.ACTIVITY_WITHOUT_DESCRIPTION,e.getMessage());
        }
    }
    
    @Test
    public void deberiaObtenerLosCreditosDeUnaActividadConDescripcion(){
        try {
            assertEquals(3,plan.credit("Trabajo Dirigido"));
        } catch (ActivityException e) {
            fail("Exception : "+e.getMessage());
        }
    }
    
    @Test
    public void deberiaNoObtenerLosCreditosDeDosActividadesConLaMismaDescripcion(){
        plan.addActivity(new SimpleActivity("CALD","Calculo Diferencial",4));
        plan.addActivity(new SimpleActivity("CALD","Calculo Diferencial",3));
        try {
            assertEquals(10132489,plan.credit("Calculo Diferencial"));
            fail("Threw an exception");
        } catch (ActivityException e) {
            assertEquals(ActivityException.EXISTING_ACTIVITY,e.getMessage());
        }
    }
}
