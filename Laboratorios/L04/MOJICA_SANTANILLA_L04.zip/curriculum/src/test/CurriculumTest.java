package test;
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import domain.Curriculum;
import domain.CurriculumException;

public class CurriculumTest {
    
    private Curriculum plan;

    @Before
    public void setUp() {
        plan = new Curriculum();
    }
    
    @Test
    public void noDeberiaAnnadirSinSigla() {
        try{
            plan.addSimple("", "Analisis de Algoritmos y Estructuras de Datos", "3", "Hacer algo");  
        } catch (CurriculumException ce) {
            assertEquals(CurriculumException.SIN_SIGLA, ce.getMessage());
        }
    }

    @Test
    public void noDeberiaAnnadirConUnaSiglaExistente(){
        plan.addSimpleActivities();
        try{
            plan.addSimple("AYED", "Analisis de Algoritmos y Estructuras de Datos", "3", "Hacer algo");  
        } catch (CurriculumException ce) {
            assertEquals(CurriculumException.SIGLA_EXISTENTE, ce.getMessage());
        }
    }

    @Test
    public void noDeberiaAnnadirSinCreditos() {
        try{
            plan.addSimple("AYED", "Analisis de Algoritmos y Estructuras de Datos", "", "Hacer algo");
        } catch (CurriculumException ce) {
            assertEquals(CurriculumException.SIN_CREDITOS, ce.getMessage());
        }
    }

    @Test
    public void noDeberiaAnnadirConCreditosFueraDeRango() {
        try{
            plan.addSimple("AYED", "Analisis de Algoritmos y Estructuras de Datos", "-1", "Hacer algo");
        } catch (CurriculumException ce){
            assertEquals(CurriculumException.CREDITOS_FUERA_DE_RANGO, ce.getMessage());
        }
        try{
            plan.addSimple("POOB", "Programacion Orientada a Objetos", "100", "Hacer algo");
        } catch (CurriculumException ce) {
            assertEquals(CurriculumException.CREDITOS_FUERA_DE_RANGO, ce.getMessage());
        }
    }

    @Test
    public void noDeberiaAnnadiSinNombreDeCurso() {
        try{
            plan.addSimple("POOB", "", "4", "Hacer algo");
        } catch (CurriculumException ce) {
            assertEquals(CurriculumException.SIN_NOMBRE_DE_CURSO, ce.getMessage());
        }
    }

    @Test
    public void noDeberiaAnnadirSinResultado() {
        try{
            plan.addSimple("POOB", "Programacion Orientada a Objetos", "4", "");
        } catch (CurriculumException ce) {
            assertEquals(CurriculumException.SIN_RESULTADOS_DE_APRENDIZAJE, ce.getMessage());
        }
    }

    @After
    public void tearDown(){
    }
}
