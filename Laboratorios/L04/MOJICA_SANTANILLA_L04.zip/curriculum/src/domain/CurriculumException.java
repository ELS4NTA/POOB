package domain;


public class CurriculumException extends Exception{
    public static final String SIN_SIGLA = "No se tiene una sigla.";
    public static final String SIGLA_EXISTENTE = "Ya existe esta sigla.";
    public static final String CREDITOS_FUERA_DE_RANGO = "Los creditos deben estar entre 1 y 10.";
    public static final String SIN_NOMBRE_DE_CURSO = "No se indicó el nombre de curso.";
    public static final String SIN_CREDITOS = "No se indicó el numero de creditos.";
    public static final String SIN_RESULTADOS_DE_APRENDIZAJE = "No se tienen resultados de aprendizaje.";


    public CurriculumException(String message) {
        super(message);
    }
}
