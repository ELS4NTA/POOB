package domain;

public class AutomataException extends Exception{
	public static final String OPCION_CONSTRUCCION = "Opcion en construccion.";
	public static final String ARCHIVO_NO_ENCONTRADO = "Archivo no encontrado.";
	
	public AutomataException(String message) {
		super(message);
	}
	
}
