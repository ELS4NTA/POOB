package domain;


public class Tablero {
	
	private Casa[] tablero;
	private int numCasas;
	
	public Tablero(int numCasas, int numSemillas) {
		this.tablero = new Casa[(numCasas*2)+2];
		for (int i = 0; i < tablero.length; i++) {
			if (i != numCasas && i != tablero.length-1) {
				tablero[i] = new Casa(numSemillas, false);
			} else {
				tablero[i] = new Casa(0, true);
			}
			
		}
		this.numCasas = numCasas;
	}
	
	
	public Casa getCasa(int i) {
		return tablero[i];
	}
	
	public int getSiguiente(int i) {
		int siguiente;
		if (i == tablero.length-1) {
			siguiente = 0;
		} else {
			siguiente = i++;
		}
		return siguiente;
	}
	
	public int getSemillasEnCampo(Jugador jugador) {
		int semillasTotales = 0;
		if (jugador.getIdJugador() == 1) {
			for (int i = 0; i < numCasas; i++) {
				Casa casa = this.tablero[i];
				semillasTotales += casa.getNumSemillas();
			}
		} else {
			for (int i = numCasas; i < tablero.length; i++) {
				Casa casa = this.tablero[i];
				if (!casa.esAlmacen()) {
					semillasTotales += casa.getNumSemillas();
				}
			}
		}
		return semillasTotales;
	}
	
	public int captura(int i, Jugador jugador) {
		int semillasGanadas = 0;
		Casa casa = tablero[i];
		if (casa.getNumSemillas() == 1 && misCasas(i, jugador)) {
			Casa opuesto = tablero[i+numCasas];
			if (!opuesto.esAlmacen()) {
				semillasGanadas = opuesto.getNumSemillas()+casa.getNumSemillas();
				opuesto.setNumSemillas(0);
				casa.setNumSemillas(0);
			}
		}
		return semillasGanadas;
	}
	
	public boolean misCasas(int i, Jugador jugador) {
		boolean esMiVecindario = false;
		if (jugador.getIdJugador()==1) {
			if (i <= numCasas) {
				esMiVecindario = true;
			}
		} else {
			if (i > numCasas) {
				esMiVecindario = true;
			}
		}
		return esMiVecindario;
		
	}
	
	public void desocuparCasas() {
		for (Casa casa : tablero) {
			if (!casa.esAlmacen()) {
				casa.setNumSemillas(0);
			}
		}
	}
}
