package presentation;

import java.awt.*;

import javax.swing.*;

public class KalahGUI extends JFrame{
	
	
	private KalahGUI() {
		setTitle("Kalah");
		prepareElements();
	}
	
	public void prepareElements() {
		Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
	    int alto = dimension.height;
	    int ancho = dimension.width;
		setSize(ancho/2, alto/2);
		setLocationRelativeTo(null);
	}
	
	public void prepareActions() {
		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
	}
	
	public void actionClose(){
        int confirmation = JOptionPane.showConfirmDialog(null,"�Seguro que deseas salir?");
        if(confirmation == JOptionPane.YES_OPTION){
            System.exit(0);
        }
    }
	
	public static void main(String[] args) {
		KalahGUI gui = new KalahGUI();
		gui.setVisible(true);
	}
}
