package domain;

public class Kalah {
	
}
