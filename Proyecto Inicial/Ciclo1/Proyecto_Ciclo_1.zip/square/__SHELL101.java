
public class __SHELL101 extends bluej.runtime.Shell {
public static void run() throws Throwable {
final bluej.runtime.BJMap __bluej_runtime_scope = getScope("C:\\Users\\usuario\\OneDrive - ESCUELA COLOMBIANA DE INGENIERIA JULIO GARAVITO\\University\\Quinto Semestre\\POOB\\Proyecto\\shapes");
final Square square1 = (Square)__bluej_runtime_scope.get("square1");


square1.makeVisible();

}}
