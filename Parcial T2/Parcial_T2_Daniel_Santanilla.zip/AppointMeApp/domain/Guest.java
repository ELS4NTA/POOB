package domain;

import java.util.Set;

public abstract class Guest {
    protected int requiredSpots() {return 0;}
    public boolean isTeam() {return false;}

    public Set assistingEvents() {
        return null;
    }
}
