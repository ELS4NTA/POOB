package domain;

public class Employee extends Person implements Organizer {

	private String role;

	private Team team;


	/**
	 * @see domain.Organizer#getId()
	 */
	public String getId() {
		return null;
	}

}
