package domain;

import domain.Event;
import domain.Guest;
import java.util.*;

public class AppointmentApp {
    private HashMap<String, Guest> teams ;
    private HashMap<String, Guest> persons;
    private HashMap<String, Event> events;
    
    
    /**
     * Creates an appointment in any slot with capacity of the given {@link Event} 
     * for the given {@link Guest}.
     * @param event The event where the guest wants to get an appointment, cannot 
     * be null.
     * @param guest The guest interested in the appointment, cannot be null.
     * @return true if the appointment was created and added to the guest, false if the guest is
     * already in the event.
     * @throws AppointmentAppException if there is an error with the guest or the event:
     * <pre>
     * <b>NO_CAPACITY_EVENT</b> if there is no available capacity in any slot of the event.
     * <b>GUEST_NO_COMPATIBLE</b> if the guest cannot separate an appointment for the the 
     * event type.
     * </pre>
     */
    public boolean createAnyAppointment(Event event, Guest guest) throws AppointmentAppException {
        List<Slot> slots;
        try {
            slots = event.findSlotsForGuest(guest);
        } catch (AppointmentAppException aap) {
            return false;
        }
           
        for (Slot slot : slots) {
            boolean done = slot.makeAppointment(guest);
            if (done == true) {
                return true;
            }
            if (slot.getCapacity() == 0) {
                throw new AppointmentAppException(AppointmentAppException.NO_CAPACITY_EVENT);
            }
        }

        return false;
    }
}
