package domain;

public class RemoteEvent extends Event {
    private String url;

}
