package domain;

public class AppointmentAppException extends Exception {
    public static final String ALREADY_IN_EVENT = "There is already in event";
    public static final String NO_CAPACITY_EVENT = "There is no avilable capacity in any slot of the event";
    public static final String GUEST_NO_COMPATIBLE = "The guest cannot separate an appointment for the event type";
    
    public AppointmentAppException(String message) {
        super(message);
    }

}
