package domain;


/**
 * Write a description of class VipPerson here.
 *
 * @author Daniel Santanilla
 * @version 04-01-22
 */
public class VipPerson extends Person{

}
