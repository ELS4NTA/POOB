package domain;

public class EventType {

    private String name;
    private int slotDuration;
    private int capacity;
    
    public EventType(String name, int slotDuration, int capacity) {
        this.name = name;
        this.slotDuration = slotDuration;
        this.capacity = capacity;
    }
    
    /** Obtiene el nombre del tipo del evento
     * @return Cadena con el nombre del vento
     */
    public String getName() {
        return this.name;
    }
    
}
