package domain;

import java.time.LocalDate;

public class Appointment {
    private boolean assisted;
    private LocalDate date;
    private int duration;
    private boolean canceled;
    private Slot slot;
    private Event event;
    private Team team;
    private Guest guest;

}
