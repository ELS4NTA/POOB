package domain;
import java.util.List;

public class Team extends Guest {
    private String name;
    private List<Employee> members;

    protected int requiredSpots() {
        return members.size();
    }

    public boolean isTeam() {
        return true;
    }
}
