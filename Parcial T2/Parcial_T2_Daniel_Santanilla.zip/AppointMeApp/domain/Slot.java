package domain;

import java.time.LocalDateTime;
import java.util.*;

public class Slot {
    private String description;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private int capacity;
    private boolean selected;
    private ArrayList<Appointment> appointments;
    private Event event;
    
    
    public boolean makeAppointment(Guest guest) {
        return false;
    }
    
    /** Obtiene la capacidad del slot
     * @return Entero con la capacidad del slot
     */
    public int getCapacity() {
        return capacity;
    }
}
