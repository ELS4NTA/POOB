package domain;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.*;
    
public abstract class Event {
    private String id;
    private String name;
    private String description;
    private LocalDateTime startDate;
    private LocalDateTime endDate;
    private LocalTime startTimeOfDay;
    private LocalTime endTimeOfDay;
    private int[] weekDays;
    private Organizer organizer;
    private EventType type;
    private ArrayList<Slot> slots;
    
    public List findSlotsForGuest(Guest guest) throws AppointmentAppException {
        Set<String> events = guest.assistingEvents();
        if (events.contains(name)) {
            throw new AppointmentAppException(AppointmentAppException.ALREADY_IN_EVENT);
        }
        boolean team = guest.isTeam();
        String typeName = type.getName();
        if (team && (typeName != "AllHands" || typeName != "Interview")) {
            throw new AppointmentAppException(AppointmentAppException.GUEST_NO_COMPATIBLE);
        }
        return slots;
    }
}
