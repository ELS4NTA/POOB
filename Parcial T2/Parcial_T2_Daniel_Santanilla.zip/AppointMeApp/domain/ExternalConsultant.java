package domain;

public class ExternalConsultant extends Person implements Organizer {

    private String company;

    public String getId() {
        return null;
    }

}
