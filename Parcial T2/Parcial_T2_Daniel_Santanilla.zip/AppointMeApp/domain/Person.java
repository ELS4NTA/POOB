package domain;
import java.util.List;

public class Person extends Guest {
    private String email;
    private String name;
    private String phone;
    private List<Event> arrangedEvents;


    protected int requiredSpots() {
        return 1;
    }

    public boolean isTeam() {
        return true;
    }
}
