package domain;

import java.util.Set;

public class Guest {
    protected int requiredSpots() {return 0;}
    public boolean isTeam() {return false;}

    public Set assistingEvents() {
        return null;
    }
}
