package domain;

import java.time.LocalDateTime;

public class Slot {

    public boolean makeAppointment(Guest guest) {
        return false;
    }
}
