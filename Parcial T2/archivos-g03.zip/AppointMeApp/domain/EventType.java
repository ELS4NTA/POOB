package domain;

public class EventType {

	private String name;

	private int slotDuration;

	private int capacity;

}
