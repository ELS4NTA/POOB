package domain;

import java.time.LocalDateTime;
import java.time.LocalTime;

public class Event {
}
