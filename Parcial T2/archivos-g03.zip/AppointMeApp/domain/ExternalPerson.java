package domain;

public class ExternalPerson extends Person {
    private String[] applyingRoles;
    private String cvUrl;
}
