package domain;

public interface Organizer {
    public abstract String getId();
}
