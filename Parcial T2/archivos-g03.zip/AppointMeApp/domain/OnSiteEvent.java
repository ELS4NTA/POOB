package domain;

public class OnSiteEvent extends Event {

	private Location location;

}
