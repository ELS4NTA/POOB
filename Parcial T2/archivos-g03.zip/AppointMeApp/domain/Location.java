package domain;

public class Location {

	private String name;

	private Double latitude;

	private Double longitude;

}
