
public class AppointmentAppException extends Exception {
}
