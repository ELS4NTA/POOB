public class Posicion {
	private int longitud;
	private int latitud;
}
