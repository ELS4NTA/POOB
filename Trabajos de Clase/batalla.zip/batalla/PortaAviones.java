import java.util.ArrayList;

public class PortaAviones {
	private int numero;
	private int capacidad;
	private Posicion ubicacion;
	private ArrayList<Marino> marinos;
	private ArrayList<Avion> aviones;
}
