package test;

import static org.junit.Assert.*;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import domain.Casilla;
import domain.Dado;
import domain.Jugador;
import domain.Poobchis;
import domain.PoobchisException;
import domain.Tablero;
import domain.fichas.Ficha;

public class PoobchisTest {

	private Poobchis juego; 
	private List<String> jugadores = new ArrayList<>();
	private List<Color> colores = new ArrayList<>();
	private List<String> fichas = new ArrayList<>();
	private List<String> comodines = new ArrayList<>();
	
	@Before
	public void setUp() {
		jugadores.add("Mojica");
		jugadores.add("Santanilla");
		colores.add(Color.BLUE);
		colores.add(Color.GREEN);
		fichas.add("Ficha");
		fichas.add("Ficha");
		fichas.add("Ficha");
		fichas.add("Ficha");
		juego = new Poobchis(jugadores,colores,fichas,comodines);
	}
	
	
	@Test
	public void deberiaObtenerElNombreDelJugadorEnTurno() {
		Jugador enTurno = juego.getJugadorEnTurno();
		String nombre = enTurno.getNombre();
		assertTrue(nombre.equals("Mojica"));
		ArrayList <Dado> dados = juego.getTableroJuego().getDados();
		for (Dado dado : dados) {
			dado.setSeHaJugado(true);
		}
		juego.cambiarTurno();
		enTurno = juego.getJugadorEnTurno();
		nombre = enTurno.getNombre();
		assertTrue(nombre.equals("Santanilla"));
	}
	
	@Test
	public void deberiaObtenerElColorDelJugadorEnTurno() {
		Jugador enTurno = juego.getJugadorEnTurno();
		Color color = enTurno.getColor();
		assertTrue(color.equals(Color.BLUE));
		ArrayList <Dado> dados = juego.getTableroJuego().getDados();
		for (Dado dado : dados) {
			dado.setSeHaJugado(true);
		}
		juego.cambiarTurno();
		enTurno = juego.getJugadorEnTurno();
		color = enTurno.getColor();
		assertTrue(color.equals(Color.GREEN));
	}
	
	@Test
	public void deberiaObtenerEldeJuegoConAmbosHumanos() {
		Jugador enTurno = juego.getJugadorEnTurno();
		boolean humano = enTurno.esHumano();
		assertTrue(humano == true);
		juego.cambiarTurno();
		enTurno = juego.getJugadorEnTurno();
		humano = enTurno.esHumano();
		assertTrue(humano == true);
	}
	
	@Test
	public void deberiaMoverUnaFicha() {
		Jugador enTurno = juego.getJugadorEnTurno();
		Ficha sacada = enTurno.getNido().sacarFicha();
		Tablero tablero = juego.getTableroJuego();
		Casilla salidaA = tablero.getCasilla(22);
		sacada.setPosicion(22);
		salidaA.addFicha(sacada);
		try {
			juego.jugar(sacada, 4);	
			assertEquals(26,sacada.getPosicion());
		} catch (PoobchisException pe){
			System.out.println(pe.getMessage());
		}
	}
	
	@Test
	public void deberiaSerUnBloqueo() {
		Jugador enTurno = juego.getJugadorEnTurno();
		Tablero tablero = juego.getTableroJuego();
		Casilla casilla = tablero.getCasilla(29);
		Ficha sacada1 = enTurno.getNido().sacarFicha();
		Ficha sacada2 = enTurno.getNido().sacarFicha();
		casilla.addFicha(sacada1);
		casilla.addFicha(sacada2);
		assertTrue(casilla.estaBloqueada());
	}
	
	@Test
	public void noDeberiaMoverUnaFicha() {
		Jugador enTurno = juego.getJugadorEnTurno();
		Tablero tablero = juego.getTableroJuego();
		Casilla casillaB = tablero.getCasilla(29);
		Casilla casillaM = tablero.getCasilla(26);
		Ficha sacada1 = enTurno.getNido().sacarFicha();
		Ficha sacada2 = enTurno.getNido().sacarFicha();
		Ficha sacada3 = enTurno.getNido().sacarFicha();
		enTurno.getNido().quitarFicha(sacada1);
		enTurno.getNido().quitarFicha(sacada2);
		enTurno.getNido().quitarFicha(sacada3);
		sacada3.setPosicion(26);
		casillaB.addFicha(sacada1);
		casillaB.addFicha(sacada2);
		casillaM.addFicha(sacada3);
		try {
			juego.jugar(sacada3, 3);
		} catch (PoobchisException pe) {
			assertEquals(PoobchisException.NO_SE_PUEDE_MOVER,pe.getMessage());
		}
	}
	
	@Test
	public void deberiaCapturarFicha() {
		Jugador enTurno = juego.getJugadorEnTurno();
		Tablero tablero = juego.getTableroJuego();		
		Casilla casillaC = tablero.getCasilla(26);
		ArrayList <Dado> dados = juego.getTableroJuego().getDados();
		for (Dado dado : dados) {
			dado.setSeHaJugado(true);
		}
		juego.cambiarTurno();
		Jugador opuesto = juego.getJugadorEnTurno();
		juego.cambiarTurno();
		Ficha sacada1 = enTurno.getNido().sacarFicha();
		Ficha sacada2 = opuesto.getNido().sacarFicha();
		enTurno.getNido().quitarFicha(sacada1);
		opuesto.getNido().quitarFicha(sacada2);
		sacada1.setPosicion(26);
		sacada2.setPosicion(26);
		casillaC.addFicha(sacada1);
		casillaC.addFicha(sacada2);
		boolean seCome = tablero.comer(casillaC, enTurno);
		assertTrue(seCome);
		assertEquals(sacada2.getPosicion(),0);
		assertEquals(4,opuesto.getNido().getTamanno());
	}
	
	@Test
	public void noDeberiaCapturarFicha() {
		Jugador enTurno = juego.getJugadorEnTurno();
		Tablero tablero = juego.getTableroJuego();
		Casilla casillaC = tablero.getCasilla(46);
		juego.cambiarTurno();
		Jugador opuesto = juego.getJugadorEnTurno();
		juego.cambiarTurno();
		Ficha sacada1 = opuesto.getNido().sacarFicha();
		Ficha sacada2 = opuesto.getNido().sacarFicha();
		opuesto.getNido().quitarFicha(sacada1);
		opuesto.getNido().quitarFicha(sacada2);
		sacada1.setPosicion(46);
		sacada2.setPosicion(46);
		casillaC.addFicha(sacada1);
		casillaC.addFicha(sacada2);
		boolean seCome = tablero.comer(casillaC, opuesto);
		assertFalse(seCome);
		assertTrue(casillaC.estaBloqueada());
	}
	
	@Test
	public void noDeberiaCapturarFichaEnSeguro() {
		Jugador enTurno = juego.getJugadorEnTurno();
		Tablero tablero = juego.getTableroJuego();
		Casilla casillaC = tablero.getCasilla(47);
		juego.cambiarTurno();
		Jugador opuesto = juego.getJugadorEnTurno();
		juego.cambiarTurno();
		Ficha sacada1 = opuesto.getNido().sacarFicha();
		Ficha sacada2 = enTurno.getNido().sacarFicha();
		opuesto.getNido().quitarFicha(sacada1);
		enTurno.getNido().quitarFicha(sacada2);
		sacada1.setPosicion(47);
		sacada2.setPosicion(47);
		casillaC.addFicha(sacada1);
		casillaC.addFicha(sacada2);
		casillaC.setTipo("Segura");
		boolean seCome = tablero.comer(casillaC, opuesto);
		assertFalse(seCome);
		assertTrue(casillaC.estaBloqueada());
	}
	
	@Test
	public void deberiaObtenerPremioCapturaDeFicha() {
		Jugador enTurno = juego.getJugadorEnTurno();
		Tablero tablero = juego.getTableroJuego();
		Casilla casillaC = tablero.getCasilla(26);
		ArrayList <Dado> dados = juego.getTableroJuego().getDados();
		for (Dado dado : dados) {
			dado.setSeHaJugado(true);
		}
		juego.cambiarTurno();
		Jugador opuesto = juego.getJugadorEnTurno();
		Casilla casillaM = tablero.getCasilla(25);
		Ficha sacada1 = enTurno.getNido().sacarFicha();
		Ficha sacada2 = opuesto.getNido().sacarFicha();
		sacada1.setPosicion(26);
		sacada2.setPosicion(25);
		casillaC.addFicha(sacada1);
		casillaM.addFicha(sacada2);
		try {
			juego.jugar(sacada2, 1);
			assertEquals(4,enTurno.getNido().getEncarceladas().size());
		} catch (PoobchisException pe) {
			pe.getMessage();		
		}
	}
	
	@Test
	public void deberiaObtenerPremioCoronacionDeFicha() {
		Jugador enTurno = juego.getJugadorEnTurno();
		Tablero tablero = juego.getTableroJuego();
		Casilla casillaM = tablero.getCasilla(74);
		Casilla casillaL = tablero.getCasilla(76);
		Ficha sacada1 = enTurno.getNido().sacarFicha();
		enTurno.getNido().quitarFicha(sacada1);
		sacada1.setPosicion(74);
		casillaM.addFicha(sacada1);
		try {
			juego.jugar(sacada1, 2);
		} catch (PoobchisException pe) {
			assertEquals(enTurno.getFichasCoronadas(), 1);
			assertEquals(1,casillaL.getFichas().size());
		}
	}
	
	@Test
	public void noDeberiaSobrepasarLaCasillaDeCoronacion() {
		Jugador enTurno = juego.getJugadorEnTurno();
		Tablero tablero = juego.getTableroJuego();
		Casilla casillaM = tablero.getCasilla(74);
		Ficha sacada1 = enTurno.getNido().sacarFicha();
		enTurno.getNido().quitarFicha(sacada1);
		sacada1.setPosicion(74);
		casillaM.addFicha(sacada1);
		try {
			juego.jugar(sacada1, 6);
		} catch (PoobchisException pe) {
			assertEquals(PoobchisException.NO_SE_PUEDE_MOVER,pe.getMessage());
		}
	}
		
	@Test
	public void deberiaExistirUnGanador() {
		Jugador enTurno = juego.getJugadorEnTurno();
		Tablero tablero = juego.getTableroJuego();
		Casilla casillaM = tablero.getCasilla(74);
		Ficha sacada1 = enTurno.getNido().sacarFicha();
		sacada1.setPosicion(74);
		casillaM.addFicha(sacada1);
		try {
			enTurno.fichaCoronada();
			enTurno.fichaCoronada();
			enTurno.fichaCoronada();
			juego.jugar(sacada1, 2);
		} catch (PoobchisException pe) {
			//assertEquals(PoobchisException.GANADOR,pe.getMessage());
		}
	}
	
	@Test
	public void deberiaSalirConUnaFicha() {
		Jugador enTurno = juego.getJugadorEnTurno();
		Tablero tablero = juego.getTableroJuego();
		Casilla casillaS = tablero.getCasilla(22);
		Ficha aSacar = enTurno.getNido().getEncarceladas().get(0);
		try {
			juego.jugar(aSacar, 5);
			assertEquals(1, casillaS.getFichas().size());
		} catch (PoobchisException pe) {
			System.out.println(pe.getMessage());
		}
	}
	
	@Test
	public void deberiaSalirConUnaFichaDondeHay1EnSalidaMismoColor() {
		Jugador enTurno = juego.getJugadorEnTurno();
		Tablero tablero = juego.getTableroJuego();
		Casilla casillaS = tablero.getCasilla(22);
		Ficha afuera = enTurno.getNido().sacarFicha();
		Ficha aSacar = enTurno.getNido().getEncarceladas().get(0);
		afuera.setPosicion(22);
		casillaS.addFicha(afuera);
		try {
			juego.jugar(aSacar, 5);
			assertEquals(2, casillaS.getFichas().size());
			assertTrue(casillaS.estaBloqueada());
		} catch (PoobchisException pe) {
			System.out.println(pe.getMessage());
		}
	}
	
	@Test
	public void deberiaSalirConUnaFichaDondeHay1EnSalidaDiferenteColor() {
		Jugador enTurno = juego.getJugadorEnTurno();
		Tablero tablero = juego.getTableroJuego();
		juego.cambiarTurno();
		Casilla casillaS = tablero.getCasilla(22);
		Jugador opuesto = juego.getJugadorEnTurno();
		Ficha afuera = opuesto.getNido().sacarFicha();
		Ficha aSacar = enTurno.getNido().getEncarceladas().get(0);
		juego.cambiarTurno();
		afuera.setPosicion(22);
		casillaS.addFicha(afuera);
		try {
			juego.jugar(aSacar, 5);
			assertEquals(2, casillaS.getFichas().size());
			assertTrue(casillaS.estaBloqueada());
		} catch (PoobchisException pe) {
			System.out.println(pe.getMessage());
		}
	}
	
	@Test
	public void deberiaSalirConUnaFichaDondeHay2EnSalidaMismoColor() {
		Jugador enTurno = juego.getJugadorEnTurno();
		Tablero tablero = juego.getTableroJuego();
		Ficha afuera1 = enTurno.getNido().sacarFicha();
		Ficha afuera2 = enTurno.getNido().sacarFicha();
		Casilla casillaS = tablero.getCasilla(22);
		Ficha aSacar = enTurno.getNido().getEncarceladas().get(0);
		afuera1.setPosicion(22);
		afuera2.setPosicion(22);
		casillaS.addFicha(afuera1);
		casillaS.addFicha(afuera2);
		try {
			juego.jugar(aSacar, 5);
		} catch (PoobchisException pe) {
			//assertEquals(PoobchisException.MOVIMIENTO_DADO,pe.getMessage());
		}
	}
	
	@Test
	public void deberiaSalirConUnaFichaDondeHay2EnSalidaIntercaladoColor() {
		Jugador enTurno = juego.getJugadorEnTurno();
		Tablero tablero = juego.getTableroJuego();
		Casilla casillaS = tablero.getCasilla(22);
		juego.cambiarTurno();
		Jugador opuesto = juego.getJugadorEnTurno();
		juego.cambiarTurno();
		Ficha afuera1 = enTurno.getNido().sacarFicha();
		Ficha afuera2 = opuesto.getNido().sacarFicha();
		Ficha aSacar = enTurno.getNido().getEncarceladas().get(0);
		afuera1.setPosicion(22);
		afuera2.setPosicion(22);
		casillaS.addFicha(afuera1);
		casillaS.addFicha(afuera2);
		try {
			juego.jugar(aSacar, 5);
		} catch (PoobchisException pe) {
			//assertEquals(PoobchisException.PREMIO_MATAR,pe.getMessage());
		}
	}
	
	@Test
	public void deberiaSalirConUnaFichaDondeHay2EnSalidadiferenteColor() {
		Jugador enTurno = juego.getJugadorEnTurno();
		Tablero tablero = juego.getTableroJuego();
		ArrayList <Dado> dados = tablero.getDados();
		for (Dado dado : dados) {
			dado.setSeHaJugado(true);
		}
		juego.cambiarTurno();
		Casilla casillaS = tablero.getCasilla(22);
		Jugador opuesto = juego.getJugadorEnTurno();
		Ficha afuera1 = opuesto.getNido().sacarFicha();
		opuesto.getNido().quitarFicha(afuera1);
		Ficha afuera2 = opuesto.getNido().sacarFicha();
		opuesto.getNido().quitarFicha(afuera2);
		Ficha aSacar = enTurno.getNido().getEncarceladas().get(0);
		juego.cambiarTurno();
		afuera1.setPosicion(22);
		afuera2.setPosicion(22);
		casillaS.addFicha(afuera1);
		casillaS.addFicha(afuera2);
		try {
			juego.jugar(aSacar, 5);
		} catch (PoobchisException pe) {
			//assertEquals(PoobchisException.PREMIO_MATAR,pe.getMessage());
		}
	}
	
	@Test
	public void deberiaObtenerCasillasRestanteParaGanar() {
		Jugador enTurno = juego.getJugadorEnTurno();
		Tablero tablero = juego.getTableroJuego();
		Ficha afuera11 = enTurno.getNido().sacarFicha();
		enTurno.getNido().quitarFicha(afuera11);
		Ficha afuera22 = enTurno.getNido().sacarFicha();
		enTurno.getNido().quitarFicha(afuera22);
		Ficha afuera33 = enTurno.getNido().sacarFicha();
		enTurno.getNido().quitarFicha(afuera33);		
		afuera11.setPosicion(29);
		afuera22.setPosicion(60);
		afuera33.setPosicion(17);
		tablero.getCasilla(29).addFicha(afuera11);
		tablero.getCasilla(60).addFicha(afuera22);
		tablero.getCasilla(17).addFicha(afuera33);
		int casillasRestantes = enTurno.getCasillasACoronadar(juego);
		assertEquals(1,enTurno.getNido().getTamanno());
		assertTrue(casillasRestantes == 176);
	}
	
	@Test
	public void deberiaJugarValor5CuandoNoTieneFichasEnCarcel() {
		Jugador enTurno = juego.getJugadorEnTurno();
		Tablero tablero = juego.getTableroJuego();
		Ficha afuera1 = enTurno.getNido().sacarFicha();
		enTurno.getNido().quitarFicha(afuera1);
		Ficha afuera2 = enTurno.getNido().sacarFicha();
		enTurno.getNido().quitarFicha(afuera2);
		Ficha afuera3 = enTurno.getNido().sacarFicha();
		enTurno.getNido().quitarFicha(afuera3);		
		Ficha afuera4 = enTurno.getNido().sacarFicha();
		enTurno.getNido().quitarFicha(afuera4);	
		afuera1.setPosicion(29);
		afuera2.setPosicion(60);
		afuera3.setPosicion(17);
		afuera4.setPosicion(17);
		tablero.poneFichaEnCasilla(tablero.getCasilla(29), afuera1);
		tablero.getCasilla(60).addFicha(afuera2);
		tablero.getCasilla(17).addFicha(afuera3);
		tablero.getCasilla(17).addFicha(afuera4);
		try {
			juego.jugar(afuera4, 5);
			assertTrue(afuera4.getPosicion() == 73);
		} catch (PoobchisException pe) {
			pe.getMessage();
		}
	}
	@Test
	public void deberiaRecibirCastigoTriplePar() {
		Jugador enTurno = juego.getJugadorEnTurno();
		Ficha afuera1 = enTurno.getNido().sacarFicha();
		enTurno.getNido().quitarFicha(afuera1);
		Ficha afuera2 = enTurno.getNido().sacarFicha();
		enTurno.getNido().quitarFicha(afuera2);
		Ficha afuera3 = enTurno.getNido().sacarFicha();
		enTurno.getNido().quitarFicha(afuera3);		
		Ficha afuera4 = enTurno.getNido().sacarFicha();
		enTurno.getNido().quitarFicha(afuera4);	
		afuera1.setPosicion(29);
		afuera2.setPosicion(60);
		afuera3.setPosicion(17);
		afuera4.setPosicion(17);
		enTurno.setCantPares(3);
		assertTrue(juego.castigoTriplePar(enTurno, afuera4));
	}
	
	@Test
	public void nodeberiaRecibirCastigoTriplePar() {
		Jugador enTurno = juego.getJugadorEnTurno();
		Ficha afuera1 = enTurno.getNido().sacarFicha();
		enTurno.getNido().quitarFicha(afuera1);
		Ficha afuera2 = enTurno.getNido().sacarFicha();
		enTurno.getNido().quitarFicha(afuera2);
		Ficha afuera3 = enTurno.getNido().sacarFicha();
		enTurno.getNido().quitarFicha(afuera3);		
		Ficha afuera4 = enTurno.getNido().sacarFicha();
		enTurno.getNido().quitarFicha(afuera4);	
		afuera1.setPosicion(29);
		afuera2.setPosicion(60);
		afuera3.setPosicion(17);
		afuera4.setPosicion(17);
		enTurno.setCantPares(2);
		assertFalse(juego.castigoTriplePar(enTurno, afuera4));
	}
	
	@Test
	public void deberiaHaberAlgunaParaMoverse() {
		Jugador enTurno = juego.getJugadorEnTurno();
		Ficha afuera1 = enTurno.getNido().sacarFicha();
		enTurno.getNido().quitarFicha(afuera1);
		afuera1.setPosicion(29);
		assertTrue(juego.algunaSeMueve(enTurno, 6));
		assertTrue(juego.algunaSeMueve(enTurno, 5));
	}
	
	@Test
	public void NodeberiaHaberAlgunaParaMoverse() {
		Jugador enTurno = juego.getJugadorEnTurno();
		assertTrue(juego.algunaSeMueve(enTurno, 5));
		assertFalse(juego.algunaSeMueve(enTurno, 6));
	}
	
	@Test
	public void deberiaHaberUnGanador() {
		Jugador enTurno = juego.getJugadorEnTurno();
		Ficha afuera1 = enTurno.getNido().sacarFicha();
		enTurno.getNido().quitarFicha(afuera1);
		Ficha afuera2 = enTurno.getNido().sacarFicha();
		enTurno.getNido().quitarFicha(afuera2);
		Ficha afuera3 = enTurno.getNido().sacarFicha();
		enTurno.getNido().quitarFicha(afuera3);		
		Ficha afuera4 = enTurno.getNido().sacarFicha();
		enTurno.getNido().quitarFicha(afuera4);	
		afuera1.setPosicion(75);
		afuera2.setPosicion(70);
		afuera3.setPosicion(71);
		afuera4.setPosicion(72);
		try {
			juego.jugar(afuera2, 6);
			juego.jugar(afuera3, 5);
			juego.jugar(afuera1, 1);
			juego.jugar(afuera4, 4);
			assertTrue(juego.ganador());
		} catch (PoobchisException pe) {
			pe.getMessage();
		}
	}
	
	@Test
	public void noDeberiaHaberUnGanador() {
		Jugador enTurno = juego.getJugadorEnTurno();
		Ficha afuera1 = enTurno.getNido().sacarFicha();
		enTurno.getNido().quitarFicha(afuera1);
		Ficha afuera2 = enTurno.getNido().sacarFicha();
		enTurno.getNido().quitarFicha(afuera2);
		Ficha afuera3 = enTurno.getNido().sacarFicha();
		enTurno.getNido().quitarFicha(afuera3);		
		Ficha afuera4 = enTurno.getNido().sacarFicha();
		enTurno.getNido().quitarFicha(afuera4);	
		afuera1.setPosicion(75);
		afuera2.setPosicion(70);
		afuera3.setPosicion(71);
		afuera4.setPosicion(72);
		try {
			juego.jugar(afuera2, 6);
			juego.jugar(afuera3, 5);
			juego.jugar(afuera1, 1);
			assertFalse(juego.ganador());
		} catch (PoobchisException pe) {
			pe.getMessage();
		} 
	}
	
	@Test
	public void esPosibleJugarConAlgunaFicha() {
		assertTrue(juego.esPosibleJugar(5));
	}
	
	@Test
	public void noEsPosibleJugarConAlgunaFicha() {
		assertFalse(juego.esPosibleJugar(6));
	}
	
	@Test
	public void deberiaObtenerCasillaSeguraMasCercana() {
		Jugador enTurno = juego.getJugadorEnTurno();
		Ficha afuera1 = enTurno.getNido().sacarFicha();
		enTurno.getNido().quitarFicha(afuera1);
		afuera1.setPosicion(36);
		assertTrue((46-36) == juego.getTableroJuego().getSeguroCercano(afuera1));
	}
	
	@Test
	public void deberiaDevolverLaFichaMasCercaPorAtras() {
		Jugador enTurno = juego.getJugadorEnTurno();
		Ficha afuera1 = enTurno.getNido().sacarFicha();
		enTurno.getNido().quitarFicha(afuera1);
		afuera1.setPosicion(36);
		juego.getTableroJuego().getCasilla(36).addFicha(afuera1);
		Ficha afuera2 = enTurno.getNido().sacarFicha();
		enTurno.getNido().quitarFicha(afuera2);
		afuera2.setPosicion(47);
		juego.getTableroJuego().getCasilla(47).addFicha(afuera2);
		Ficha fichaAtraida = juego.getTableroJuego().getFichaAtraida(afuera2);
		assertEquals(afuera1, fichaAtraida);
		assertTrue(11 == juego.getTableroJuego().valorAMoverFichaAtraida(fichaAtraida, afuera2));
	}
	
	@Test
	public void deberiaHaberGanadorAlAbandonarPartida() {
		Jugador enTurno = juego.getJugadorEnTurno();
		Ficha afuera1 = enTurno.getNido().sacarFicha();
		enTurno.getNido().quitarFicha(afuera1);
		afuera1.setPosicion(36);
		Ficha afuera2 = enTurno.getNido().sacarFicha();
		enTurno.getNido().quitarFicha(afuera2);
		afuera2.setPosicion(47);
		Ficha afuera3 = enTurno.getNido().sacarFicha();
		enTurno.getNido().quitarFicha(afuera3);
		afuera3.setPosicion(12);
		juego.getTableroJuego().getCasilla(36).addFicha(afuera1);
		juego.getTableroJuego().getCasilla(47).addFicha(afuera2);
		juego.getTableroJuego().getCasilla(12).addFicha(afuera3);
		ArrayList <Dado> dados = juego.getTableroJuego().getDados();
		for (Dado dado : dados) {
			dado.setSeHaJugado(true);
		}
		juego.cambiarTurno();
		Jugador nuevoJugador =  juego.getJugadorEnTurno();
		Ficha afuera11 = nuevoJugador.getNido().sacarFicha();
		nuevoJugador.getNido().quitarFicha(afuera11);
		afuera11.setPosicion(56);
		Ficha afuera22 = nuevoJugador.getNido().sacarFicha();
		nuevoJugador.getNido().quitarFicha(afuera22);
		afuera22.setPosicion(7);
		Ficha afuera33 = nuevoJugador.getNido().sacarFicha();
		nuevoJugador.getNido().quitarFicha(afuera33);
		afuera33.setPosicion(10);
		juego.getTableroJuego().getCasilla(56).addFicha(afuera11);
		juego.getTableroJuego().getCasilla(7).addFicha(afuera22);
		juego.getTableroJuego().getCasilla(10).addFicha(afuera33);
		assertEquals(juego.ganadorPartidaAbandonada(),enTurno);
	}
	
	@Test
	public void deberiaHaberGanadorAlAbandonarPartida2() {
		Jugador enTurno = juego.getJugadorEnTurno();
		Ficha afuera1 = enTurno.getNido().sacarFicha();
		enTurno.getNido().quitarFicha(afuera1);
		afuera1.setPosicion(36);
		Ficha afuera2 = enTurno.getNido().sacarFicha();
		enTurno.getNido().quitarFicha(afuera2);
		afuera2.setPosicion(22);
		Ficha afuera3 = enTurno.getNido().sacarFicha();
		enTurno.getNido().quitarFicha(afuera3);
		afuera3.setPosicion(12);
		juego.getTableroJuego().getCasilla(36).addFicha(afuera1);
		juego.getTableroJuego().getCasilla(22).addFicha(afuera2);
		juego.getTableroJuego().getCasilla(12).addFicha(afuera3);
		ArrayList <Dado> dados = juego.getTableroJuego().getDados();
		for (Dado dado : dados) {
			dado.setSeHaJugado(true);
		}
		juego.cambiarTurno();
		Jugador nuevoJugador =  juego.getJugadorEnTurno();
		Ficha afuera11 = nuevoJugador.getNido().sacarFicha();
		nuevoJugador.getNido().quitarFicha(afuera11);
		afuera11.setPosicion(56);
		Ficha afuera22 = nuevoJugador.getNido().sacarFicha();
		nuevoJugador.getNido().quitarFicha(afuera22);
		afuera22.setPosicion(51);
		Ficha afuera33 = nuevoJugador.getNido().sacarFicha();
		nuevoJugador.getNido().quitarFicha(afuera33);
		afuera33.setPosicion(10);
		juego.getTableroJuego().getCasilla(56).addFicha(afuera11);
		juego.getTableroJuego().getCasilla(51).addFicha(afuera22);
		juego.getTableroJuego().getCasilla(10).addFicha(afuera33);
		assertEquals(juego.ganadorPartidaAbandonada(),nuevoJugador);
	}
}
