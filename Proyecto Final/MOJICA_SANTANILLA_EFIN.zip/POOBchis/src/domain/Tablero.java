package domain;

import java.awt.Color;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import domain.fichas.Aspiradora;
import domain.fichas.Cohete;
import domain.fichas.Ficha;

/**
 * Clase que representa el tablero de juego.
 * @author Angie Mojica - Daniel Santanilla.
 * @version 0.4
 */
public class Tablero implements Serializable{
	
	private Casilla[] tablero;
	private ArrayList<Jugador> jugadores;
	private ArrayList<Ficha> fichas = new ArrayList<Ficha>();
	private ArrayList<Dado> dados = new ArrayList<Dado>();
	
	/**
	 * Constructor del tablero.
	 * @param nuevosJugadores Lista de jugadores en el tablero
	 * @param nuevosComodines Lista con los comodines que se jugaran en el tablero.
	 */
	public Tablero(ArrayList<Jugador> nuevosJugadores, List<String> nuevosComodines) {
		dados.add(new Dado());
		dados.add(new Dado());
		tablero = new Casilla[101];
		jugadores = nuevosJugadores;
		for (Jugador jugador : nuevosJugadores) {
			fichas.addAll(jugador.getFichas());
		}
		for (int i = 0; i < tablero.length; i++) {
			if (i ==  5 || i == 22 || i == 39 || i == 56) {
				tablero[i] = new Casilla("Salida", i);
			} else if (i==12 || i==17 || i==29 || i==34 || i==46 || i==51 || i==63 || i==68) {
				tablero[i] = new Casilla("Seguro", i);
			} else if (i == 9 || i == 26 || i == 43 || i == 60) {
				Casilla casillaComodin = new Casilla("Comodin", i);
				casillaComodin.setComodin(nuevosComodines);
				tablero[i] = casillaComodin;
			} else {
				tablero[i] = new Casilla("Normal", i);
			}
		}
	}
	
	/**
	 * Verifica si al caer en una casilla se puede comer ficha del oponente
	 * @param casilla Casilla actual 
	 * @param jugador Jugador que llega a la casilla
	 * @return True si habia ficha de oponente y come, false de lo contrario.
	 */
	public boolean comer(Casilla casilla, Jugador jugador) {
		Jugador opuesto = jugadorOpuesto(casilla, jugador);
		boolean comio = false;
		Casilla jugada = casilla;
		if (!(jugada.getTipo().equals("Seguro") || jugada.getTipo().equals("Salida"))) {
			if (jugada.catidadFichas() == 2) {
				if (opuesto != null) {
					Ficha ficha = jugada.obtenerFicha(opuesto);
					if (!ficha.esInmortal()) {
						jugada.quitarFicha(ficha);
						ficha.setPosicion(0);
						opuesto.getNido().addFicha(ficha);
						comio = true;
					}
				}
			}
		}
		return comio;
	}
	
	/**
	 * Obtiene el jugador opuesto de la casilla, dado un jugador.
	 * @param casilla Casilla a hallar el jugador opuesto.
	 * @param jugador Jugador que se quiere hallar su opuesto
	 * @return Jugador opuesto al jugador ingresado por parametro.
	 */
	public Jugador jugadorOpuesto(Casilla casilla,Jugador jugador) {
		Jugador jugadorOpuesto = null;
		Color colorJugador = jugador.getColor();
		for (Ficha ficha : casilla.getFichas()) {
			Color colorFicha = ficha.getColor();
			if (!colorJugador.equals(colorFicha)) {
				jugadorOpuesto = getJugador(colorFicha); 
			}
		}
		return jugadorOpuesto;
	}
	
	/**
	 * Obtiene la casilla de salida del jugador
	 * @param jugador Jugador a consultar su casilla de salida
	 * @return Casilla de salida del jugador.
	 */
	public Casilla casillaSalida(Jugador jugador) {
		Color color = jugador.getColor();
		Casilla salida;
		if (color.equals(Color.YELLOW)) {
			salida = tablero[5];
		} else if (color.equals(Color.BLUE)) {
			salida = tablero[22];
		} else if (color.equals(Color.RED)) {
			salida = tablero[39];
		} else {
			salida = tablero[56];
		}
		return salida;
	}
	
	/**
	 * Agrega una ficha a una casilla.
	 * @param casilla Casilla en la cual se quiere poner la ficha.
	 * @param ficha Ficha a agregar.
	 */
	public void poneFichaEnCasilla(Casilla casilla, Ficha ficha) {
		casilla.addFicha(ficha);
	}
	
	/**
	 * Obtiene la casilla de una posicion en el tablero.
	 * @param posicion Posicion de la casilla en el tablero.
	 * @return Casilla que esta en dicha posicion.
	 */
	public Casilla getCasilla(int posicion) {
		return tablero[posicion];
	}
	
	/**
	 * Obtiene el jugador especificado por su color.
	 * @param color Color para hallar el jugador.
	 * @return Jugador del color especificado.
	 */
	public Jugador getJugador(Color color) {
		Jugador obtenido = null;
		for (Jugador jugador : getJugadores()) {
			if (jugador.getColor().equals(color)) {
				obtenido = jugador;
			}
		}
		return obtenido;
	}
	
	/**
	 * Obtiene los jugadores del tablero.
	 * @return Lista de jugadores.
	 */
	public ArrayList<Jugador> getJugadores() {
		return jugadores;
	}
	
	/**
	 * Obtiene las fichas contenidas en el tablero.
	 * @return Lista de fichas contenidas en el tablero.
	 */
	public ArrayList<Ficha> getFichas() {
		return fichas;
	}
	
	/**
	 * Obtiene la casilla siguiente a una especificada.
	 * @param casilla Casilla a la que se quiere hallar siguente.
	 * @param color Color del jugador.
	 * @return Casilla siguiente a la casilla espeficada.
	 */
	public Casilla siguienteCasilla(Casilla casilla, Color color) {
		int posicion = casilla.getPosicion();
		int siguiente;
		if (posicion != 68) {
			siguiente = posicion + 1;
		} else {
			siguiente = 1;
		}
		if (color.equals(Color.BLUE) && posicion == 17) {
			siguiente = 69;
		} else if (color.equals(Color.RED) && posicion == 34) {
			siguiente = 77;
		} else if (color.equals(Color.GREEN) && posicion == 51) {
			siguiente = 85;
		} else if (color.equals(Color.YELLOW) && posicion == 68) {
			siguiente = 93;
		}
		return tablero[siguiente];
	}
	
	/**
	 * Obtiene la casilla anterior a una especificada.
	 * @param casilla Casilla a la que se quiere hallar anterior.
	 * @param color Color del jugador.
	 * @return Casilla anterior a la casilla especificada.
	 */
	public Casilla anteriorCasilla(Casilla casilla, Color color) {
		int posicion = casilla.getPosicion();
		int anterior;
		if (posicion != 1) {
			anterior = posicion - 1;
		} else {
			anterior = 68;
		}
		if (color.equals(Color.BLUE) && posicion == 69) {
			anterior = 17;
		} else if (color.equals(Color.RED) && posicion == 77) {
			anterior = 34;
		} else if (color.equals(Color.GREEN) && posicion == 81) {
			anterior = 51;
		} else if (color.equals(Color.YELLOW) && posicion == 93) {
			anterior = 68;
		}
		return tablero[anterior];
	}
	
	/**
	 * Obtiene el tablero de juego.
	 * @return Lista de casillas que componen al tablero.
	 */
	public Casilla[] getRegilla() {
		return tablero;
	}
	
	/**
	 * Obtiene el valor a mover en una ficha atraida por la ficha {@link Aspiradora}.
	 * es dedir, se halla la distancia entre las fichas.
	 * @param fichaAtraida Ficha es atraida.
	 * @param fichaObjetivo Ficha objetivo de la ficha atraida.
	 * @return Entero con el valor a mover por la ficha atraida.
	 */
	public int valorAMoverFichaAtraida(Ficha fichaAtraida, Ficha fichaObjetivo) {
		Casilla salida = tablero[fichaAtraida.getPosicion()];
		Casilla objetivo = tablero[fichaObjetivo.getPosicion()];
		return distanciaEntreCasillas(salida, objetivo, fichaObjetivo.getColor());
	}
	
	/**
	 * Obtiene la ficha atraida por una ficha {@link Aspiradora},
	 * esto va limidado por 12 casillas de rango.
	 * @param ficha Ficha aspiradora.
	 * @return Ficha atraida por la ficha aspiradora.
	 */
	public Ficha getFichaAtraida(Ficha ficha) {
		int limitePoder = 12;
		int posFicha = ficha.getPosicion();
		Casilla actual = anteriorCasilla(tablero[posFicha], ficha.getColor());
		Ficha fichaAtraida = null;
		Color colorAspiradora = ficha.getColor();
		while (limitePoder > 0) {
			for (Ficha fichaCasilla : actual.getFichas()) {
				Color colorPosible = fichaCasilla.getColor();
				if (colorPosible.equals(colorAspiradora)) {
					fichaAtraida = fichaCasilla;
					return fichaAtraida;
				}
			}
			Casilla anterior = anteriorCasilla(actual, ficha.getColor()); 
			actual = anterior;
			limitePoder -= 1;
		}
		return fichaAtraida;
	}
	
	/**
	 * Obtiene el seguro mas cercano para una ficha {@link Cohete}.
	 * @param ficha Ficha que se quiere encontrar su seguro cercano.
	 * @return Entero con la distancia entre la posicion de la ficha y el seguro.
	 */
	public int getSeguroCercano(Ficha ficha) {
		int posFicha = ficha.getPosicion();
		Casilla actual = tablero[posFicha];
		while (actual.getPosicion() != ficha.getLlegada()) {
			Casilla siguiente = siguienteCasilla(actual, ficha.getColor());
			actual = siguiente;
			if (actual.getTipo().equals("Seguro")) {
				return distanciaEntreCasillas(tablero[posFicha], actual, ficha.getColor());
			}
		}
		return 0;
	}
	
	/**
	 * Distancia entre dos casillas, se indica una casilla de salida y una casilla objetivo,
	 * ademas, se indica un color de referencia.
	 * @param salida Casilla de donde se quiere salir.
	 * @param objetivo Casilla a donde se quiere llegar.
	 * @param referencia Color de referencia.
	 * @return Entero con la distancia enter la casilla de salida y la objetivo.
	 */
	public int distanciaEntreCasillas(Casilla salida, Casilla objetivo, Color referencia) {
		int contador = 0;
		Casilla actual = salida;
		while (actual.getPosicion() != objetivo.getPosicion()) {
			Casilla siguiente = siguienteCasilla(actual, referencia);
			actual = siguiente;
			contador += 1;
		}
		return contador;
	}
	
	public ArrayList<Dado> getDados() {
		return dados;
	}
	
	/**
	 * Obtiene valores aleatorios para los dados
	 * @return Array con dos valores de los dados.
	 */
	public void lanzarDados() {
		for (Dado dado : dados) {
			dado.lanzar();
		}
	}
	
	/**
	 * Verifica si el valor obtenido en los dados es par.
	 * @return True si los valores son iguales, false si no.
	 */
	public boolean esPar() {
		return (dados.get(0).getValor() == dados.get(1).getValor() ? true : false);
	}

	/**
	 * Reinica los dados del tablero.
	 */
	public void reiniciaDados() {
		for (Dado dado : dados) {
			dado.setSeHaJugado(false);
		}
	}
	
	/**
	 * Indica el numero de dados jugados.
	 * @return Entero con el numero de dados jugados.
	 */
	public int numeroDadosJugados() {
		int numJugados = 0;
		for (Dado dado : dados) {
			if (dado.seHaJugado()) {
				numJugados += 1;
			}
		}
		return numJugados;
	}
	
}
