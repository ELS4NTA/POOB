package domain.fichas;
import java.awt.Color;
import java.io.Serializable;

import domain.PoobchisException;
import domain.Tablero;
/**
 * Clase que representa a una {@link Ficha} Aspiradora\n
 * Trae la ficha (del mismo equipo) que est� casillas atr�s m�s cerca de ella; 
 * y la lleva a la misma casilla donde est� la ficha aspiradora
 * @author Angie Mojica - Daniel Santanilla
 * @Version 0.4
 */
public class Aspiradora extends Ficha implements Serializable{
	
	/**
	 * Crea una ficha Aspiradora
	 * @param color Color de la ficha
	 */
	public Aspiradora(Color color) {
		super(color);
	}
	
	/**
	 * Ver tambien {@inheritDoc}
	 */
	@Override
	public void setNumPoder() {
		poderUsado = 2;
	}
	
	/**
	 * Ver tambien {@inheritDoc}
	 */
	@Override
	public void poderUsado(Tablero tablero) {
		Ficha atraida = tablero.getFichaAtraida(this);
		if (atraida != null) {
			int distanciaAtraida = tablero.valorAMoverFichaAtraida(atraida, this);
			if (sePuedeMover(atraida, distanciaAtraida, tablero)) {
				try {
					mover(tablero.getJugador(getColor()), atraida, distanciaAtraida, tablero);
				} catch (PoobchisException e) {
					e.printStackTrace();
				}
			}
			poderUsado -= 1;
		} 
	}
	
	/**
	 * Ver tambien {@inheritDoc}
	 */
	@Override
	public String getTipo() {
		return "Aspiradora";
	}
}
