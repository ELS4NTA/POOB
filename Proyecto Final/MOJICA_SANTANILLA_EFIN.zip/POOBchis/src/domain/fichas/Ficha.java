package domain.fichas;
import java.awt.Color;
import java.io.Serializable;

import domain.Casilla;
import domain.Jugador;
import domain.PoobchisException;
import domain.Tablero;

/**
 * Clase que representa a una ficha en el juego de Poobchis\n
 * Avanza a lo largo del tablero seg�n el valor que le indica el jugador
 * @author Angie Mojica - Daniel Santanilla
 * @Version 0.4
 */
public class Ficha implements Serializable{
	
	protected Color color;
	protected int posicion;
	protected final int meta;
	protected final int llegada;
	protected int poderUsado;
	protected boolean esInmortal;
	
	/**
	 * Constructor de la ficha.
	 * @param color Color que identifica la ficha.
	 */
	public Ficha(Color color) {
		if (color.equals(Color.BLUE)) {
			this.meta = 17;
			this.llegada = 76;
		} else if (color.equals(Color.RED)) {
			this.meta = 34;
			this.llegada = 84;
		} else if (color.equals(Color.GREEN)) {
			this.meta = 51;
			this.llegada = 92;
		} else {
			this.meta = 68;
			this.llegada = 100;
		}
		this.esInmortal = false;
		this.setNumPoder();
		this.color = color;
		this.posicion = 0;
	}
	
	/**
	 * Realiza el movimiento de la ficha.
	 * @param jugador Jugador que realiza el movimiento.
	 * @param ficha Ficha proxima a mover.
	 * @param valorAMover Valor del dado y con el que se movera la ficha.
	 * @param tablero Tablero del juego.
	 * @return actual Casilla correspondiente a la ultima despues de moverse.
	 * @throws PoobchisException NO_ES_TU_FICHA cuando se selecciona una ficha diferente a la del jugador en turno.
	 * @throws PoobchisException NO_SE_PUEDE_MOVER cuando la ficha seleccionada no tiene un camino para moverse.
	 */
	public Casilla mover(Jugador jugador, Ficha ficha, int valorAMover, Tablero tablero) throws PoobchisException {
		Casilla actual = tablero.getCasilla(ficha.getPosicion());
		if (!jugador.getNido().contieneFicha(ficha)) {
			if (!jugador.getColor().equals(ficha.getColor())) {
				throw new PoobchisException(PoobchisException.NO_ES_TU_FICHA);
			}
			if (sePuedeMover(ficha, valorAMover, tablero)) {
				while (valorAMover > 0) {
					Casilla siguiente = tablero.siguienteCasilla(actual, ficha.getColor());
					actual.quitarFicha(ficha);
					ficha.setPosicion(siguiente.getPosicion());
					siguiente.addFicha(ficha);
					actual = siguiente;
					// por cada ficha hacer refresh del tablero para que se vea que se esta moviendo de 1 en 1
					valorAMover -= 1;
				}
			} else {
				throw new PoobchisException(PoobchisException.NO_SE_PUEDE_MOVER);
			}
		}
		return actual;
	}
	
	/**
	 * Verifica si una ficha se puede mover el valor de casillas indicado por el dado
	 * @param ficha Ficha a mover
	 * @param valorAMover Cantidad de casillas a recorrer
	 * @param tablero Tablero del juego
	 * @return True si no hay obstaculos o movimientos sobrantes al moverse, de lo contario false.
	 */
	public boolean sePuedeMover(Ficha ficha, int valorAMover, Tablero tablero) {
		Casilla actual = tablero.getCasilla(ficha.getPosicion());
		int llegada = ficha.getLlegada();
		if (ficha.getPosicion() == 0 && valorAMover != 5) {
			return false;
		}
		while (valorAMover > 0) {
			if (actual.getPosicion() != llegada) {
				Casilla siguiente = tablero.siguienteCasilla(actual, ficha.getColor());
				if (!siguiente.estaBloqueada()) {
					actual = siguiente;
				} else {
					return false;
				}
			} else {
				return false;
			}
			valorAMover -= 1;
		}
		return true;
	}
	
	/**
	 * Verifica si una ficha se puede salir segun el jugador indicado
	 * @param ficha Ficha de verificacion
	 * @param jugador Jugador que desea salir con la ficha.
	 * @param tablero Tablero de juego
	 * @return True si se puede salir, de lo contrario False.
	 */
	public boolean puedeSalir(Ficha ficha, Jugador jugador, Tablero tablero) {
		Casilla salida = tablero.casillaSalida(jugador);
		int cantFichas = salida.contarMisFichas(jugador);
		if (cantFichas != 2) {
			return true;
		}
		return false;
	}
	
	/**
	 * Obtiene el color de la ficha.
	 * @return color Color de la ficha.
	 */
	public Color getColor() {
		return this.color;
	}
	
	/**
	 * Actualiza la posicion de la ficha
	 * @param posicion Posicion nueva de la ficha
	 */
	public void setPosicion(int posicion) {
		this.posicion = posicion;
	}
	
	/**
	 * Obtiene la posicion actual de la ficha.
	 * @return Entero con la posicion de la ficha.
	 */
	public int getPosicion() {
		return this.posicion;
	}
	
	/**
	 * Obtiene la posicion de la casilla Meta de la ficha, es decir, 
	 * el seguro antes de iniciar el pasillo de coronacion.
	 * @return Entero con el valor de la casilla meta correspondiente a la ficha.
	 */
	public int getMeta() {
		return this.meta;
	}
	
	/**
	 * Obtiene la posicion de la casilla de llegada de la ficha, 
	 * es decir, la casilla de coronacion de la ficha.
	 * @return Entero con el valor de la casilla de llegada correspondiente a la ficha.
	 */
	public int getLlegada()  {
		return this.llegada;
	}
	
	/**
	 * Obtiene el tipo de ficha
	 * @return Cadnea con el tipo de la ficha.
	 */
	public String getTipo() {
		return "Ficha";
	}
	
	/**
	 * Asigna un numero de poderes que puede usar.
	 */
	public void setNumPoder() {
		poderUsado = 0;
	}
	
	/**
	 * Usa el poder de la ficha
	 * @param tablero TODO
	 * 
	 */
	public void poderUsado(Tablero tablero) {}

	/**
	 * Obtiene el numero de poderes usados.
	 * @return Entero con la cantidad restante de poderes a usar.
	 */
	public int getPoderUsado() {
 		return poderUsado;
	}
	
	/**
	 * Hace que una ficha sea inmortal en el tablero.
	 */
	public void setInmortalidad() {
		this.esInmortal = true;
	}
	
	/**
	 * Dice si una ficha es inmortal
	 * @return True si la ficha es inmortal, de lo contrario False.
	 */
	public boolean esInmortal() {
		return esInmortal;
	}
}
