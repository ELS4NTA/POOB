package domain;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Maquina extends Jugador {
	

	public Maquina(String nombre, Color color, List<String> equipo, int identi) {
		super(nombre, color, equipo, false, identi, false);

		// TODO Auto-generated constructor stub
	}

}
