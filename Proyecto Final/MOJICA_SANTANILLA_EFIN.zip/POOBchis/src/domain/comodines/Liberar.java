package domain.comodines;

import java.io.Serializable;

import javax.swing.JOptionPane;

import domain.Carcel;
import domain.Jugador;
import domain.Poobchis;
import domain.fichas.Ficha;

/**
 * Clase que represneta un {@link Comodin} Liberar
 * @author Angie Mojica - Daniel Santanilla
 * @version 0.4
 */
public class Liberar extends Comodin implements Serializable{
	
	/**
	 * El equipo del color correspondiente a la ficha que adquiere este comodin, 
	 * podra liberar una de sus fichas solo si tiene fichas en la carcel.
	 * Ver tambien {@inheritDoc}
	 */
	@Override
	public void especial(Poobchis currentGame, Ficha ficha) {
		JOptionPane.showMessageDialog(null, "Se ha liberado una ficha.","Buena Suerte",1);
		Jugador jugador = currentGame.getJugadorEnTurno();
		Carcel carcel = jugador.getNido();
		if (carcel.getTamanno() != 0) {
			Ficha aSalir = carcel.sacarFicha();
			currentGame.sacarFicha(currentGame.getJugadorEnTurno(), aSalir);
		}
		
	}

}
