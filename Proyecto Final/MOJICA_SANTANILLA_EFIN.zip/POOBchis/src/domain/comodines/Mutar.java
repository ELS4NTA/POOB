package domain.comodines;

import java.awt.Color;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JOptionPane;

import domain.Casilla;
import domain.Poobchis;
import domain.fichas.Ficha;
import presentation.PaintPicture;
import presentation.TableroGUI;

/**
 * Clase que representa un {@link Comodin} Mutar
 * @author Angie Mojica - Daniel Santanilla
 * @version 0.4
 */
public class Mutar extends Comodin implements Serializable{
	
	private PaintPicture impresora = PaintPicture.getPrinter();
	
	/**
	 * La ficha cambia de tipo transformandose en una seleccionada 
	 * aleatoriamente entre las que no tenga el jugador en turno.
	 * Ver tambien {@inheritDoc}
	 */
	@Override
	public void especial(Poobchis currentGame, Ficha ficha) {
//		HashMap<Color, String> colorMap = new HashMap<Color, String>();
//	    colorMap.put(Color.BLUE, "azul");
//	    colorMap.put(Color.RED, "rojo");
//	    colorMap.put(Color.YELLOW, "amarillo");
//	    colorMap.put(Color.GREEN, "verde");
//		String[] fichasNombre = {"Ficha","Cohete","Aspiradora","Saltarina","Ventajosa","Ingeniera"};
//		int index = currentGame.getTableroJuego().getFichas().indexOf(ficha);
//		ArrayList<String> tipos = new ArrayList<String>();
//		ArrayList<JButton> botonesFicha = TableroGUI.getBotonesFichas();
//		JButton boton = botonesFicha.get(index);
//		List<String> fichasNoExistentes = new ArrayList<String>();
//		for (Ficha losTipos : currentGame.getJugadorEnTurno().getFichas()) {
//			tipos.add(losTipos.getTipo());
//		}
//		for (int i = 0; i < fichasNombre.length; i++) {
//			if (!tipos.contains(fichasNombre[i])) {
//				fichasNoExistentes.add(fichasNombre[i]);
//			}
//		}
//		int rand = (int)(Math.random()*fichasNoExistentes.size());
//		String seleccionada = fichasNoExistentes.get(rand);
//		try {
//			JOptionPane.showMessageDialog(null, "Ahora tu ficha es "+seleccionada+".","Mutacion",1);
//			Ficha fichaNueva = (Ficha) Class.forName("domain.fichas."+seleccionada).getDeclaredConstructor(Color.class).newInstance(ficha.getColor());
//			fichaNueva.setPosicion(ficha.getPosicion());
//			boton.addActionListener(new ButtonFichaListener(boton, fichaNueva, null, currentGame, null));
//			impresora.pintarImagen(boton, "./img/"+colorMap.get(fichaNueva.getColor())+"/"+fichaNueva.getTipo()+".png", 20, 20);
//			Casilla casilla = currentGame.getTableroJuego().getCasilla(ficha.getPosicion());
//			casilla.quitarFicha(ficha);
//			ficha = fichaNueva;
//			casilla.addFicha(ficha);
//		} catch (InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException
//				| NoSuchMethodException | SecurityException | ClassNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
	}

}
