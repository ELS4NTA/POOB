package domain.comodines;

import java.io.Serializable;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import domain.Casilla;
import domain.Jugador;
import domain.Poobchis;
import domain.fichas.Ficha;

/**
 * Clase que representa un {@link Comodin} Eliminar
 * @author Angie Mojica - Daniel Santanilla
 * @version 0.4
 */
public class Eliminar extends Comodin implements Serializable{

	/**
	 * La ficha mas avanzada de su oponente se envia a la carcel.
	 * Ver tambien {@inheritDoc}
	 */
	@Override
	public void especial(Poobchis currentGame, Ficha ficha) {
		JOptionPane.showMessageDialog(null, "Un tornado ha enviado la ficha mas avanzada del oponente a la carcel.","Tornado",1);
		ArrayList<Jugador> listaJugadores = currentGame.getTableroJuego().getJugadores();
		Jugador enTurno = currentGame.getJugadorEnTurno();
		Jugador jugadorRandom = null;
		for (Jugador jugador : listaJugadores) {
			if (!jugador.equals(enTurno)) {
				jugadorRandom = jugador;
			}
		}
		int llegada = jugadorRandom.getFichas().get(0).getLlegada();
		Casilla[] tablero = currentGame.getTableroJuego().getRegilla();
		Casilla actual = tablero[llegada-1];
		Casilla salida = currentGame.getTableroJuego().casillaSalida(jugadorRandom);
		while (actual.getPosicion() !=  salida.getPosicion()) {
			for (Ficha fichaQuitar : actual.getFichas()) {
				if (fichaQuitar.getColor().equals(jugadorRandom.getColor())) {
					fichaQuitar.setPosicion(0);
					actual.quitarFicha(fichaQuitar);
					jugadorRandom.getNido().addFicha(fichaQuitar);
					break;
				}
			}
			Casilla anterior = currentGame.getTableroJuego().anteriorCasilla(actual, jugadorRandom.getColor());
			actual = anterior;
		}
		
	}

}
