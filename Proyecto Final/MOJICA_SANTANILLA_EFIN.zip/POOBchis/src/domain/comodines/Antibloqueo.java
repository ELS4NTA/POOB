package domain.comodines;

import java.io.Serializable;

import domain.Poobchis;
import domain.PoobchisException;
import domain.fichas.Ficha;

/**
 * Clase que representa un {@link Comodin} Antibloqueo.
 * 
 * @author Angie Mojica - Daniel Santanilla
 * @version 0.4
 */
public class Antibloqueo extends Comodin implements Serializable{
	
	/**
	 * Si hay bloqueos en el tablero, se rompe el bloqueo de fichas 
	 * mas proximo a la casilla donde se obtuvo el comod�n
	 * Ver tambien {@inheritDoc}
	 */
	@Override
	public void especial(Poobchis currentGame, Ficha ficha) throws PoobchisException {
		// TODO Auto-generated method stub
		
	}

}
