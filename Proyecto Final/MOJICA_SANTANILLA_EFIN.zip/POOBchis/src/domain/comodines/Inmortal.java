package domain.comodines;

import java.io.Serializable;

import javax.swing.JOptionPane;

import domain.Poobchis;
import domain.fichas.Ficha;

/**
 * Clase que representa un {@link Comodin} Inmortar
 * @author Angie Mojica - Daniel Santanilla
 * @version 0.4
 */
public class Inmortal extends Comodin implements Serializable{
	
	/**
	 * Si se obtiene este comodin, nadie puede matar a la ficha que lo obtuvo.
	 * Ver tambien {@inheritDoc}
	 */
	@Override
	public void especial(Poobchis currentGame, Ficha ficha) {
		JOptionPane.showMessageDialog(null, "Ahora tu ficha es inmortal.","Inmortalidad",1);
		ficha.setInmortalidad();
		
	}

}
