package domain;

import java.util.ArrayList;

public class Carcel {
	
	private ArrayList<Ficha> fichas;
	
	public Carcel(ArrayList<Ficha> fichasJugador) {
		this.fichas = fichasJugador;
	}
	
	public ArrayList<Ficha> getFichas() {
		return this.fichas;
	}
	
	public void addFicha(Ficha nuevaFicha) {
		fichas.add(nuevaFicha);
	}
	
	public Ficha sacarFicha() {
		Ficha ficha = fichas.get(0);
		fichas.remove(0);
		return ficha;
	}
	
	public boolean estaVacia() {
		return fichas.isEmpty();
	}
}
