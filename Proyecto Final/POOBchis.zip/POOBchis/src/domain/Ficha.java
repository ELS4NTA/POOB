package domain;

public class Ficha {
	
	private String color;
	private int posicion;
	private final int meta;
	private final int llegada;
	
	public Ficha(String color) {
		if (color.equals("Azul")) {
			this.meta = 17;
			this.llegada = 76;
		} else if (color.equals("Rojo")) {
			this.meta = 34;
			this.llegada = 84;
		} else if (color.equals("Verde")) {
			this.meta = 51;
			this.llegada = 92;
		} else {
			this.meta = 68;
			this.llegada = 100;
		}
		
		this.color = color;
		this.posicion = 0;
	}
	
	public String getColor() {
		return this.color;
	}
	
	public void setPosicion(int posicion) {
		this.posicion = posicion;
	}
	
	public int getPosicion() {
		return this.posicion;
	}
	
	public int getMeta() {
		return this.meta;
	}
	
	public int getLlegada()  {
		return this.llegada;
	}
}
