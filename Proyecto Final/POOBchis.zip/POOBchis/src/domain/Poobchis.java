package domain;

public class Poobchis {

}
// implementar el juego en el tablero con todas las reglas