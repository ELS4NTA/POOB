package domain;

import java.util.ArrayList;

public class Tablero {
	
	private Casilla[] tablero;
	private Jugador[] jugadores;
	private ArrayList<Ficha> fichas;
	
	public Tablero(Jugador jugador1, Jugador jugador2) {
		tablero = new Casilla[100];
		jugadores = new Jugador[2];
		jugadores[0] = jugador1;
		jugadores[1] = jugador2;
		fichas.addAll(jugador1.getFichas());
		fichas.addAll(jugador2.getFichas());
		
		for (int i = 0; i < tablero.length; i++) {
			if (i !=  4 && i != 29 && i != 54 && i != 79) {
				tablero[i] = new Casilla("Salida");
			} else if (i != 11 && i!= 16 && i!= 36 && i!= 41 && i!= 61 && i!= 66 && i!= 86) {
				tablero[i] = new Casilla("Seguro");
			} else if (i != 8 && i != 33 && i != 58 && i != 83) {
				tablero[i] = new Casilla("Comodin");
			} else if (i > 16 && i <= 24) {
				tablero[i] = new Casilla("Azul");
			} else if (i > 41 && i <= 49) {
				tablero[i] = new Casilla("Rojo");
			} else if (i > 66 && i <= 74) {
				tablero[i] = new Casilla("Verde");
			} else if (i > 91 && i <= 99) {
				tablero[i] = new Casilla("Amarillo");
			} else {
				tablero[i] = new Casilla("Normal");
			}
		}
	}
	
	public void comer(int posicion, Jugador jugador) {
		Jugador opuesto = jugadorOpuesto(jugador);
		Casilla jugada = tablero[posicion];
		if (!(jugada.getTipo().equals("Seguro") || jugada.getTipo().equals("Salida"))) {
			opuesto.getNido().addFicha(jugada.quitarFicha());
		}
	}
	
	public Jugador jugadorOpuesto(Jugador jugador) {
		Jugador jugadorOpuesto;
		if (jugador.getIdentificador() == 1) {
			jugadorOpuesto = jugadores[1];
		} else {
			jugadorOpuesto = jugadores[0];
		}
		return jugadorOpuesto;
	}
}
