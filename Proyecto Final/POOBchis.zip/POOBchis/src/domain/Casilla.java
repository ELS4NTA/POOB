package domain;

import java.util.ArrayList;

public class Casilla {
	
	private String tipo;
	private boolean esBloqueada;
	private ArrayList<Ficha> fichas;
	
	public Casilla(String tipo) {
		this.tipo = tipo;
		this.esBloqueada = false;
	}
	
	public String getTipo() {
		return this.tipo;
	}
	
	public boolean estaBloqueada() {
		return this.esBloqueada;
	}
	
	public void setBloqueo(boolean bloqueo) {
		this.esBloqueada = bloqueo;
	}
	
	public ArrayList<Ficha> getFichas() {
		return this.fichas;
	}
	
	public void addFicha(Ficha ficha) {
		this.fichas.add(ficha);
	}
	
	public Ficha quitarFicha() {
		return this.fichas.remove(0);
	}
}
