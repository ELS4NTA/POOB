package domain;

import java.util.ArrayList;

public class Jugador {
	
	private boolean esHumano;
	private boolean enTurno;
	private int identificador;
	private ArrayList<Ficha> fichas;
	private String color;
	private String nombre;
	private Carcel nido;
	
	public Jugador(String nombre, String color, boolean humano, int identi, boolean turno) {
		this.esHumano = humano;
		this.enTurno = turno;
		this.identificador = identi;
		this.color = color;
		this.nombre = nombre;
		this.fichas = new ArrayList<Ficha>();
		for (int i = 0; i < fichas.size(); i++) {
			fichas.add(new Ficha("Normal", color));
		}
		this.nido = new Carcel(fichas);
		
	}
	
	public boolean estaEnTurno() {
		return this.enTurno;
	}
	
	public void setTurno(boolean turno) {
		this.enTurno = turno;
	}
	
	public int getIdentificador() {
		return this.identificador;
	}
	
	public String getNombre() {
		return this.nombre;
	}
	
	public String getColor() {
		return this.color;
	}
	
	public Carcel getNido() {
		return this.nido;
	}
	
	public ArrayList<Ficha> getFichas() {
		return this.fichas;
	}
	
	public int[] lanzarDados() {
		int[] valorEnDados = new int[2];
		int valorDado1 = (int)(Math.random()*6+1);
		int valorDado2 = (int)(Math.random()*6+1);
		valorEnDados[0] = valorDado1;
		valorEnDados[1] = valorDado2;
		return valorEnDados;
	}
	
}
