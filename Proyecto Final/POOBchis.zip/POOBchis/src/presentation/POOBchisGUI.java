package presentation;

import java.awt.*;
import java.awt.event.*;
import java.io.File;

import javax.swing.*;
import javax.swing.border.*;


/**
 * Presentacion del juego
 * @Autor Angie Mojica - Daniel Santanilla
 * @Version 12-04-22
 * */
public class POOBchisGUI extends JFrame{
	
	private CardLayout card;
	private JMenuBar barraMenu;
	private JMenu opciones;
	private JPanel principal;
	private JMenuItem nuevo, abrir, salvar, salir, regresar;
	private JFileChooser selectorArchivos;
	private JButton jugar, reglas, humano, maquina;
	private JLabel fondoPW, fondoCMW, fondoRW;

	private POOBchisGUI() {
		prepareElements();
		prepareActions();
	}
	// hacer cardlayout para manejar ventanas, poner botones de dados en fin....
	public void prepareElements() {
		card = new CardLayout();
		principal = new JPanel(card);
		setTitle("POOBCHIS");
		setSize(1080, 720);
		setLocationRelativeTo(null);
		setResizable(false);
		add(principal);
		preparePrincipalWindow();
		prepareChooseModeWindow();
		prepareRulesWindow();
		prepareElementsMenu();
		prepareGameHumansWindow();
		//prepareElementsBoard();
		card.show(principal, "FondoPW");
	    
	}
	
	public void preparePrincipalWindow() {
		fondoPW = new JLabel();
		JLabel titulo = new JLabel();
		jugar = new JButton("JUGAR");
	    reglas = new JButton("REGLAS");
		fondoPW.setBounds(0, 0, 1080, 720);
		jugar.setBounds(230, 350, 150, 80);
	    reglas.setBounds(600,350,150, 80);
	    pintarImagen(fondoPW, "./img/fondoPrincipal.jpg", 1080, 720);
	    titulo.setBounds(190, 60, 453, 202);
	    pintarImagen(titulo, "./img/titulo.gif", 453, 202);
	    fondoPW.add(titulo);
	    fondoPW.add(jugar);
	    fondoPW.add(reglas);
	    principal.add(fondoPW, "FondoPW");
	}
	
	public void prepareChooseModeWindow() {
		fondoCMW = new JLabel();
		fondoCMW.setVisible(false);
		JLabel titulo = new JLabel();
		JLabel imagenHumano = new JLabel();
		JLabel imagenMaquina = new JLabel();
		humano = new JButton("JUGADOR VS JUGADOR");
		maquina = new JButton("JUGADOR VS MAQUINA");
		fondoCMW.setBounds(0, 0, 1080, 720);
		titulo.setBounds(200, 40, 701, 199);
		imagenHumano.setBounds(250, 300, 150, 150);
		imagenMaquina.setBounds(680, 300, 150, 150);
		humano.setBounds(250, 500, 150, 80);
		maquina.setBounds(680,500,150, 80);
		
		pintarImagen(fondoCMW, "./img/fondoPrincipal.jpg", 1080, 720);
	    pintarImagen(titulo, "./img/modotitulo.png", 701, 199);
	    pintarImagen(imagenHumano, "./img/humanos.png", 150, 150);
	    pintarImagen(imagenMaquina, "./img/x.png", 150, 150);
	    
		fondoCMW.add(titulo);
		fondoCMW.add(imagenHumano);
		fondoCMW.add(imagenMaquina);
		fondoCMW.add(humano);
		fondoCMW.add(maquina);
		principal.add(fondoCMW, "FondoCMW");
	}
	
	private void prepareRulesWindow() {
		fondoRW = new JLabel();
		fondoRW.setVisible(true);
		fondoRW.setBounds(0, 0, 1080, 720);
		
		pintarImagen(fondoRW, "./img/fondoPrincipal.jpg", 1080, 720);
		
		principal.add(fondoRW, "FondoRW");
	}
	
	private void preprareGameBoardWindow() {
		
	}
	
	private void prepareGameHumansWindow() {
		
	}
	
	private void pintarImagen(JLabel label, String ruta, int ancho, int alto) {
		ImageIcon imagen = new ImageIcon(ruta);
		ImageIcon icon = new ImageIcon(imagen.getImage().getScaledInstance(ancho, alto, Image.SCALE_DEFAULT));
		label.setIcon(icon);
		repaint();
	}
	
	public void prepareElementsMenu() {
		barraMenu = new JMenuBar();
		opciones = new JMenu("Opciones");
		nuevo = new JMenuItem("Nuevo");
		abrir = new JMenuItem("Abrir");
		salvar = new JMenuItem("Guardar");
		salir = new JMenuItem("Salir");
		regresar = new JMenuItem("Regresar");
		opciones.add(nuevo);
		opciones.addSeparator();
		opciones.add(abrir);
		opciones.add(salvar);
		opciones.addSeparator();
		opciones.add(salir);
		barraMenu.add(opciones);
		barraMenu.add(regresar);
		selectorArchivos = new JFileChooser();
		setJMenuBar(barraMenu);
	}
	

	public void prepareActions() {
		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
            	actionClose();
            }
        });
		prepareActionsMenu();
		prepareActionsPrincipalWindow();
	}
	
	public void prepareActionsChooseModeWindow() {
		humano.addActionListener( new ActionListener(){
			public void actionPerformed( ActionEvent event) {
				actionGameHumans();
				} 
		});
		maquina.addActionListener( new ActionListener(){
			public void actionPerformed( ActionEvent event) {
				actionGameBot();
				} 
		});
	}
	
	public void prepareActionsPrincipalWindow() {
		jugar.addActionListener( new ActionListener(){
			public void actionPerformed( ActionEvent event) {
				actionPlay();
				} 
		});
		reglas.addActionListener( new ActionListener(){
			public void actionPerformed( ActionEvent event) {
				actionRules();
				} 
		});
	}
	
    public void prepareActionsMenu(){
    	abrir.addActionListener( new ActionListener(){ 
    		public void actionPerformed( ActionEvent event ){
            	actionOpen();
            } 
    	});
    	salvar.addActionListener( new ActionListener(){
            public void actionPerformed( ActionEvent event ){
            	actionSave();
            }
        });
        salir.addActionListener( new ActionListener(){
            public void actionPerformed( ActionEvent event ){
            	actionClose();
            }
        });
        regresar.addActionListener( new ActionListener(){
            public void actionPerformed( ActionEvent event ){
            	actionReturn();
            }
        });
    }
	
    public void actionOpen() {
    	File archivo = null;
    	selectorArchivos.setVisible(true);
    	int confirmation = selectorArchivos.showOpenDialog(abrir);
    	if (confirmation == selectorArchivos.APPROVE_OPTION) {
    		archivo = selectorArchivos.getSelectedFile();
    	}
    	JOptionPane.showMessageDialog(abrir, "La accion para abrir el archivo " + archivo.getName() + " esta en construccion.","Informacion",1);
    	selectorArchivos.setVisible(false);
    }
    
    
    public void actionSave() {
    	File archivo = null;
    	selectorArchivos.setVisible(true);
    	int confirmation = selectorArchivos.showSaveDialog(salvar);
    	if (confirmation == selectorArchivos.APPROVE_OPTION) {
    		archivo = selectorArchivos.getSelectedFile();
    	}
    	JOptionPane.showMessageDialog(salvar, "La accion para guardar el archivo " + archivo.getName() + " esta en construccion.","Informacion",1);
    	selectorArchivos.setVisible(false);
    }
    
	public void actionClose(){
        int confirmation = JOptionPane.showConfirmDialog(null,"�Seguro que desea salir?","Cerrar",0);
        if(confirmation == JOptionPane.YES_OPTION){
            System.exit(0);
        }
    }
	
	public void actionPlay() {
		card.show(principal, "FondoCMW");
	}
	
	public void actionRules() {
		card.show(principal, "FondoRW");
	}
	
	public void actionReturn() {
		if (fondoCMW.isVisible()) {
			fondoPW.setVisible(true);
			fondoRW.setVisible(false);
			fondoCMW.setVisible(false);
		} else if (fondoRW.isVisible()) {
			fondoPW.setVisible(true);
			fondoRW.setVisible(false);
			fondoCMW.setVisible(false);
		}
	}
	
	public void actionGameHumans() {
		card.show(principal, "HumanoVSHumano");
	}
	
	public void actionGameBot() {
		card.show(principal, "HumanoVSBot");
	}

	public static void main(String[] args) {
		POOBchisGUI gui = new POOBchisGUI();
		gui.setVisible(true);
	}
}
