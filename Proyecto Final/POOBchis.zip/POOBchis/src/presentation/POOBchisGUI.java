package presentation;

import java.awt.*;
import java.awt.event.*;
import java.io.File;

import javax.swing.*;
import javax.swing.border.*;


/**
 * Presentacion del juego
 * @Autor Angie Mojica - Daniel Santanilla
 * @Version 12-04-22
 * */
public class POOBchisGUI extends JFrame{
	
	private JMenuBar barraMenu;
	private JMenu opciones;
	private JMenuItem nuevo, abrir, salvar, salir, regresar;
	private JFileChooser selectorArchivos;
	private JButton jugar, reglas, humano, maquina;
	private JLabel fondoPW, fondoCMW, fondoRW;

	private POOBchisGUI() {
		prepareElements();
		prepareActions();
	}
	// hacer cardlayout para manejar ventanas, poner botones de dados en fin....
	public void prepareElements() {
		setTitle("POOBCHIS");
		setSize(720, 720);
		setLocationRelativeTo(null);
		setResizable(false);
		preparePrincipalWindow();
		prepareChooseModeWindow();
		prepareRulesWindow();
		prepareElementsMenu();
		//prepareElementsBoard();
	    
	}
	
	public void preparePrincipalWindow() {
		fondoPW = new JLabel();
		JLabel titulo = new JLabel();
		jugar = new JButton("JUGAR");
	    reglas = new JButton("REGLAS");
		fondoPW.setBounds(0, 0, 720, 720);
		jugar.setBounds(100, 500, 150, 80);
	    reglas.setBounds(460,500,150, 80);
	    pintarImagen(fondoPW, "./img/tablero.png", 710, 670);
	    titulo.setBounds(170, 100, 380, 260);
	    pintarImagen(titulo, "./img/titulo.gif", 380, 260);
	    fondoPW.add(titulo);
	    fondoPW.add(jugar);
	    fondoPW.add(reglas);
	    add(fondoPW);
	}
	
	public void prepareChooseModeWindow() {
		fondoCMW = new JLabel();
		fondoCMW.setVisible(false);
		JLabel titulo = new JLabel();
		JLabel imagenHumano = new JLabel();
		JLabel imagenMaquina = new JLabel();
		humano = new JButton("JUGADOR VS JUGADOR");
		maquina = new JButton("JUGADOR VS MAQUINA");
		fondoCMW.setBounds(0, 0, 720, 720);
		titulo.setBounds(300, 100, 150, 100);
		imagenHumano.setBounds(100, 300, 150, 150);
		imagenMaquina.setBounds(460, 300, 150, 150);
		humano.setBounds(100, 500, 150, 80);
		maquina.setBounds(460,500,150, 80);
		
		pintarImagen(fondoCMW, "./img/x.png", 710, 670);
	    pintarImagen(titulo, "./img/x.png", 150, 100);
	    pintarImagen(imagenHumano, "./img/x.png", 150, 150);
	    pintarImagen(imagenMaquina, "./img/x.png", 150, 150);
	    
		fondoCMW.add(titulo);
		fondoCMW.add(imagenHumano);
		fondoCMW.add(imagenMaquina);
		fondoCMW.add(humano);
		fondoCMW.add(maquina);
	    add(fondoCMW);
	}
	
	private void prepareRulesWindow() {
		fondoRW = new JLabel();
		fondoRW.setVisible(true);
		fondoRW.setBounds(0, 0, 720, 720);
		
		pintarImagen(fondoRW, "./img/x.png", 710, 670);
		
		add(fondoRW);
	}
	
	private void preprareGameBoardWindow() {
		
	}
	
	private void pintarImagen(JLabel label, String ruta, int ancho, int alto) {
		ImageIcon imagen = new ImageIcon(ruta);
		ImageIcon icon = new ImageIcon(imagen.getImage().getScaledInstance(ancho, alto, Image.SCALE_DEFAULT));
		label.setIcon(icon);
		repaint();
	}
	
	public void prepareElementsMenu() {
		barraMenu = new JMenuBar();
		opciones = new JMenu("Opciones");
		nuevo = new JMenuItem("Nuevo");
		abrir = new JMenuItem("Abrir");
		salvar = new JMenuItem("Guardar");
		salir = new JMenuItem("Salir");
		regresar = new JMenuItem("Regresar");
		opciones.add(nuevo);
		opciones.addSeparator();
		opciones.add(abrir);
		opciones.add(salvar);
		opciones.addSeparator();
		opciones.add(salir);
		barraMenu.add(opciones);
		barraMenu.add(regresar);
		selectorArchivos = new JFileChooser();
		setJMenuBar(barraMenu);
	}
	

	public void prepareActions() {
		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
            	actionClose();
            }
        });
		prepareActionsMenu();
		prepareActionsPrincipalWindow();
	}
	
	public void prepareActionsPrincipalWindow() {
		jugar.addActionListener( new ActionListener(){
			public void actionPerformed( ActionEvent event) {
				actionPlay();
				} 
		});
		reglas.addActionListener( new ActionListener(){
			public void actionPerformed( ActionEvent event) {
				actionRules();
				} 
		});
	}
	
    public void prepareActionsMenu(){
    	abrir.addActionListener( new ActionListener(){ 
    		public void actionPerformed( ActionEvent event ){
            	actionOpen();
            } 
    	});
    	salvar.addActionListener( new ActionListener(){
            public void actionPerformed( ActionEvent event ){
            	actionSave();
            }
        });
        salir.addActionListener( new ActionListener(){
            public void actionPerformed( ActionEvent event ){
            	actionClose();
            }
        });
        regresar.addActionListener( new ActionListener(){
            public void actionPerformed( ActionEvent event ){
            	actionReturn();
            }
        });
    }
	
    public void actionOpen() {
    	File archivo = null;
    	selectorArchivos.setVisible(true);
    	int confirmation = selectorArchivos.showOpenDialog(abrir);
    	if (confirmation == selectorArchivos.APPROVE_OPTION) {
    		archivo = selectorArchivos.getSelectedFile();
    	}
    	JOptionPane.showMessageDialog(abrir, "La accion para abrir el archivo " + archivo.getName() + " esta en construccion.","Informacion",1);
    	selectorArchivos.setVisible(false);
    }
    
    
    public void actionSave() {
    	File archivo = null;
    	selectorArchivos.setVisible(true);
    	int confirmation = selectorArchivos.showSaveDialog(salvar);
    	if (confirmation == selectorArchivos.APPROVE_OPTION) {
    		archivo = selectorArchivos.getSelectedFile();
    	}
    	JOptionPane.showMessageDialog(salvar, "La accion para guardar el archivo " + archivo.getName() + " esta en construccion.","Informacion",1);
    	selectorArchivos.setVisible(false);
    }
    
	public void actionClose(){
        int confirmation = JOptionPane.showConfirmDialog(null,"�Seguro que desea salir?","Cerrar",0);
        if(confirmation == JOptionPane.YES_OPTION){
            System.exit(0);
        }
    }
	
	public void actionPlay() {
		fondoPW.setVisible(false);
		fondoCMW.setVisible(true);
	}
	
	public void actionRules() {
		fondoPW.setVisible(false);
		fondoRW.setVisible(true);
	}
	
	public void actionReturn() {
		if (fondoCMW.isVisible()) {
			fondoPW.setVisible(true);
			fondoRW.setVisible(false);
			fondoCMW.setVisible(false);
		} else if (fondoRW.isVisible()) {
			fondoPW.setVisible(true);
			fondoRW.setVisible(false);
			fondoCMW.setVisible(false);
		}
		
	}
	/**
	 * Metodo principal
	 * */
	public static void main(String[] args) {
		POOBchisGUI gui = new POOBchisGUI();
		gui.setVisible(true);
	}
}
