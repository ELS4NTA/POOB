import java.util.*;
import java.util.Arrays;

/**
 * Crea un simulador de una plaza para MTB.
 * Este simulador contiene una serie de domos y turistas que pueden ser añadidos deacuerdo
 * a la necesidad del usuario, se pueden realizar distintos metodos para poder tener una
 * simulacion deseada y obtener conclusiones.
 * 
 * @author Angie Mojica y Daniel Santanilla
 * @version 0.0.3
 */

public class Square {
    private Rectangle square;
    private int countIdentifier;
    private int dimensionX;
    private int dimensionY;
    private int safetyDistance; 
    private int[] desiredView;
    private HashMap<String,Dome> domeshash = new HashMap();
    private HashMap<String,Tourist> touristshash = new HashMap();
    private boolean isVisible;
    private boolean ok;

    /**
     * Constructor para objetos de la clase Square con parametros de construccion.
     * @param dimensionX Medida de ancho de la plaza, 
     * recomendable que use dimensiones entre 100 y 600 de lo contrario se tomará como 300.
     * @param dimensionY Medida del alto de la plaza, 
     * recomendable que use dimensiones entre 100 y 600 de lo contrario se tomará como 300.
     * @param safetyDistance Distancia segura entre turistas, es recomendable que escoja 
     * su distancia entre 10 y 60 dependiendo del tamanno de su simulacion.
     */
    public Square(int dimensionX, int dimensionY, int safetyDistance) {
        this.ok = false;
        square = new Rectangle();
        int[] rangeX = {100,600};
        int[] rangeY = rangeX;
        if (validRange(dimensionX, dimensionY, rangeX, rangeY)) {
            this.dimensionX = dimensionX;
            this.dimensionY = dimensionY;
            this.safetyDistance = safetyDistance;
            this.countIdentifier = 1;
            this.ok = true;
            isVisible = false;
            square.changeSize(dimensionX,dimensionY);
        } else {
            square.changeSize(300,300);
        }
    }
    
    /**
     * Constructor para objetos de la clase Square con parametros de construccion.
     * @param dimensions Dimensiones de la plaza (ancho y alto) se recomienda dimensiones entre 100 y 600
     * de lo contrario se tomará como 300.
     * @param domes Domos Con las posiciones en X y en Y, los domos maximos aceptados son 6.
     * @param desiredView Orden de los domos en los que se requiere una foto.
     */
    public Square(int[] dimensions, int[][] domes, int[] desiredView) {
        String[] colors = {"red","blue","yellow","black","magenta","green"};
        int[] rangeX = {100,600};
        int[] rangeY = {100,600};
        if (validRange(dimensions[0], dimensions[1], rangeX, rangeY)) {
            this.dimensionX = dimensions[0];
            this.dimensionY = dimensions[1];
        }else {
            this.dimensionX = 300;
            this.dimensionY = 300;
        }
        this.countIdentifier = 1;
        this.desiredView = desiredView;
        this.ok = true;
        isVisible = false;
        square = new Rectangle();
        square.changeSize(dimensionX,dimensionY);
        for (int i=0;i<domes.length;i++) {
            String randomColor = colors[i];
            addDome(randomColor,domes[i][0],domes[i][1]);
        }
    }
    
    /**
     * Asigna la foto que se requiere tomar con el orden de los domos.
     * @param domes Orden de los domos en los que se requiere tomar la foto.
     */
    public void defineRequestedPhoto(String[] domes) {
        this.ok = false;
        this.desiredView = new int[domes.length];
        for (int i=0;i<domes.length;i++) {
            Dome dome = domeshash.get(domes[i]);
            if (dome != null) {
                this.desiredView[i] = dome.getIdentifier();
                this.ok = true;
            }
        }
    }
    
    /**
     * Agregar un Domo a la plaza.
     * @param color Colores validos: "red", "yellow", "blue", "green",
     * "magenta" and "black".
     * @param positionX Posicion en el eje x de la plaza.
     * @param positionY Posicion en el eje y de la plaza.
     */
    public void addDome(String color, int positionX, int positionY) {
        this.ok = false;
        // Verificando que las posiciones dadas estan dentro de la plaza
        int[] rangeX = {0,this.dimensionX};
        int[] rangeY = {0,this.dimensionY};
        if (validRange(positionX, positionY, rangeX, rangeY)) {
            Dome dome = new Dome(color,positionX,this.dimensionY-positionY,this.countIdentifier);
            domeshash.put(color, dome);
            this.countIdentifier += 1;
            if (this.isVisible) {
                dome.makeVisible();
            }
            this.ok = true;
        }
    }
    
    /**
     * Eliminar un Domo de la plaza.
     * @param dome Colores validos: "red", "yellow", "blue", "green",
     * "magenta" and "black".
     */
    public void delDome(String dome) {
        this.ok = false;
        Dome domo = domeshash.get(dome);
        if (domo != null) {
            domo.makeInvisible();
            domeshash.remove(dome);
            this.ok = true;
        }
    }
    
    /**
     * Llegada de un turista a la plaza.
     * @param color Colores validos: "red", "yellow", "blue", "green",
     * "magenta" and "black".
     * @param xPos Posicion en el eje x del turista en las coordenadas de la plaza.
     * @param yPos Posicion en el eje y del turista en las coordenadas de la plaza.
     */
    public void touristArrive(String color, int xPos, int yPos) {
        this.ok = false;
        // Verificando que es seguro annadir un turista
        if (isSafety(color, xPos,yPos)) {
            int[] rangeX = {0,this.dimensionX};
            int[] rangeY = {0,this.dimensionY};
            if (validRange(xPos, yPos, rangeX, rangeY)) {
                Tourist turista = new Tourist(color,xPos,this.dimensionY-yPos,0);
                if (this.isVisible) {
                    turista.makeVisible();
                }
                // Annadiendo referencias del nuevo turista
                touristshash.put(color, turista);
                this.ok = true;
            }
        }
        else {
            System.out.println("No es distancia segura, cuidado con el covid.");
        }
    }
    
    /**
     * Mueve un turista a una posicion especificada en las coordenadas de la plaza.
     * @param tourist Identificador (color) del turista.
     * @param xPos Posicion en el eje x de la plaza a la que se quiere mover.
     * @param yPos Posicion en el eje y de la plaza a la que se quiere mover.
     * @param angle Nuevo angulo de vision del turista en sentido antihorario
     * recomendable usar angulos entre 0 y 360.
     */
    public void touristMove(String tourist, int xPos, int yPos, int angle) {
        this.ok = false;
        Tourist turista = touristshash.get(tourist);
        // Realizando movimientos
        int[] rangeX = {0,this.dimensionX};
        int[] rangeY = {0,this.dimensionY};
        if (validRange(xPos, yPos, rangeX, rangeY)) {
            if (isSafety(tourist,xPos,yPos)) {
                if (turista != null) {
                    turista.moveHorizontal(xPos);
                    turista.moveVertical(this.dimensionY-yPos);
                    turista.setPov(angle);
                    this.ok = true;
                }
            }
            else {
                if (this.isVisible) {
                    System.out.println("No te puedes mover porque esa no es una distancia segura.");
                }
            }
        }
    }
    
    /**
     * Toma una foto de la plaza respecto al angulo de vision del turista.
     * @param tourist Identificador (color) del turista que quiere tomar la foto en la plaza.
     * @return Array con los colores de los domos que fueron captados en camara.
     */
    public String[] touristTakePhoto(String tourist) {
        this.ok = false;
        String[] domesPhotos = new String[domeshash.size()];
        if (touristshash.containsKey(tourist)) {
            int contador = 0;
            Tourist turista = touristshash.get(tourist);
            // Posicion del turista con los ejes del enunciado
            int xTurista = 0;
            int yTurista = 0;
            double angle = 0.0;
            if (turista != null) {
                xTurista = turista.getPosx();
                yTurista = this.dimensionY-turista.getPosy();
                angle = Math.toRadians(turista.getPov()); // Angulo en radianes
                flashCam(turista, turista.getPov());
            }
            // Punto con los ejes de referencia trasladados y rotados con el angulo, origen el turista
            double xComparacionT = (xTurista-xTurista)*Math.cos(angle)+(yTurista-yTurista)*Math.sin(angle); 
            double yComparacionT = (yTurista-yTurista)*Math.cos(angle)-(xTurista-xTurista)*Math.sin(angle); 
            for (Dome dome: domeshash.values()) {
                // Posicion del domo con los ejes del enunciado
                int xDome = dome.getPosx();
                int yDome = this.dimensionY-dome.getPosy();
                // Punto con los ejes de referencia trasladados y rotados con el angulo, origen el turista
                double xComparacionD = (xDome-xTurista)*Math.cos(angle)+(yDome-yTurista)*Math.sin(angle);
                double yComparacionD = (yDome-yTurista)*Math.cos(angle)-(xTurista-xTurista)*Math.sin(angle);
                if (xComparacionD > xComparacionT) {
                    domesPhotos[contador] = dome.getColor();
                    contador += 1;
                }
            }
            this.ok = true;
        }
        return domesPhotos;
    }
    
    /**
     * Toma una foto de la plaza dependiendo del angulo de la camara del turista.
     * @param tourist Identificador (color) del turista que quiere tomar la foto en la plaza.
     * @param viewingAngle Angulo de la camara, este angulo debe estar contenido en 0 y 360.
     * @return Array con los colores de los domos que fueron captados en camara.
     */
    public String[] touristTakePhoto(String tourist, int viewingAngle) {
        this.ok = false;
        String[] domesPhotos = new String[domeshash.size()];
        if (touristshash.containsKey(tourist)) {
            int contador = 0;
            int xTurista = 0;
            int yTurista = 0;
            double angle = Math.toRadians(viewingAngle);
            Tourist turista = touristshash.get(tourist);
            // Posicion del turista con los ejes del enunciado
            if (turista != null) {
                xTurista = turista.getPosx();
                yTurista = this.dimensionY-turista.getPosy();
                flashCam(turista, viewingAngle);
            }
             // Angulo en radianes
            // Punto con los ejes de referencia trasladados y rotados con el angulo, origen el turista
            double xComparacionT = (xTurista-xTurista)*Math.cos(angle)+(yTurista-yTurista)*Math.sin(angle); 
            for (Dome dome: domeshash.values()) {
                // Posicion del domo con los ejes del enunciado
                int xDome = dome.getPosx();
                int yDome = this.dimensionY-dome.getPosy();
                // Punto con los ejes de referencia trasladados y rotados con el angulo, origen el turista
                double xComparacionD = (xDome-xTurista)*Math.cos(angle)+(yDome-yTurista)*Math.sin(angle);
                if (xComparacionD > xComparacionT) {
                    domesPhotos[contador] = dome.getColor();
                    contador += 1;
                }
            }
            
            this.ok = true;
        }
        return domesPhotos;
    }
    
    /**
     * Retorna los domos existentes en la plaza.
     * @return Array con los identificadores (colores) de los domos.
     */
    public String[] domes() {
        this.ok = true;
        int contador = 0;
        String[] strDomes = new String[domeshash.size()]; // Creando un Array con el tamanno del ArrayList de domos
        // Annadiendo referencias de los domos al Array creado
        for (Dome dome: domeshash.values()) {
            strDomes[contador] = dome.getColor();
            contador += 1;
        }
        return strDomes;
    }
    
    /**
     * Retorna los turistas existentes en la plaza.
     * @return Array con los identificadores (colores) de los turistas.
     */
    public String[] tourists() {
        this.ok = true;
        int contador = 0;
        String[] strTourist = new String[touristshash.size()]; // Creando un Array con el tamanno del ArrayList de turistas
        // Annadiendo referencias de los turistas al Array creado
        for (Tourist turista: touristshash.values()) {
            strTourist[contador] = turista.getColor();
            contador += 1;
        }
        return strTourist;
    }
    
    /**
     * Retorna la informacion del domo especificado.
     * @param dome Color del domo deseado; Colores validos: "red", "yellow", "blue", "green",
     * "magenta" and "black".
     * @return Array con las posiciones en X y en Y del domo.
     */
    public int[] dome(String dome) {        
        this.ok = false;
        int[] dome_info = {-1,-1};
        if (domeshash.containsKey(dome)) {
            Dome domo = domeshash.get(dome);
            dome_info[0] = domo.getPosx();
            dome_info[1] = domo.getPosy();
            this.ok = true;
        }
        return dome_info;
    }
    
    /**
     * Retorna la informacion del turista especificado.
     * @param tourist Color del turista deseado; Colores validos: 
     * "red", "yellow", "blue", "green","magenta" and "black"
     * @return Array con las posiciones en X, en Y y el angulo de vision del turista.
     */
    public int[] tourist(String tourist) {
        this.ok = false;
        int[] tourist_info = {-1,-1,-1};
        if (touristshash.containsKey(tourist)) {
            Tourist turista = touristshash.get(tourist);
            tourist_info[0] = turista.getPosx(); // Posicion en X del turista
            tourist_info[1] = turista.getPosy(); // Posicion en Y del turista
            tourist_info[2] = turista.getPov(); // Angulo de vision del turista
            this.ok = true;
        }
        return tourist_info;
    }
    
    /**
     * Hace visible la simulacion.
     */
    public void makeVisible() {
        this.ok = true;
        this.isVisible = true;
        square.makeVisible();
        // Verifica si hay objetos en la plaza
        if (domeshash.size() > 0 || touristshash.size() > 0) {
            // Hace visible los domos annadidos previamente
            for (Dome dome: domeshash.values()) {
                dome.makeVisible();
            }
            // Hace visible los turistas annadidos previamente
            for (Tourist turista: touristshash.values()) {
                turista.makeVisible();
            }
        }
    }
    
    /**
     * Hace invisible la simulacion.
     */
    public void makeInvisible() {
        this.ok = true;
        this.isVisible = false;
        square.makeInvisible();
        // Verifica si hay objetos en la plaza
        if (domeshash.size() > 0 || touristshash.size() > 0) {
            // Hace visible los domos annadidos previamente
            for (Dome dome: domeshash.values()) {
                dome.makeInvisible();
            }
            // Hace visible los turistas annadidos previamente
            for (Tourist turista: touristshash.values()) {
                turista.makeInvisible();
            }
        }
    }
    
    /**
     * Finalizacion del simulador borrando toda la informacion almacenada.
     */
    public void finish() {
        for (Tourist turista: touristshash.values()) {
            turista.makeInvisible();
        }
        for (Dome dome: domeshash.values()) {
            dome.makeInvisible();
        }
        square.makeInvisible();
        square.changeSize(0,0);
        domeshash = new HashMap();
        touristshash = new HashMap();
        desiredView = new int[0];
        this.ok = true;
    }
    
    /**
     * Verifica la operacion indicada se pudo ejecutar en el simulador, este devolvera un mensaje de referencia.
     * @return true si la operacion se realizó satisfactoriamente,
     * de lo contrario false.
     */
    public boolean ok() {
        if (this.isVisible) {
            if (!this.ok) {
                System.out.println("La accion no se pudo realizar.");
            }
        }
        return this.ok;
    }
    
    /* Si es seguro que ingrese un turista a la plaza con condiciones de bioseguridad
     * @return boolean se calcula la distancia entre los turistas y si es seguro el turista ingresa (true)
     * en caso de que no sea seguro este no ingresa (false)
     */
    private boolean isSafety(String color,int xPosNewTourist,int yPosNewTourist) {
        // Si existen turistas en la plaza
        boolean flag = true;
        if (touristshash.size() > 0) {
            // Recorriendo los turistas
            for (Tourist turista: touristshash.values()) {
                if (!(turista.getColor().equals(color))) {
                    int xPosOldTourist = turista.getPosx();
                    int yPosOldTourist = Math.abs(turista.getPosy()-this.dimensionY);
                    
                    // Distancia entre turistas
                    double distance = Math.sqrt(Math.pow(xPosOldTourist-xPosNewTourist,2)+Math.pow(yPosOldTourist-yPosNewTourist,2));
                    if (distance < this.safetyDistance) {
                        flag = false;
                    }  
                }
            }
        }
        return flag;
    }
    
    /* Nuevo punto a annadir en un rango valido
     * @param newX Punto en x a annadir en el rango
     * @param newY Punto en y a annadir en el rango
     * @param rangeX Rango definido para x
     * @param rangeY Rango definido para y
     * @return true si es valido annadirlo en rangos dados, de lo contrario false
     */
    private boolean validRange(int newX, int newY, int[] rangeX, int[] rangeY) {
        boolean flag = false;
        if ((newX>=rangeX[0] && newX<=rangeX[1]) && (newY>=rangeY[0] && newY<=rangeY[1])) {
            flag = true;
        }
        return flag;
    }
    
    private void flashCam(Tourist turista, int angle) {
        //Rectangle flash = new Rectangle(); // hay que lograr esto :")        
        //flash.setAngle(angle+90);
        //flash.drawFlash(tourist.getPosx(),tourist.getPosy(),this.dimensionX,this.dimensionY);
    }
    
}
