
public class __SHELL197 extends bluej.runtime.Shell {
public static java.lang.Object run() throws Throwable {

return new java.lang.Object() { Square __bluej__result__;
{ int[] __bluej_param0 = {600,600};
int[][] __bluej_param1 = {{400,400},{200,200},{300,300},{150,450},{150,150},{300,100}};
int[] __bluej_param2 = {3,1,2,4,5,6};
try {
__bluej__result__=(new Square(__bluej_param0,__bluej_param1,__bluej_param2)
);}
finally {
}} };
}}
