
public class __SHELL64 extends bluej.runtime.Shell {
public static void run() throws Throwable {
final bluej.runtime.BJMap __bluej_runtime_scope = getScope("C:\\Users\\usuario\\OneDrive - ESCUELA COLOMBIANA DE INGENIERIA JULIO GARAVITO\\University\\Quinto Semestre\\POOB\\Proyecto\\Ciclo2\\square");
final Square square1 = (Square)__bluej_runtime_scope.get("square1");


java.lang.String __bluej_param0 = "red";
int __bluej_param1 = 150;
int __bluej_param2 = 250;
int __bluej_param3 = 0;
square1.touristMove(__bluej_param0,__bluej_param1,__bluej_param2,__bluej_param3);

}}
